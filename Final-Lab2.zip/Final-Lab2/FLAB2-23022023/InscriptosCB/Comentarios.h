#ifndef COMENTARIOS_H_INCLUDED
#define COMENTARIOS_H_INCLUDED

#include "Fecha.h"

class comentario{
private:
    int _id;
	int _legajo;
	char _texto[300];
	Fecha _FechaPublicacion;
	int _IDForo;//(1- Cafeter�a, 2- Foro de dudas, 3- Tareas, 4 - Grupos, 5- Desaf�os )
	int _IDComentarioRespuesta;

public:
    int getid();
	int getlegajo();
	const char *gettexto(){return _texto;}
	Fecha getFechaPublicacion();
	int getIDForo();
	int getIDComentarioRespuesta();

	void setid(int id);
	void setlegajo(int leg);
	void settexto(const char *tex);
	void setFechaPublicacion(Fecha fe);
	void setIDForo(int idf);
	void setIDComentarioRespuesta(int idc);

	void cargarComentario();
	int grabarenDisco();


};

#endif // COMENTARIOS_H_INCLUDED
