#include <iostream>
using namespace std;
#include "modeloParcial.h"


int main()
{
    modeloParcial obj;

    obj.punto1();
    cout<<endl;
    obj.punto2();
    cout<<endl;
    obj.punto3();


    return 0;
}
