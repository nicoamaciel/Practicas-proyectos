
#ifndef MODELOPARCIAL_H_INCLUDED
#define MODELOPARCIAL_H_INCLUDED



class modeloParcial{

private:
public:
    void punto1();
    void punto2();
    void punto3();

};



#endif // MODELOPARCIAL_H_INCLUDED
