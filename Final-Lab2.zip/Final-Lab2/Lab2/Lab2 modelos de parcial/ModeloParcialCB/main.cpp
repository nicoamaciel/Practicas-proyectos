#include <iostream>
using namespace std;

#include "modelo.h"
int main()
{
    modelo reg;

    //reg.punto1();
    //reg.punto2();
    reg.punto3();


    return 0;
}
