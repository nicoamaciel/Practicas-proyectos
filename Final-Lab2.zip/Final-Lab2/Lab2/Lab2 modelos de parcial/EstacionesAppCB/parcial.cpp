#include <iostream>
#include "ResumenDiario.h"
#include "ResumenDiarioArchivo.h"

using namespace std;

#include "parcial.h"

void parcial::punto1(){

      ResumenDiarioArchivo resumen;
      int cantidad = resumen.getCantidad();
      ResumenDiario* resDiario = new ResumenDiario[cantidad];

      //CargarVector
      for (int i = 0; i < cantidad; i++) {
        resDiario[i] = resumen.leer(i);
      }

        int masCaro=0;
        int idMasCaro=0;

      for(int j=0; j<cantidad; j++){
            if(resDiario[j].getPrecioPorLitro()>masCaro){
                masCaro = resDiario[j].getPrecioPorLitro();
                idMasCaro = resDiario[j].getIDTipoCombustible();
            }


        }

        cout << "Precio por litro: " << masCaro<<endl;
        cout << "ID: " << idMasCaro <<endl;
        mostrarNombre(idMasCaro);
        cout << " - - - - - - - - - - - - - - - - - - - - - - "<< endl;

}

void parcial::mostrarNombre(int id){

if(id==1){cout << "Combustible mas caro Nafta super" << endl;}
if(id==2){cout << "Combustible mas caro Nafta comun" << endl;}
if(id==3){cout << "Combustible mas caro Diesel" << endl;}
if(id==4){cout << "Combustible mas caro Gasoil" << endl;}
if(id==5){cout << "Combustible mas caro Gas" << endl;}

}


void parcial::punto2(){

    ResumenDiarioArchivo resumen;
    int cantidad = resumen.getCantidad();
    ResumenDiario* resDiario = new ResumenDiario[cantidad];

    //CargarVector
    for (int i = 0; i < cantidad; i++) {
        resDiario[i] = resumen.leer(i);
    }

    int idEstacion;
    cout << "Ingrese Id de estacion: ";
    cin >> idEstacion;

    for (int j = 0; j < cantidad; j++) {
        if(idEstacion == resDiario[j].getIDEstacion() && resDiario[j].getIDTipoCombustible()!=1){
            cout << "Mes sin nafta super: " << resDiario[j].getFecha().getMes() <<endl;
        }
    }


}




void parcial::punto3(){

    ResumenDiarioArchivo resumen;
    int cantidad = resumen.getCantidad();
    ResumenDiario* resDiario = new ResumenDiario[cantidad];

    //CargarVector
    for (int i = 0; i < cantidad; i++) {
        resDiario[i] = resumen.leer(i);
    }

    int tipo1=0;
    float precio1=0;

    for (int i = 0; i < cantidad; i++) {
        if(resDiario[i].getIDTipoCombustible()==1){
            tipo1++;
        }
        precio1=resDiario[i].getPrecioPorLitro();

    }

    cout << "Tipo1: " << tipo1*precio1;


}
