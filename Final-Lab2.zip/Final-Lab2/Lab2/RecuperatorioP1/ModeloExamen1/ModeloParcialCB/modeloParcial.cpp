/*
1) Mostrar legajo, apellidos y nombres de aquellos estudiantes que no hayan
rendido ning�n examen en el a�o 2022.

2) Por cada alumno listar legajo, apellidos, nombres, cantidad de ex�menes
aprobados (nota >=6) y cantidad de ex�menes desaprobados. Utilizar el
siguiente formato:

3) Listar la cantidad de alumnos que hayan rendido examen m�s de una vez
para la misma materia entre los a�os 2018 y 2022 (ambos a�os inclusive).
Aclaraci�n: Los IDMateria son valores entre 1 y 60.
*/


#include <iostream>
using namespace std;

#include "modeloParcial.h"
#include "Estudiante.h"
#include "EstudiantesArchivo.h"
#include "Examen.h"
#include "ExamenesArchivo.h"

void modeloParcial::punto1(){

ExamenesArchivo obj;
int cantExamen = obj.getCantidad();

EstudiantesArchivo obj2;
int cantEstu = obj2.getCantidad();

Examen *exa = new Examen[cantExamen];
if(exa==nullptr){"Error dinamico examen";}

Estudiante *est = new Estudiante[cantEstu];
if(est==nullptr){"Error dinamico estudiante";}

for(int i=0; i<cantExamen; i++){
    exa[i] = obj.leer(i);

}

for(int x=0; x<cantEstu; x++){
    est[x] = obj2.leer(x);

}


for(int i=0; i<cantEstu; i++){
    int cont=0;
    for(int x=0; x<cantExamen; x++){
        if(est[i].getLegajo()==exa[x].getLegajo() && exa[x].getFecha().getAnio()==2022){
            cont++;
        }
    }

    if(cont==0){
        cout << est[i].getLegajo() << " " << est[i].getNombres() << " " << est[i].getApellidos() << endl;
    }

}

delete []exa;
delete []est;

}



void modeloParcial::punto2(){


ExamenesArchivo obj;
int cantExamen = obj.getCantidad();

EstudiantesArchivo obj2;
int cantEstu = obj2.getCantidad();

Examen *exa = new Examen[cantExamen];
if(exa==nullptr){"Error dinamico examen";}

Estudiante *est = new Estudiante[cantEstu];
if(est==nullptr){"Error dinamico estudiante";}

for(int i=0; i<cantExamen; i++){
    exa[i] = obj.leer(i);

}

for(int x=0; x<cantEstu; x++){
    est[x] = obj2.leer(x);

}

    for(int x=0; x<cantEstu; x++){
        int aprobado=0;
        int desaprobado=0;

        for(int i=0; i<cantExamen; i++){
            if(est[x].getLegajo()==exa[i].getLegajo()){
                if(exa[i].getNota()>=6){
                aprobado++;
                }
                if(exa[i].getNota()<6){
                desaprobado++;
                }

            }
        }
        cout <<est[x].getLegajo()<< "\t" << est[x].getNombres() << "\t" << est[x].getApellidos() << "\t" << aprobado << "\t" << desaprobado << endl;
        cout << " - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - " << endl;

    }










delete []exa;
delete []est;


}


void modeloParcial::punto3(){

ExamenesArchivo obj;
int cantExamen = obj.getCantidad();

EstudiantesArchivo obj2;
int cantEstu = obj2.getCantidad();

Examen *exa = new Examen[cantExamen];
if(exa==nullptr){"Error dinamico examen";}

Estudiante *est = new Estudiante[cantEstu];
if(est==nullptr){"Error dinamico estudiante";}

for(int i=0; i<cantExamen; i++){
    exa[i] = obj.leer(i);

}

for(int x=0; x<cantEstu; x++){
    est[x] = obj2.leer(x);

}


int cantidad=0;
for(int x=0; x<cantEstu; x++){
        bool masDos=false;

        int vecMaterias[60]{};
        for(int i=0; i<cantExamen; i++){
        if(est[x].getLegajo()==exa[i].getLegajo()){
            if(exa[i].getFecha().getAnio()>=2018 && exa[i].getFecha().getAnio()<=2022){
                vecMaterias[exa[i].getIDMateria()-1]++;
                }
            }
            if(vecMaterias[exa[i].getIDMateria()-1]>=2){
                masDos = true;
            }


        }

        if(masDos){
            cantidad++;
        }

    }

cout << cantidad << endl;

delete []exa;
delete []est;



}
