#ifndef ESTADISTICAS_H_INCLUDED
#define ESTADISTICAS_H_INCLUDED



class estadisticas{

private:
    int _anio;
    float _recaudacion;
public:
    estadisticas();
    estadisticas(int anio, float recaudacion);
    int getAnio();
    float getRecaudacion();
    void setAnio(int anio);
    void setRecaudacion(float recaudacion);
    void add(float recaudacion);

    void mostrarEstadistica();
};



#endif // ESTADISTICAS_H_INCLUDED

