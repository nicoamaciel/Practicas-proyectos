
///Maciel Nicolas
///parcial 2 - 7/11


#include <iostream>
#include <cstdlib>

using namespace std;
#include "clasesp2.h"

/*
1-Crear un archivo con las asignaciones realizadas para el proyecto Gesti�n ventas DEK SA en el a�o 2021.
El archivo debe tener el mismo formato que el archivo de asignaciones, pero sin la fecha.
Mostrar el archivo creado.


2-Dar de baja l�gica en el archivo de asignaciones a los registros del a�o actual.
Listar el archivo omitiendo los registros dados de baja.


4-Crear un vector din�mico para copiar y mostrar el archivo luego de las modificaciones del punto 2.

*/

class ventasDEK21{
private:
    int numero;
    int legajoProgramador;
    int codigoProyecto;
    int localidad;
    bool estado;
public:
    void setNumero(int n){numero=n;}
    void setLegajoProgramador(int l){legajoProgramador=l;}
    void setCodigoProyecto(int cod){codigoProyecto=cod;}
    void setLocalidad(int loc){localidad=loc;}
    void setEstado(bool est){estado=est;}



    bool grabarEnDisco(){
    FILE *p = fopen("ventasdek.dat","ab");
    if(p==NULL){return false;}
    bool escribio = fwrite(this,sizeof *this,1,p);
    fclose(p);
    return escribio;
    }

    void mostrar(){
    cout << "Numero: " << numero << endl;
    cout << "Legajo: " << legajoProgramador << endl;
    cout << "Codigo: " << codigoProyecto << endl;
    cout << "Localidad: " << localidad << endl;
    cout << "Estado: " << estado << endl;
    }






};



void punto1();
    bool buscarProyecto(int cod);
    void leerRegistro();
bool punto2();
    bool modificarEnDisco(int pos);


void punto4();
    int contarModifaciones();
    void copiarModificados(Asignacion *vMod);





int main(){

punto1();
cout << endl;
punto2();
cout << endl;
punto4();



return 0;
}



void punto1(){
Asignacion obj;
ventasDEK21 reg;
int pos=0;

while(obj.leerDeDisco(pos)){
    if(obj.getFechaAsignacion().getAnio()==2021){
        if(buscarProyecto(obj.getNumero())){
            reg.setNumero(obj.getNumero());
            reg.setLegajoProgramador(obj.getLegajoProgramador());
            reg.setCodigoProyecto(obj.getCodigoProyecto());
            reg.setLocalidad(obj.getLocalidad());
            reg.setEstado(obj.getEstado());

            if(reg.grabarEnDisco()){
                cout << "Archivo grabado con exito" << endl;
            }


        }
    }

    pos++;
    }



}


bool buscarProyecto(int cod){
Proyecto reg;
int pos=0;

while(reg.leerDeDisco(pos)){
    if(reg.getCodigo()==2){
        return true;
    }

    pos++;
}


}


void leerRegistro(){
    FILE *p;
    ventasDEK21 aux;
    p=fopen("ventasdek.dat","rb");
    if(p==NULL){cout << "ERROR DE ARCHIVO"<<endl;}

    while(fread(&aux,sizeof aux, 1, p)==1){
        aux.mostrar();
        cout << endl;
    }
    fclose(p);

}




bool punto2(){

Asignacion obj;
int pos=0;

while(obj.leerDeDisco(pos)){
    if(obj.getFechaAsignacion().getAnio()==2021){
        obj.leerDeDisco(pos);
        obj.setEstado(false);
        modificarEnDisco(pos);
        }

    pos++;
    }

    int pos2=0;
    while(obj.leerDeDisco(pos2)){
    obj.Mostrar();
    pos2++;
    }



}



bool modificarEnDisco(int pos){
    Asignacion obj;
    FILE *p;
    p=fopen("Asignaciones.dat","rb+");
    if(p==NULL) return false;
    fseek(p, pos * sizeof(Asignacion), 0);
    bool escribio=fwrite(&obj, sizeof (Asignacion), 1, p);
    fclose(p);
    return escribio;
    }


void punto4(){

Asignacion *vMod;
int cant = contarModifaciones();
vMod = new Asignacion[cant];
if(vMod=NULL){"ERROR";}
copiarModificados(vMod);

delete []vMod;

}


int contarModifaciones(){
Asignacion aux;
int pos=0, cant=0;
while(aux.leerDeDisco(pos++)){
    if(aux.getEstado()==false){
        cant++;
    }
    return cant;
}


}

void copiarModificados(Asignacion *vMod){


}

