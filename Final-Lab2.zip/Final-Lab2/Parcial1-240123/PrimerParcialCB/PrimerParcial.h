#ifndef PRIMERPARCIAL_H_INCLUDED
#define PRIMERPARCIAL_H_INCLUDED

/*
1) Un m�todo llamado  listarRecaudacion  que muestre para cada curso, la recaudaci�n obtenida desde el 10/05/2020.
    (2 Puntos)
2) Agregar a la clase  Pago un m�todo llamado  esPagoVencido   que determine si el pago fue un pago vencido o no.
    (1 Punto)

3) Agregar un m�todo llamado  listarAlumnosNoMorosos  y que usando el m�todo del punto anterior,
muestre los legajos de los alumnos que nunca realizaron un pago vencido.
    (2 Puntos)

4)Un m�todo llamado  soloUnCurso  que muestre el legajo, nombre y apellido de todos los alumnos que
pagaron solamente un curso del periodo (a�o per�odo de cursada)  2021 .
    (2 Puntos)

5) Crear un m�todo  generarEstadistica  que genere un archivo llamado estadisticas.dat que guarde el a�o y
la recaudaci�n de cada a�o del archivo de pagos
Crear un m�todo llamado  mostrarEstadisticas  que muestre el archivo generado en el punto anterior.
    (2 Puntos)

6) Crear un m�todo llamado  cursosPremium  que reciba el legajo de un estudiante y
muestre el id del curso al que realiz� el mayor pago individual (en caso de haber m�s de uno, muestre todos los que cumplan esa condici�n).
(1 Punto)

Aclaraci�n: Un pago vencido es aquel que la fecha de pago es superior al del per�odo de cursada.
Aclaraci�n 2: Solo existen 10 cursos, y los ids van del 1 al 10
Aclaraci�n 3: Solo existen 2 m�todos de pagos y son (1- Efectivo, 2- Tarjeta)


*/




class PrimerParcial{


private:


public:
    void listarRecaudacion();
    void soloUnCurso();
    void generarEstadistica();
    void mostraEstadistica();
    void cursosPremium(int leg);

};


#endif // PRIMERPARCIAL_H_INCLUDED
