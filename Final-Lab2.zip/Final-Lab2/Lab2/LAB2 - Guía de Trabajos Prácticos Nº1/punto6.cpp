/*
6
La Universidad Brian Lara dispone de los registros de todos los cursos que se dictar�n en el a�o actual.
Por cada curso se registr� la siguiente informaci�n:

N�mero de curso (entero)
N�mero de aula (10, 20, 30, 40, 50, 60, 70, 80, 90, 100)
Turno ('M' - Ma�ana, 'T' - Tarde, 'N' - Noche)
Cantidad de alumnos inscriptos

El fin de la carga de datos se indica con un n�mero de curso igual a cero.
La informaci�n no est� agrupada ni ordenada. Se pide calcular informar:

A) Por cada aula, la cantidad total de cursos que la utilizaron.

B) El promedio de alumnos por turno (se muestra un s�lo resultado).

C) Por cada aula, la m�xima cantidad de alumnos inscriptos en un curso.
Por ejemplo, si el aula 50 es utilizada por el curso 1 con 30 alumnos y el curso 2 con 75 alumnos.
Entonces, la mayor cantidad de alumnos inscriptos para el aula 50 es de 75.


*/



#include <iostream>
using namespace std;

//Declaracion de la funcion


int main(){


int NumeroCurso; //(entero)
int NumeroAula; //(10, 20, 30, 40, 50, 60, 70, 80, 90, 100)
char Turno;// ('M' - Ma�ana, 'T' - Tarde, 'N' - Noche)
int CantAlumnosInscriptos;


//PuntoA
int const AULAS=100;
int vCursosXaula[AULAS]{};

//PuntoB
int ContadorT=0, ContadorM=0, ContadorN=0;
float Noche=0, Tarde=0, Maniana=0;

//PuntoC
int vMaximosAlumnos[AULAS]{};


cout << "Numero de curso: ";
cin >> NumeroCurso;

while(NumeroCurso!=0){



    cout << "Numero de aula: ";
    cin >> NumeroAula;
    cout << "Turno -->> M-maniana T-tarde N-noche: ";
    cin >> Turno;
    cout << "Cantidad alumnos inscriptos: ";
    cin >> CantAlumnosInscriptos;



    //PuntoA
    for(int i=0; i<AULAS; i++){
      if(NumeroAula==i){
        vCursosXaula[i]++;
      }
    }


    //PuntoB
    if(Turno == 't' || Turno == 'T'){
        ContadorT++;
        Tarde+=CantAlumnosInscriptos;
    }
    if(Turno == 'n' || Turno == 'N'){
        ContadorN++;
        Noche+=CantAlumnosInscriptos;
    }
    if(Turno == 'm' || Turno == 'M'){
        ContadorM++;
        Maniana+=CantAlumnosInscriptos;

    }

    //PuntoC

    for(int y=0; y<AULAS; y++){
        if(NumeroAula==y && CantAlumnosInscriptos>vMaximosAlumnos[y]){
            vMaximosAlumnos[y]=CantAlumnosInscriptos;
        }

    }





cout << "------------------------------" << endl;
cout << "Numero de curso: ";
cin >> NumeroCurso;

}///TerminaWhile


cout << "Punto A: " << endl;
for (int i=1; i<AULAS; i++){
    if(vCursosXaula[i]>0){
        cout << "Aula: " << i << " Cantidad: " <<  vCursosXaula[i] << endl;
    }

}

cout << "------------------------------" << endl;
cout << "Punto B: " << endl;
cout << "Promedio maniana: " << Maniana/ContadorM << endl;
cout << "Promedio tarde: " << Tarde/ContadorT << endl;
cout << "Promedio noche: " << Noche/ContadorN << endl;

cout << "------------------------------" << endl;
cout << "Punto C: " << endl;
for (int y=1; y<AULAS; y++){
    if(vMaximosAlumnos[y]>0){
        cout << "Aula: " << y << " Maximos alumnos: " <<  vMaximosAlumnos[y] << endl;
    }

}



return 0;
}

