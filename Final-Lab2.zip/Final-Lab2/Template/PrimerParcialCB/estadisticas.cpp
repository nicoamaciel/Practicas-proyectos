
#include <iostream>
using namespace std;
#include "estadisticas.h"

int estadisticas::getRecaudacion(){
    return _recaudacion;
}

int estadisticas::getAnio(){
    return _anio;
}

void estadisticas::setAnio(int an){
    _anio=an;
}

void estadisticas::setRecaudacion(float reca){
    _recaudacion=reca;
}

void estadisticas::add(float reca){
    _recaudacion+=reca;

}

void estadisticas::verEstadisticas(){

cout << "Anio: " << getAnio() << endl;
cout << "Recaudacion: " << getRecaudacion() << endl;

}
