#include <iostream>
#include <cstdlib>
#include <cstring>
#include <fstream>

using namespace std;
#include "fecha.h"
#include "alertas.h"




    ///Gets

    int alertas::getUsuario(){
        return _Usuario;
    }
    fecha alertas::getFechaDeAlerta(){
        return _FechaDeAlerta;
    }
    bool alertas::getEstado(){
        return _Estado;
    }


    ///Sets

    void alertas::setTorre(const char *torre){
        strcpy (_Torre,torre);
    }

    void alertas::setNombreEquipo(const char *nom){
        strcpy(_NombreEquipo,nom);
    }

    void alertas::setServicio(const char *ser ){
        strcpy (_Servicio,ser);
    }


    void alertas::setUsuario(int usu){
        _Usuario=usu;
    }

    void alertas::setFechaDeAlerta(fecha fe){
        _FechaDeAlerta=fe;
    }

    void alertas::setEstado(bool est){
        _Estado=est;
    }




    ///Comportamientos

        void alertas::cargarAlertas(){
        int usu, pos;
        char torre[20], servicio[20], host[20];
        fecha fe;
        bool est;

        do{
        cout << "Cargar torre de resolucion: ";
        cin >> torre;
        cout << "Cargar servicio alertado: ";
        cin >> servicio;
        cout << "Cargar usuario: ";
        cin >> usu;
        pos = buscarAlerta(servicio,torre,usu);
        if(pos>=0){
        cout << "Alerta ya registarada con anterioridad" << endl;
        system("pause");
        }
        else{
            setTorre(torre);
            setServicio(servicio);
            setUsuario(usu);
            }
        }while(pos>=0);

        cout << "Cargar nombre del equipo: ";
        cin >> host;
        cout << "Cargar fecha de alerta: ";
        fe.cargarFecha();
        est = true;

        setNombreEquipo(host);
        setFechaDeAlerta(fe);
        setEstado(est);
        }

        void alertas::mostrarAlertas(){
            if(_Estado==true){
            cout  << getTorre() << "     |     "<< getNombreEquipo() << "      |     "<< getServicio() << "   |     " << getUsuario() << "          |     " ;
            getFechaDeAlerta().mostrarFecha();
            cout <<endl;
            }

        }

        void verAlertas(){
        cout << " TORRE " << "        |     "  << " HOST " << "               | "  <<" SERVICIO "<< "          | "  <<" USUARIO" << "          | "  <<" FECHA" <<  endl;
        cout << "------------------------------------------------------------------------------------------------------"<< endl;
        }


    int alertas::grabarenDisco(){
        FILE *pAlertas;
        pAlertas = fopen("alertas.dat", "ab");
        if(pAlertas == NULL){
        cout << "ERROR DE ARCHIVO"<< endl;
        system("pause");
        return -1;
        }

        int escribio = fwrite(this, sizeof(alertas), 1, pAlertas);
        fclose(pAlertas);
        return escribio;

    }

    int alertas::leerdeDisco(int pos){
        FILE *pAlertas;
        int leyo;
        pAlertas = fopen("alertas.dat", "rb");
        if(pAlertas == NULL){
            cout << "ERROR DE ARCHIVO"<< endl;
            system("pause");
            return -1;
        }
        fseek(pAlertas, pos*sizeof(alertas),0);
        leyo = fread(this, sizeof(alertas),1,pAlertas);
        fclose(pAlertas);
        return leyo;

    }

    bool alertas::modificarEnDisco(int pos){
        FILE *p;
        p=fopen("alertas.dat","rb+");
        if(p==NULL) return false;
        fseek(p, pos * sizeof(alertas), 0);
        bool escribio=fwrite(this, sizeof (alertas), 1, p);
        fclose(p);
        return escribio;

    }


    int buscarAlerta(char *servicio, char *torre, int usu){
        alertas obj;
        int pos=0;
        while(obj.leerdeDisco(pos)){
            if(strcmp(obj.getServicio(),servicio)==0){
                if(strcmp(obj.getTorre(),torre)==0){
                    if(obj.getUsuario()==usu){
                        return pos;
                    }

                }
            }
            pos++;
        }
        return -1;


    }

    bool bajaAlerta(){
        alertas obj;
        int pos,usu;
        char servicio[20];
        char torre[20];

        cout << "Validacion de servicio alertado: ";
        cin >> servicio;
        cout << "Validacion de torre: ";
        cin >> torre;
        cout << "Validar usuario: ";
        cin >> usu;

        pos = buscarAlerta(servicio,torre,usu);
        if(pos==-1){
        cout << "El servicio no exite en el archivo: "<< endl;
        system("pause");
        return false;
        }
        obj.leerdeDisco(pos);
        if(obj.getEstado()==false){
        cout << "Alerta ya fue dada de baja"<< endl;
        system("pause");
        return true;
        }

        obj.leerdeDisco(pos);
        obj.setEstado(false);
        obj.modificarEnDisco(pos);


    }



    bool csvAlertas(){
    alertas obj;
    int pos=0;

    ofstream _alertas("alertas.csv",ios::ate);

    if(!_alertas){
        cout << "Error al grabar registro en csv";
    }
    else{
        _alertas<<"TORRE"<<";"<<"HOST"<<";"<<"SERVICIO"<<";"<<"USUARIO"<<";"<<"DIA"<<";"<<"MES"<<";"<<"ANIO"<<endl;
        while(obj.leerdeDisco(pos)==1){
                _alertas<<obj.getTorre()<<";"<<obj.getNombreEquipo()<<";"<<obj.getServicio()<<";"<<obj.getUsuario()<<";"<<obj.getFechaDeAlerta().getDia()<<";"<<obj.getFechaDeAlerta().getMes()<<";"<<obj.getFechaDeAlerta().getAnio()<<endl;
                pos++;
            }
            _alertas.close();
        }

    }


