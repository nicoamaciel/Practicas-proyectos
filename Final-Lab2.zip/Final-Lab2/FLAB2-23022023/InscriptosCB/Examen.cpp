
#include <iostream>
#include <cstdlib>
#include <stdio.h>
#include <string.h>
using namespace std;

#include "Estudiante.h"
#include "EstudiantesArchivo.h"
#include "Comentarios.h"
#include "comentarioArchivo.h"
#include "Fecha.h"

#include "Examen.h"

/*
1- Crear un m�todo llamado crearComentario que me permita agregar un comentario a alguno de los foros correspondientes
y lo registre en el archivo comentarios.dat .Validaciones a considerar:

- No se puede registrar un comentario con un alumno que no existe en el sistema.
- No se puede realizar una respuesta a un comentario que no existe en el sistema.
- No se puede responder a un comentario que pertenezca a otro foro.
(30- Puntos)

2- Crear un m�todo llamado fullComentado que muestre el nombre del foro que ha registrado la mayor
cantidad de comentarios durante el a�o 2022, excluyendo aquellos que son respuestas. En caso de que exista
un empate en la cantidad de comentarios entre dos o m�s foros, el m�todo deber� mostrar todos aquellos que
cumplan con dicha condici�n.
(30- Puntos)

3- Crear un m�todo llamado cortitaYAlPie cuyo prop�sito consista en identificar y
mostrar los nombres de aquellos estudiantes que han participado en el foro de dudas mediante la realizaci�n
de comentarios, y cuyas contribuciones no superan los 200 caracteres en longitud.
(30- Puntos)


*/


void Examen::leerComentarios(){

comentarioArchivo com;
int cantComentarios = com.getCantidad();
comentario* vecCom = new comentario[cantComentarios];
if(vecCom==nullptr){cout << "error en vec dinamico";}

    for(int i=0; i<cantComentarios; i++){
        vecCom[i] = com.leer(i);
    }

    for(int i=0; i<cantComentarios; i++){
        cout << "Id de comentario: "<< vecCom[i].getid() << " anio "<< vecCom[i].getFechaPublicacion().getAnio()<< endl;
        cout << "Legajo alumno: "<< vecCom[i].getlegajo()<< endl;
        cout << "Id foro: "<< vecCom[i].getIDForo()<< endl;
        cout << "Comentario: "<< vecCom[i].gettexto()<< endl;

        cout << " - - - - - - - - - - - " << endl;
    }

}



void Examen::crearComentario(){
    int id, leg, idF, idC;
    char tex[300];
    Fecha fe;
    int d,m,a;
    bool pos;

    do{
        cout << "Cargar id comentario: ";
        cin >> id;
        cout << "Cargar legajo alumno: ";
        cin >> leg;
        cout << "Cargar id de foro (1- Cafeter�a, 2- Foro de dudas, 3- Tareas, 4 - Grupos, 5- Desaf�os )";
        cin >>idF;
        pos = validarLegajo(leg,id,idF);
        if(pos==false){
        cout << "Error de validacion en datos suministrados" << endl;
        system("pause");
        }


    }while(pos==false);

    cout << "Cargar texto comentario: ";
    cin >> tex;
    cout << "Cargar fecha de publicacion: "<<endl;
    cout << "Dia: ";
    cin>>d;
    cout << "Mes: ";
    cin>>m;
    cout << "Anio: ";
    cin>>a;
    cout << "Cargar ID Comentario: ";
    cin >>idC;


    comentario obj;
    obj.setid(id);
    obj.setlegajo(leg);
    obj.setIDForo(idF);
    obj.settexto(tex);
    fe.setDia(d);
    fe.setMes(m);
    fe.setAnio(a);
    obj.setIDComentarioRespuesta(idC);

    obj.grabarenDisco();
}

void Examen::fullComentado(){
    comentarioArchivo com;

    int cantComentarios = com.getCantidad();

    comentario* vecCom = new comentario[cantComentarios];

    for(int i=0; i<cantComentarios; i++){
        vecCom[i] = com.leer(i);
    }

    int vecForo[5]{};

    for(int i=0; i<cantComentarios; i++){
        if(vecCom[i].getFechaPublicacion().getAnio()==2022){
            vecForo[vecCom[i].getIDForo()-1]++;
        }

    }

    int maxCan=0;
    int maxForo=0;

    for(int i=0; i<5; i++){

        if(vecForo[i]>maxCan){
            maxCan=vecForo[i];
            maxForo=i+1;
        }
    }

    cout << "Foro con mas comentarios en 2022: " << maxForo << endl;


}

void Examen::cortitaYAlPie(){

comentarioArchivo com;
int cantComentarios = com.getCantidad();
comentario* vecCom = new comentario[cantComentarios];
if(vecCom==nullptr){cout << "error en vec dinamico";}

    for(int i=0; i<cantComentarios; i++){
        vecCom[i] = com.leer(i);
    }

    const char vecComprador[200]{};

    for(int i=0; i<cantComentarios; i++){

        if(vecCom[i].getIDForo()==2){
            if(strcmp(vecCom[i].gettexto(),vecComprador)>0){
                cout << vecCom[i].getlegajo() << endl;
            }
        }
    }




}



bool validarLegajo(int leg, int id, int foro){

comentarioArchivo com;
int cantComentarios = com.getCantidad();
comentario* vecCom = new comentario[cantComentarios];
if(vecCom==nullptr){cout << "error en vec dinamico";}

    for(int i=0; i<cantComentarios; i++){
        vecCom[i] = com.leer(i);
    }


EstudiantesArchivo est;
int canEstudiantes = est.getCantidad();
Estudiante* vecEst = new Estudiante[canEstudiantes];
if(vecEst==nullptr){cout << "error en vec dinamico";}

    for(int x=0; x<canEstudiantes; x++){
        vecEst[x] = est.leer(x);
    }

int pos=0;;

    for(int x=0; x<canEstudiantes; x++){
        for(int y=0; y<cantComentarios; y++){
            if(vecEst[x].getLegajo()==leg){
                if(vecCom[y].getIDForo()==foro && vecCom[y].getid()==id){
                    return true;
                }
            }

        }
    }



}
