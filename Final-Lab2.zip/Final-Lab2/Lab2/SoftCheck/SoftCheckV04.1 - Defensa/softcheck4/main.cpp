#include <iostream>

using namespace std;
#include "menu.h"
int main()
{
    menu app;

    app.menuPrincipal();

    return 0;
}
