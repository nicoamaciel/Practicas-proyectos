///MACIEL NICOLAS legajo 24290
///PROGRA 2 - 3/10/22

#include <iostream>
#include <cstring>
#include <cstdlib>
using namespace std;

#include "clases_p.h"


/*
1-Generar un archivo con la cantidad de reservas que cada restaurante de la categor�a 2 tuvo el a�o pasado.
Cada registro debe tener el siguiente formato:

-   C�digo de restaurante,
-   nombre de restaurante,
-   cantidad de reservas del a�o pasado.

2- Informar el mes de este a�o con m�s cantidad de reservas.

*/

class cantidadReservas{
private:
    int codigoRestaurante;
    char nombreRestaurant[30];
    int cantReservas;

public:
    //Sets
    void setCodigoRestaurante(int cod){codigoRestaurante=cod;}
    void setNombreRestaurant(const char *nom){strcpy(nombreRestaurant,nom);}
    void setCantReservas(int cant){cantReservas=cant;}
    //Comportamiento

    bool grabarEnDisco();


};




//Prototipos





//Punto1

void buscarReservas();
    bool buscarAnio();
    int contarReservas(int cod);


//Punto2
void masReservas();
    void mostraMaxReservas(int *vec,int tam);



int main(){

masReservas();
;








return 0;
}


//Punto1
bool cantidadReservas::grabarEnDisco(){
        FILE *pCant;
        pCant = fopen("cantReservas.dat","ab");
        if(pCant==NULL){
            return false;
        }
        bool escribio = fwrite(this,sizeof(cantidadReservas),1, pCant);
        fclose(pCant);
        return escribio;


    }

void buscarReservas(){

Restaurante reg;
cantidadReservas obj;

int pos=0;

while(reg.leerDeDisco(pos)){
    if(buscarAnio()==true && reg.getCategoriaRestaurante()==2){
        obj.setNombreRestaurant(reg.getNombre());
        obj.setCodigoRestaurante(reg.getCodigoRestaurante());
        obj.setCantReservas(contarReservas(reg.getCodigoRestaurante()));

        obj.grabarEnDisco();

        }

    pos++;
    }

}

bool buscarAnio(){
Reserva reg;
int pos=0;
int const pasado=2021;

while(reg.leerDeDisco(pos)){

    if(reg.getFechaReserva().getAnio()==pasado){
        return true;
        }
        pos++;

    }

}


int contarReservas(int cod){
Reserva reg;
int pos=0;
int cant=0;

while(reg.leerDeDisco(pos)){
    if(reg.getCodigoRestaurante()==cod){
        cant++;
    }

    pos++;
}

return cant;

}

//Punto2
void masReservas(){

int vMeses[12]{};
Reserva reg;
int pos=0;
int const actual=2022;

while(reg.leerDeDisco(pos)){
    if(reg.getFechaReserva().getAnio()==actual){
        vMeses[reg.getFechaReserva().getMes()-1]++;
    }

    pos++;
}

mostraMaxReservas(vMeses,12);


}


void mostraMaxReservas(int *vec,int tam){

int maxReservas=0;
int mesMax=0;

for(int i=0; i<tam; i++){
    if(vec[i]>maxReservas){
        maxReservas=vec[i];
        mesMax=i+1;
    }

}
cout << "- - - - - - - - - - - - - - - - - - - - " << endl;
cout << "Mes con mas reservas: " << mesMax << endl;


}
