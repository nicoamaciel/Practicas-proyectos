#include <iostream>

using namespace std;
#include "botella.h"


//Constructor
botella::botella(float capacidad){
_capacidad=capacidad;
_ocupacion=0;
_tapada=false;
}

//Gets --->> Vaolores de retorno
float botella::getCapacidad(){
    return _capacidad;
}
float botella::getOcupacion(){
    return _ocupacion;
}
bool botella::getTapada(){
    return _tapada;
}

//Sets --->>

void botella::setCapacidad(float capacidad){
_capacidad=capacidad;
}
void botella::setOcupacion(float ocupacion){
if(ocupacion>0){
    _ocupacion=ocupacion;
}

}

void botella::setTapada(bool tapada){
_tapada=tapada;
}

//Comportamientos

void botella::destapar(){
    _tapada=0;

    if(_tapada==0){
    cout << "Botella destapada" << endl;
    }


}

void botella::tapar(){
    _tapada=1;

    if(_tapada==1){
    cout << "Botella tapada" << endl;
    }

}

void botella::llenar(float contenido){
    if(contenido>_ocupacion && _tapada==0){
        _ocupacion+=contenido;
    }
    else{
        cout << "Imposible llenar " << endl;
    }

}

void botella::vaciar(float contenido2){
    if(contenido2>0 && _tapada==0){
        _ocupacion-=contenido2;
    }
    else{
        cout << "Imposible vaciar " << endl;
    }


}

void botella::mostrar(){

cout << "Contendio de botella en lts: " << _ocupacion << endl;



}
