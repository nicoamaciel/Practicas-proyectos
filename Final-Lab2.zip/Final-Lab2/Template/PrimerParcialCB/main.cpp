#include <iostream>
using namespace std;

#include "PrimerParcial.h"

int main() {
    PrimerParcial obj;

    //obj.listarRecaudacion();
    cout<<endl;
    //obj.listarAlumnosNoMorosos();
    cout<<endl;
    //obj.soloUnCurso();
    cout<<endl;
    //obj.generarEstadistica();
    //obj.mostrarEstadisticas();
    cout<<endl;
    obj.cursosPremium(1030);

  return 0;
}
