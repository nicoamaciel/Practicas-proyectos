================================================================================================================
===============================================Ejemplo de baja==================================================
================================================================================================================

2-Dar de baja lógica en el archivo de asignaciones a los registros del año actual.
Listar el archivo omitiendo los registros dados de baja.

//Prototipos
void punto2();
    bool modificarArchivo(Asignacion reg, int pos);

================================================================================================================


void punto2(){

Asignacion reg;
int pos=0;

while(reg.leerDeDisco(pos)){
    if(reg.getFechaAsignacion().getAnio()==2021){
        reg.setEstado(false);
        modificarArchivo(reg,pos);
    }
    pos++;
 }

}

bool modificarArchivo(Asignacion reg, int pos){
FILE *p = fopen("asignaciones.dat","rb+");
if(p==NULL){return false;}

fseek(p,sizeof(Asignacion)*pos,0);
bool escribio = fwrite(&reg,sizeof reg,1,p);
fclose(p);
return escribio;

}