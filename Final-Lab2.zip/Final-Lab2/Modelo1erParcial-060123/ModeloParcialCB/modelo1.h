#ifndef MODELO1_H_INCLUDED
#define MODELO1_H_INCLUDED
/*
1-Mostrar legajo, apellidos y nombres de aquellos estudiantes que no hayan
rendido ning�n examen en el a�o 2022.

2-Por cada alumno listar legajo, apellidos, nombres, cantidad de ex�menes
aprobados (nota >=6) y cantidad de ex�menes desaprobados. Utilizar el
siguiente formato: ver pdf

3-Listar la cantidad de alumnos que hayan rendido examen m�s de una vez
para la misma materia entre los a�os 2018 y 2022 (ambos a�os inclusive).
Aclaraci�n: Los IDMateria son valores entre 1 y 60

*/




class modeloParcial{

private:

public:
    void punto1();
    void punto2();
    void punto3();



};



#endif // MODELO1_H_INCLUDED
