#include <iostream>
#include <cstdlib>
using namespace std;

#include "Estudiante.h"
#include "EstudiantesArchivo.h"
#include "Pago.h"
#include "PagosArchivo.h"
#include "PrimerParcial.h"
#include "estadisticas.h"

void PrimerParcial::listarRecaudacion(){

PagosArchivo pag;
int cantPago=0;

cantPago = pag.getCantidad();
Pago *vecPag = new Pago [cantPago];

for (int i=0; i<cantPago; i++){
    vecPag[i] = pag.leer(i);
}

float vecCurso[10]{};

for (int j=0; j<cantPago; j++){
    if(vecPag[j].getFecha().getDia()>=10 && vecPag[j].getFecha().getMes()>=5 && vecPag[j].getFecha().getAnio()>=2020){
        vecCurso[vecPag[j].getIdCurso()-1]+=vecPag[j].getMonto();
    }
}


for(int i=0; i<10; i++){
    cout << " Cursos: " << i+1 << " Recaudacion: " << vecCurso[i] << endl;
}




delete []vecPag;

}



void PrimerParcial::soloUnCurso(){

EstudiantesArchivo estu;
int cantEstu=0;

cantEstu = estu.getCantidad();

Estudiante *vecEstu = new Estudiante [cantEstu];


for (int i=0; i<cantEstu; i++){
    vecEstu[i] = estu.leer(i);
}


PagosArchivo pag;
int cantPago=0;

cantPago = pag.getCantidad();
Pago *vecPag = new Pago [cantPago];

for (int i=0; i<cantPago; i++){
    vecPag[i] = pag.leer(i);
}




for (int i=0; i<cantEstu; i++){
    int vCursos[10]{};
    for (int j=0; j<cantPago; j++){
        if(vecEstu[i].getLegajo()==vecPag[j].getLegajo() && vecPag[j].getAnio()== 2021 ){
        vCursos[vecPag[j].getIdCurso()-1]=1;
        }
    }

    int cant=0;
    for(int x=0; x<10; x++){
        if(vCursos[x]==1){
            cant += vCursos[x];
        }

    }

    if(cant==1){
        cout << " Legajo: " << vecEstu[i].getLegajo() << endl;
    }

}





delete []vecPag;
delete []vecEstu;

}


void PrimerParcial::generarEstadistica(){

PagosArchivo obj;
int cantPagos = obj.getCantidad();

Pago *vPag = new Pago[cantPagos];

for(int i=0; i<cantPagos; i++){
    vPag[i] = obj.leer(i);
    }
int anioMax=0; int anioMin=0;

for(int x=0; x<cantPagos; x++){
    if(x==0){
        anioMax = anioMin = vPag[x].getFecha().getAnio();
    }

    if(vPag[x].getFecha().getAnio()>anioMax){
        anioMax = vPag[x].getFecha().getAnio();
    }

    if(vPag[x].getFecha().getAnio()<anioMin){
        anioMin = vPag[x].getFecha().getAnio();
    }

}

estadisticas *anios = new estadisticas[anioMax - anioMin+1];

for(int x=0; x<anioMax-anioMin; x++){
    anios[x].setAnio(x+anioMin);
    anios[x].setRecaudacion(0);
}

for(int x=0; x<cantPagos; x++){
    anios[vPag[x].getFecha().getAnio()-anioMin].add(vPag[x].getMonto());
    }


    FILE* pFile;
    pFile = fopen("estadisticas.dat","wb");
    fwrite(anios, sizeof (estadisticas), anioMax-anioMin+1, pFile);
    fclose(pFile);


}



void PrimerParcial::mostraEstadistica(){
FILE *pFile;
pFile = fopen("estadisticas.dat","rb");
estadisticas es;
while(fread(&es, sizeof (estadisticas),1,pFile)==1){
    es.mostrarEstadistica();
}


}





/*
6) Crear un m�todo llamado  cursosPremium  que reciba el legajo de un estudiante y
muestre el id del curso al que realiz� el mayor pago individual (en caso de haber m�s de uno,
muestre todos los que cumplan esa condici�n).
(1 Punto)
*/

void PrimerParcial::cursosPremium(int leg){

PagosArchivo pag;
int cantPago=0;

cantPago = pag.getCantidad();
Pago *vecPag = new Pago [cantPago];

for (int i=0; i<cantPago; i++){
    vecPag[i] = pag.leer(i);
}

float maximo=0;
for (int i=0; i<cantPago; i++){
    if(leg=vecPag[i].getLegajo() &&)
    }





delete []vecPag;
delete []vecEstu;

}

