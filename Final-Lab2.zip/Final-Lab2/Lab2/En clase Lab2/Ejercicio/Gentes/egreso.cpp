#include <iostream>

using namespace std;

#include "egreso.h"


    //Gets
    int egreso::getDni(){
        return _Dni;
    }
    int egreso::getHoraEgreso(){
        return _HoraEgreso;
    }

    //Sets
    void egreso::setDni(int dni){
        _Dni=dni;
    }
    void egreso::setHoraEgreso(int hora){
        _HoraEgreso=hora;

    }

    //Comportamiento

    void egreso::cargarEgreso(){
    int dni, hora;

    cout << "Ingrese dni: ";
    cin >> dni;
    cout << "Ingrese hora (00hs a 24hs exactas): ";
    cin >> hora;
    cout << "----------------------" << endl;

    setDni(dni);
    setHoraEgreso(hora);

    }
