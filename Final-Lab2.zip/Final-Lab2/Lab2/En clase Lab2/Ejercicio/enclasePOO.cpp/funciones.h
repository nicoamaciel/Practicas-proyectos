#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

/*
Propiedades que vamos a usar del objeto:
litros y nombres
Metodos (Acciones que va a realizar ){
extraer y modificar cantidad de litros
}
*/

class bidones{
private:///Solo es accesible desde dentro de la clase
    float _litros;///Propiedades de la clase ENCAPSULAMIENTO
    string _nombre;
public:
    ///constructor --->> Permite inicializar con valores
    bidones(float capacidad, string nom);

    void extraerLitros(float cantidad);
    float getLitros();
    string getNombres();


};





#endif // FUNCIONES_H_INCLUDED
