
===================================================================================================================================
============================================== Punto dos de examen progra2====================================================
===================================================================================================================================

2- Informar el mes de este año con más cantidad de reservas.



void punto2();
    void mostrarMayorCant(int *vMeses, int cant);

===================================================================================================================================
Mostar siempre en main!

int main (){
cout << "- - - - - - - - " << endl;
punto2();
cout << "- - - - - - - - " << endl;
return 0;
}






===================================================================================================================================
void punto2(){
Reserva reg;
int vMeses[12]{};
int pos=0;

while(reg.leerDeDisco(pos)){
    if(reg.getFechaReserva().getAnio()==2022){
        vMeses[reg.getFechaReserva().getMes()-1]++;
    }

    pos++;
}

mostrarMayorCant(vMeses,12);

}


void mostrarMayorCant(int *vMeses,int cant){

int maxCant=0;
int maxMes=0;

for(int i=0; i<cant; i++){

    if(vMeses[i]>maxCant){
        maxCant=vMeses[i];
        maxMes=i+1;
    }


}

cout << endl << "Mes con mayor cantidad de reservas: " << maxMes << endl;

}