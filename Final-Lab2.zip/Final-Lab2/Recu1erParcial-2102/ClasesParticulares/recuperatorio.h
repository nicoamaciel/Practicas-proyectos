#ifndef RECUPERATORIO_H_INCLUDED
#define RECUPERATORIO_H_INCLUDED

class Recuperatorio{

private:

public:
    void cursosConMayorAyuda();
    void alumnosConPocaAyuda();
    void generarEstadisticasAyuda();
    void mostrarEstadisticas();
    void nuncaRecibioAyuda(int leg);




};

#endif // RECUPERATORIO_H_INCLUDED
