/*
Hacer una funci�n que reciba como par�metros un
vector de enteros y un n�mero entero que indica la cantidad de componentes del vector,
 y que devuelva el valor m�nimo contenido en ese vector.

*/


#include <iostream>
using namespace std;

///Declaracion de funcion

void componentesVector( int *vPrueba, int CONTENIDO);

int main(){

int const CONTENIDO=10;

int vPrueba[CONTENIDO]={10,3,7,9,10,2,11,25,15,9};
componentesVector(vPrueba, CONTENIDO);

return 0;
}


///Definicion de funcion
void componentesVector(int *vPrueba, int CONTENIDO){
    int minimo=0;

    for (int x=0; x<10; x++){
        if(x==0){
            minimo=vPrueba[x];
        }

        if(vPrueba[x]<minimo){
            minimo=vPrueba[x];
        }
    }

    cout << minimo << endl;




}


