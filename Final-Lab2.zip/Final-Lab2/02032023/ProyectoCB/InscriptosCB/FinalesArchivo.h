#ifndef FINALESARCHIVO_H_INCLUDED
#define FINALESARCHIVO_H_INCLUDED

#include "ExameneFinal.h"
class finalesArchivo
{
public:
  ExameneFinal leer(int nroRegistro);
  int getCantidad();
};


#endif // FINALESARCHIVO_H_INCLUDED
