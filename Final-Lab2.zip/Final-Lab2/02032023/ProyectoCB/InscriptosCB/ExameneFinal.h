#ifndef EXAMENEFINAL_H_INCLUDED
#define EXAMENEFINAL_H_INCLUDED

#include "Fecha.h"

class ExameneFinal{
private:
    int _id; //(Autonumerico)
	int _Legajoalumno; //que realiza el examen
	char _Observacion[200]; //que realiza el profesor respecto al examen
	Fecha _fechaExamen;
	int _IDMateria;//100-109
	int _Nota;//1-10

public:
    int getId();
	int getLegajo();
	const char *getObservacion(){return _Observacion;}
	Fecha getFechaExamen();
	int getIDMateria();
	int getNota();

	void setId(int id);
	void setLegajo(int leg);
	void setObservacion(const char *obs);
	void setFechaExamen(Fecha fe);
	void setIDMateria(int idMat);
    void setNota(int nota);

	void cargarExamenes();
	int grabarenDisco();


};

#endif // EXAMENEFINAL_H_INCLUDED
