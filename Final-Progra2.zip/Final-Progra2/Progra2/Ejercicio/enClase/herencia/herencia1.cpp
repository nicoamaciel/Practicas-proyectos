///Ejercicio:
///Autor:DEK
///Fecha:
///Comentario:

# include<iostream>
# include<cstdlib>
# include<cstring>

using namespace std;

void cargarCadena(char *pal, int tam){
  int i;
  fflush(stdin);
  for(i=0;i<tam;i++){
      pal[i]=cin.get();
	  if(pal[i]=='\n') break;
	  }
  pal[i]='\0';
  fflush(stdin);
}


class Fecha{
private:
    int dia, mes, anio;
public:
    void setDia(int d){dia=d;}
    void setMes(int d){mes=d;}
    void setAnio(int d){anio=d;}
    int getDia(){return dia;}
    int getMes(){return mes;}
    int getAnio(){return anio;}
    void Cargar(){
        cout<<"DIA: ";
        cin>>dia;
        cout<<"MES: ";
        cin>>mes;
        cout<<"ANIO: ";
        cin>>anio;
    }
    void Mostrar(){
        cout<<dia<<"/"<<mes<<"/"<<anio<<endl;
    }

};

class Persona{
protected:///mantiene la privacidad de lo que est� definido, pero permite el acceso completo a las clases derivadas
    int DNI;
    char nombre[30];
    char apellido[30];
    char email[30];
    Fecha fechaNacimiento;///composici�n: se usa un OBJETO de una clase como
                          ///  propiedad de otra clase. CLASE TIENE OBJETO DE OTRA CLASE
public:
    void setDNI(int d){DNI=d;}
    void setNombre(const char *n){strcpy(nombre, n);}
    void setApellido(const char *n){strcpy(apellido, n);}
    void setFechaNacimiento(Fecha aux){fechaNacimiento=aux;}

    const char *getNombre(){return nombre;}
    const char *getApellido(){return apellido;}
    int getDNI(){return DNI;}
    Fecha getFechaNacimiento(){return fechaNacimiento;}

    void Cargar();
    void Mostrar();
};
///clases bases abstractas: clases que desarrollamos para hacer otras clases no para declarar objetos.

void Persona::Cargar(){
    cout<<"DNI: ";
    cin>>DNI;
    cout<<"NOMBRE: ";
    cargarCadena(nombre, 29);
    cout<<"APELLIDO: ";
    cargarCadena(apellido, 29);
    cout<<"EMAIL: ";
    cargarCadena(email, 29);
    cout<<"FECHA DE NACIMIENTO: ";
    fechaNacimiento.Cargar();///estoy adentro de la clase Persona, no de la clase Fecha
                                ///por lo tanto tengo que usar los gets y sets definidos
}                                ///en la clase de la cual proviene el objeto

void Persona::Mostrar(){
    cout<<"DNI: "<<DNI<<endl;
    cout<<"NOMBRE: "<<nombre<<endl;
    cout<<"APELLIDO: "<<apellido<<endl;
    cout<<"EMAIL: "<<email<<endl;
    cout<<"FECHA DE NACIMIENTO: ";
    fechaNacimiento.Mostrar();///estoy adentro de la clase Persona, no de la clase Fecha
                                ///por lo tanto tengo que usar los gets y sets definidos
}

class Alumno: public Persona{
private:
    int legajoAlumno;
    int codigoCarrera;

public:
    void Cargar();
    void Mostrar();

    void setLegajo(int l){legajoAlumno=l;}
    void setCodigoCarrera(int cc){codigoCarrera=cc;}

    int getLegajo(){return legajoAlumno;}
    int getCodigoCarrera(){return codigoCarrera;}

    void modificarDNI(int d){DNI=d;}

};

void Alumno::Cargar(){
    Persona::Cargar();
    cout<<"LEGAJO: ";
    cin>>legajoAlumno;
    cout<<"CARRERA: ";
    cin>>codigoCarrera;
}

void Alumno::Mostrar(){
    Persona::Mostrar();
    cout<<"LEGAJO: "<<legajoAlumno<<endl;
    cout<<"CARRERA: "<<codigoCarrera<<endl;
}

class Docente: public Persona{
private:
    int legajoDocente;
    int cargo;
    Fecha fechaIngreso;

public:
    //Set
    void setLegajoDocente(int l){legajoDocente=l;}
    void setCargo(int c){cargo=c;}
    void setFechaIngreso(Fecha aux){fechaIngreso=aux;}

    //Get
    int getLegajoDocente(){return legajoDocente;}
    int getCargo(){return cargo;}
    Fecha getFechaIngreso(){return fechaIngreso;}


    //Comportamiento
    void CargarDocente();
    void MostrarDocente();


};

void Docente::CargarDocente(){
    Persona::Cargar();
    cout<<"LEGAJO DOCENTE: ";
    cin>>legajoDocente;
    cout<<"CARGO(ENTERO): ";
    cin>>cargo;
    cout<<"FECHA DE INGRESO: ";
    fechaIngreso.Cargar();

}

void Docente::MostrarDocente(){
    Persona::Mostrar();
    cout<<"LEGAJO DOCENTE: "<<legajoDocente<<endl;
    cout<<"CARGO : "<< cargo<<endl;
    cout<<"FECHA DE INGRESO: ";
    fechaIngreso.Mostrar();
}




int main(){
    Docente obj;
    obj.CargarDocente();
    cout<<endl;
    obj.MostrarDocente();


	cout<<endl;
	system("pause");
	return 0;
}
