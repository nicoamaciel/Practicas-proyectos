#ifndef PRIMERPARCIAL_H_INCLUDED
#define PRIMERPARCIAL_H_INCLUDED

class primerParcial{

public:
    void listarRecaudacion();
        int buscarCurso(int curso);
    void listarAlumnosNoMorosos();
    void soloUnCurso();
        int unoSolo(int leg);
    void generarEstadistica();
        int grabarEnEstadistica();
    void mostrarEstadisticas();
        void mostrar();



};


class estadistica{
    private:
        int _anioEstadistica;
        int _recaudacionEstadistica;
    public:
        //gets
        int getAnioEstadistica(){return _anioEstadistica;}
        int geTrecaudacionEstadistica(){return _recaudacionEstadistica;}
        //sets
        void setAnioEstadistica(int a){_anioEstadistica=a;}
        void seTrecaudacionEstadistica(int r){_recaudacionEstadistica=r;}

};




#endif // PRIMERPARCIAL_H_INCLUDED
