#include "Pais.h"
#include <cstring>
#include <cstdio>
#include <iostream>
using namespace std;



void Pais::mostrar(){
    cout << _codigo << " " << _codigo2 << " " << _nombre << " " << _continente << " " << _superficie << " ";
    cout << _poblacion << " " << _independencia << " " << _expectativaDeVida << " " << _capital << endl;
}
void Pais::setCodigo(const char *codigo){
    strcpy(_codigo, codigo);
}
void Pais::setCodigo2(const char *codigo2){
    strcpy(_codigo2, codigo2);
}
void Pais::setNombre(const char *nombre){
    strcpy(_nombre, nombre);
}
void Pais::setContinente(const char *continente){
    strcpy(_continente, continente);
}
void Pais::setSuperficie(float superficie){
    _superficie = superficie;
}
void Pais::setPoblacion(int poblacion){
    _poblacion = poblacion;
}
void Pais::setIndependencia(short independencia){
    _independencia = independencia;
}
void Pais::setExpectativaDeVida(float expectativa){
    _expectativaDeVida = expectativa;
}
void Pais::setIDCapital(int IDCapital){
    _capital = IDCapital;
}
char * Pais::getCodigo(){
    return _codigo;
}
char * Pais::getCodigo2(){
    return _codigo2;
}
char * Pais::getNombre(){
    return _nombre;
}
char * Pais::getContinente(){
    return _continente;
}
float Pais::getSuperficie(){
    return _superficie;
}
int Pais::getPoblacion(){
    return _poblacion;
}
short Pais::getIndependencia(){
    return _independencia;
}
float Pais::getExpectativaDeVida(){
    return _expectativaDeVida;
}
int Pais::getIDCapital(){
    return _capital;
}

int cantidadPaises(){
int cantidad=0;
FILE *pPaises;
pPaises = fopen("paises.dat","rb");
if(pPaises==nullptr){return -1;}

int cant=0;
fseek(pPaises,0,SEEK_END);
cantidad = ftell(pPaises)/sizeof(Pais);
fclose(pPaises);
return cantidad;


}
bool existePais(char *cod){
Pais reg;
FILE *Pfile = fopen("paises.dat", "rb");
if(Pfile==nullptr){return false;}
bool punto=0;

 while(fread(&reg, sizeof (Pais),1, Pfile)==1){
       punto=strcmp(reg.getCodigo(),cod);
       if(punto==0){
        cout << reg.getNombre() << endl;
        return true;
       }
    }
}

void leerPaises(){
Pais reg;
FILE *Pfile = fopen("paises.dat", "rb");
if(Pfile==nullptr){"Error de lectura";}
bool punto=0;

 while(fread(&reg, sizeof (Pais),1, Pfile)==1){
       reg.mostrar();
       cout << endl;
    }
}

bool guardarPais(){
Pais reg;
FILE *pPais = fopen("paises.dat","ab");
if(pPais==nullptr){return false;}
bool escribio = fwrite(&reg,sizeof(Pais),1,pPais);
fclose(pPais);
return escribio;

}

void cargarPais(){
Pais obj;
char cod[4], cod2[3], nom[45], cont[45];
float sup, exp;
int pob,idCap;
short inde;

cout << "Cargar cod: ";
cin >>cod;
cout << "Cargar cod2: ";
cin >>cod2;
cout << "Cargar nom: ";
cin >>nom;
cout << "Cargar continente: ";
cin >>cont;
cout << "Cargar superfice ";
cin >>sup;
cout <<"Cargar expectativa de vidad: ";
cin >>exp;
cout <<"Cargar poblacion: ";
cin >>pob;
cout <<"Cargar id de capital: ";
cin >> idCap;
cout <<"Cargar independencia: ";
cin >> inde;

obj.setCodigo(cod);
obj.setCodigo2(cod2);
obj.setNombre(nom);
obj.setContinente(cont);
obj.setSuperficie(sup);
obj.setPoblacion(pob);
obj.setIndependencia(exp);
obj.setExpectativaDeVida(exp);
obj.setIDCapital(idCap);


}


void nombreSuperficie(){
Pais reg;
FILE *Pfile = fopen("paises.dat", "rb");
if(Pfile==nullptr){"Error de lectura";}
bool punto=0;

 while(fread(&reg, sizeof (Pais),1, Pfile)==1){
    cout << "Nombre de pais: " << reg.getNombre() << endl;
    cout << "Superfiece: " << reg.getSuperficie() << endl;
    cout << endl;
    }

}


