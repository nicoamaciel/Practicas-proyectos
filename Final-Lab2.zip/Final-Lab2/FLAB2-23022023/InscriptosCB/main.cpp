#include <iostream>
using namespace std;

#include "Comentarios.h"
#include "Examen.h"




int main() {


//int cant, archCom=0;

//cout << "Ingresar cantidad de comentarios a cargar: ";
//cin >> cant;
//
//comentario *objCom = new comentario[cant];
//
//
//    for(int i=0; i<cant; i++){
//        objCom[i].cargarComentario();
//        archCom = objCom[i].grabarenDisco();
//        if(archCom == 1){
//        cout << "Archivo cargado" << endl;
//        }
//    }
//
//delete []objCom;
//




    Examen obj;
    obj.leerComentarios();
    cout << endl;

    //obj.fullComentado();
    //obj.crearComentario();
    obj.cortitaYAlPie();

	return 0;
}
