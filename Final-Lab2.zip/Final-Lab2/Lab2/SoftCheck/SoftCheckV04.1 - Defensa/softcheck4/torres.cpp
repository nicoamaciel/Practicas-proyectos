#include <iostream>
#include <cstdlib>
#include <cstring>
#include <fstream>

using namespace std;
#include "torres.h"
#include "fecha.h"


    int torres::getEquiposxtorre(){return _Equiposxtorre;}
    bool torres::getEstado(){return _Estado;}

///Sets

    void torres::setNombreTorre (const char *n){
        strcpy (_NombreTorre,n);
    }
    void torres::setEquiposxtorre(int equi){_Equiposxtorre=equi;}

    void torres::setEstado(bool est){_Estado=est;}

///Comportamientos

    void torres::cargarTorres(){
        char tor[20];
        bool est;
        int equi, pos;

        do{
        cout << "Cargar nombre de torre: ";
        cin >> tor;
        pos = buscarTorre(tor);
        if(pos>=0){
            cout << "Torre ya registarada con anterioridad" << endl;
            system("pause");
            }
            else{
                setNombreTorre(tor);
            }
        }while(pos>=0);

        cout << "Equipos monitoreados: ";
        cin >> equi;

        est = true;


        setEquiposxtorre(equi);
        setEstado(est);

    }
    void torres::mostrarTorres(){
        if(_Estado == true){
        cout << getNombreTorre() << "              |   " << getEquiposxtorre() << "      |   " ;
        cout << endl << endl;
        }


    }

    void verTorres(){
        cout << " NOMBRE TORRE   " << " |  " << " EQUIPOS POR TORRE " <<  " | "  <<endl;
        cout << "------------------------------------"<< endl;
    }



    int torres::grabarenDisco(){

    FILE *pTorres;
    pTorres = fopen("torres.dat", "ab");
    if(pTorres == NULL){
        cout << "ERROR DE ARCHIVO"<< endl;
        system("pause");
        return -1;
        }

    int escribio = fwrite(this, sizeof(torres), 1, pTorres);
    fclose(pTorres);
    return escribio;
    }

    int torres::leerdeDisco(int pos){
    FILE *pTorres;
    int leyo;
    pTorres = fopen("torres.dat", "rb");
        if(pTorres == NULL){
            cout << "ERROR DE ARCHIVO"<< endl;
            system("pause");
            return -1;
        }
    fseek(pTorres, pos*sizeof(torres),0);
    leyo = fread(this, sizeof(torres),1,pTorres);
    fclose(pTorres);
    return leyo;
    }

    bool torres::modificarEnDisco(int pos){
    FILE *p;
    p=fopen("torres.dat","rb+");
    if(p==NULL) return false;
    fseek(p, pos * sizeof(torres), 0);
    bool escribio=fwrite(this, sizeof (torres), 1, p);
    fclose(p);
    return escribio;
    }

    int buscarTorre(char *tor){
        torres reg;
        int pos=0;

        while(reg.leerdeDisco(pos)){
            if(strcmp(reg.getNombreTorre(),tor)==0){
                return pos;
            }
            pos++;
        }
        return -1;

    }

    bool bajaTorre(){
        torres obj;
        int pos;
        char tor[20];
        cout << "Cargar nombre de torre: ";
        cin >> tor;
        pos = buscarTorre(tor);
        if(pos==-1){
        cout << "Torre no existe en el archivo"<< endl;
        system("pause");
        return false;
        }
        obj.leerdeDisco(pos);
        if(obj.getEstado()==false){
        cout << "Torre ya fue dada de baja"<< endl;
        system("pause");
        return false;
        }

        obj.leerdeDisco(pos);
        obj.setEstado(false);
        obj.modificarEnDisco(pos);

    }

    int torres::bkTorres(){
        FILE *pTorres;
        pTorres = fopen("BKP-torres.dat","wb");
        if(pTorres==NULL){
            cout << "Error en archivo";
            return -1;
        }

        int escribio = fwrite(this, sizeof(torres), 1, pTorres);
        fclose(pTorres);
        return escribio;


    }



