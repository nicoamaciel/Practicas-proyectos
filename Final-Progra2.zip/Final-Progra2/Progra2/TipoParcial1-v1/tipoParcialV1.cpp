/*
A) Calcular e informar la cantidad de municipios de cada
B) Calcular e informar los nombres de las empresas de m�s de 200 empleados.
C) Generar un archivo con las empresas esenciales con el siguiente formato:
    N�mero de empresa, nombre, cantidad de empleados (agregar un campo para el estado)


D) Calcular e informar la cantidad de empleados por cada una de las categor�as (entre todas las empresas)
E) Calcular e informar el municipio con mayor cantidad de empresas esenciales.
F) Generar un archivo con los municipios que tengan una relaci�n poblaci�n/cantidad total de empresas menor a 1000.
El formato del nuevo archivo debe ser el mismo que el formato del archivo de municipios.
*/



#include <iostream>
using namespace std;
#include "tipoParcialV1.h"


//PuntoC
class esencial{
    private:
        int _numeroEmpresa;
        char _nombreEmpresa[30];
        int _cantidadEmpleados;
        bool _estado;


    public:
        //Gets
        int getNumeroEmpresa(){return _numeroEmpresa;}
        const char *getNombreEmpresa(){return _nombreEmpresa;}
        int getCantidadEmpleados(){return _cantidadEmpleados;}
        bool getEstado(){return _estado;}
        //Sets
        void setNumeroEmpresa(int num){_numeroEmpresa=num;}
        void setNombreEmpresa(const char *nom){strcpy(_nombreEmpresa,nom);}
        void setCantidadEmpleados(int cant){_cantidadEmpleados=cant;}
        void setEstado(bool est){ _estado=est;}

        //Comportamientos
        void mostrar();
        bool grabarEnDisco();
        bool leerDeDisco(int);


    };





///Prototipos
void puntoA();
    void mostrarVector(int*vec,int tam);
void puntoB();
void puntoC();
    bool esEsencial(int cat);
void puntoD();
   void mostrarPuntoD(int*v,int tam);
void puntoE();
    int buscarEsencial(int cate);
    void mostrarPuntoE(int *vMun,int tam);



int main(){
int opc, posCat=0, posEmp=0, posMuni=0, pos1=0;
//Empresa reg[6];
//Municipio reg2[6];
Empresa obj;
esencial reg;




    while(true){
        system("cls");
        cout<<"-------MENU PRINCIPAL -------"<<endl;
        cout<<"1.   CARGAR EMPRESA"<<endl;
        cout<<"2.   CARGAR MUNICIPIO"<<endl;
        cout<<"3.   CARGAR CATEGORIA "<<endl;
        cout<<"4.   PUNTO A "<<endl;
        cout<<"5.   PUNTO B "<<endl;
        cout<<"6.   PUNTO C "<<endl;
        cout<<"7.   PUNTO D "<<endl;
        cout<<"8.   PUNTO E "<<endl;
        cout<<"9.   PUNTO F "<<endl;
        cout<<"0.   SALIR"<<endl;
        cout<<"-----------------------------"<<endl<<endl;
        cout<<"OPCION: ";
        cin>>opc;
        system("cls");
        switch(opc){
            case 1:

//                for (int i=0; i<6; i++){
//                   reg[i].Cargar();
//                    if(reg[i].grabarEnDisco()){
//                        cout << "Empresa cargada con exito!" << endl;
//                    }
//
//                }


                    break;
            case 2:
//                for (int i=0; i<6; i++){
//                   reg2[i].Cargar();
//                    if(reg2[i].grabarEnDisco()){
//                        cout << "Municipio cargado con exito!" << endl;
//                    }
//
//                }






                    break;
            case 3:
//                for (int i=0; i<6; i++){
//                    obj[i].Cargar();
//                    if(obj[i].grabarEnDisco()){
//                        cout << "Categoria cargada con exito!" << endl;
//                    }
//
//                }





                    break;
            case 4:
                    puntoA();


                    break;
            case 5:
                    puntoB();

                    break;
            case 6:

                    puntoC();

//                    while(obj.leerDeDisco(pos1++)){
//                    obj.Mostrar();
//                    cout << endl;
//                    }

                    break;
            case 7:
                    puntoD();
                    break;
            case 8:
                    puntoE();
                    break;
            case 9:
                    break;



            case 0: return 0;
                    break;
        }
        system("pause");

    }

	cout<<endl;



return 0;
}

void puntoA(){
int vSec[9]={0};
Municipio reg;
int pos=0;

while(reg.leerDeDisco(pos)){
    vSec[reg.getSeccion()-1]++;
    pos++;
}

mostrarVector(vSec,9);

}

void mostrarVector(int *vec,int tam){
    cout << "Seccion " << " | " << " Municipio " <<endl;

    for(int i=0; i<tam; i++){
        cout<< i+1 << "        |   "<<vec[i] << endl;
    }

}

void puntoB(){
Empresa reg;

int pos=0;

while(reg.leerDeDisco(pos)){
    if(reg.getCantidadEmpleados()>200){
        cout << reg.getNombreEmpresa() << endl;
    }
    pos++;
}


}

//PuntoC
void esencial::mostrar(){
        cout << "Numero de empresa: " << getNumeroEmpresa()<< endl;
        cout << "Nombre empresea: " << getNombreEmpresa()<< endl;
        cout << "Cantidad empleados: " << getCantidadEmpleados() << endl;



    }
bool esencial::grabarEnDisco(){
        FILE *pE;
        pE = fopen("esencial.dat","ab");
        if(pE==NULL){
            return false;
        }
        bool escribio = fwrite(this,sizeof(esencial),1,pE);
        fclose(pE);
        return escribio;


    }

bool esencial::leerDeDisco(int pos){
        bool leyo;
        FILE *pE;
        pE= fopen("esencial.dat","rb");
        if(pE==NULL){
            return false;
        }
        fseek(pE,pos*sizeof(esencial),0);
        leyo = fread(this,sizeof(esencial),1,pE);
        fclose(pE);
        return leyo;



    }

void puntoC(){
esencial reg;
Empresa obj;

int pos=0;

while(obj.leerDeDisco(pos)){
    if(esEsencial(obj.getCategoria())){
        reg.setNumeroEmpresa(obj.getNumeroEmpresa());
        reg.setNombreEmpresa(obj.getNombreEmpresa());
        reg.setCantidadEmpleados(obj.getCantidadEmpleados());

        reg.grabarEnDisco();
        }

    pos++;
    }
}





bool esEsencial(int cat){

Categoria reg;
int pos=0;
while(reg.leerDeDisco(pos)){
    if(cat==reg.getNumeroCategoria()){
        return true;
    }
    return false;
    pos++;
    }



}

void puntoD(){
int vCatego[80]={0};
Empresa obj;
int pos=0;

while(obj.leerDeDisco(pos)){
    vCatego[obj.getCategoria()-1]+=obj.getCantidadEmpleados();

    pos++;
}

mostrarPuntoD(vCatego,80);



}

void mostrarPuntoD(int *vCatego,int tam){
    cout << "Categoria " << " | " << " CantEmpleados " <<endl;

    for(int i=0; i<tam; i++){
        if(vCatego[i]>0){
        cout<< i+1 << "        |   "<<vCatego[i] << endl;
        }
    }
}

void puntoE(){
int vMuni[135]={0};
Empresa obj;
int esencial=0;


int pos=0;

while (obj.leerDeDisco(pos)){
    esencial = buscarEsencial(obj.getCategoria());
    if(esencial>0)
    {
    vMuni[obj.getMunicipio()-1]+=esencial;
    }




pos++;

}

mostrarPuntoE(vMuni,135);
}

int buscarEsencial(int cate){

Categoria reg;
int pos=0;

while(reg.leerDeDisco(pos)){
   if(cate==reg.getNumeroCategoria()){
    return reg.getEsencial();
   }


   pos++;
}


}


void mostrarPuntoE(int *vMun,int tam){
    int mayor=0;

    for(int i=0; i<tam; i++){
        if(vMun[i]>0 ){
            if(vMun[i]>mayor){
                mayor=vMun[i];
            }


        }

    }

    cout<< "Municipio maximo esencial: "<< mayor<< endl;
}
