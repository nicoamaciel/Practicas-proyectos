///MACIEL NICOLAS legajo 24290
///PROGRA 2 Final - 12/12/22

#include <iostream>
#include <cstring>
#include <cstdlib>
using namespace std;



/*

Se pide el desarrollo de un programa para:
a) Generar un archivo nuevo con el siguiente formato de registro:
ID jugador, nombre y apellido jugador y cantidad de partidos jugados (3 puntos).

b) Sabiendo que el a�o de nacimiento del jugador m�s viejo es 1982 y el del jugador m�s joven es 2004,
informar el a�o en el que nacieron m�s jugadores (3 puntos).






*/

class partidosJugados{
private:
    int IDjugador;
    char nombre[50];
    char apellido[50];
    int cantPartidosJugados;

public:
    //Sets
    void setIDjugador(int id){IDjugador=id;}
    void setNombre(const char *nomb){strcpy(nombre,nomb);}
    void setApellido(const char *ape){strcpy(apellido,ape);}
    void setCantPartidosJugados(int cant){cantPartidosJugados=cant;}


    //Comportamiento

    bool grabarEnDisco();


};

//Prototipos
//Punto1
void buscarJugados();
    int contarPatidos(int idJugador);

//Punto2

void anioMasJugadores();
    void mostrarMayorAnio(int *vAnios,int cant)



int main(){




return 0;
}



//Punto1
bool partidosJugados::grabarEnDisco(){
    FILE *pJugados;
    pJugados = fopen("cantJugados.dat","ab");
    if(pJugados==NULL){
    return false;
    }
    bool escribio = fwrite(this,sizeof(partidosJugados),1, pJugados);
    fclose(pJugados);
    return escribio;
}


void buscarJugados(){
Jugador reg;
partidosJugados obj;

int pos=0;

while(reg.leerDeDisco(pos)){
    if(contarPatidos(reg.getIDjugador())>0){
        obj.setIDjugador(reg.getIDjugador());
        obj.setNombre(reg.getNombre());
        obj.setApellido(reg.getApellido());
        obj.setCantPartidosJugados(contarPartidos(reg.getIDjugador()));

        obj.grabarEnDisco();
        }

    pos++;
    }


}


int contarPatidos(int idJugador){

Jugador_partidos reg;

int pos=0;
int cant=0;

while(reg.leerDeDisco(pos)){
    if(reg.getIDjugador==cod && reg.tiempoEnCancha>0){
        cant++;
    }

    pos++;
}

return cant;


}


void anioMasJugadores(){
Jugador reg;
int vAnios[22]{};
int pos=0;

while(reg.leerDeDisco(pos)){
    vAnios[reg.getFechaNacimiento().getAnio()-1]++;
    }
    pos++;
}

mostrarMayorAnio(vAnios,22);


}

void mostrarMayorAnio(int *vAnios,int cant){

int maxCant=0;
int maxAnio=0;

for(int i=0; i<cant; i++){

    if(vAnios[i]>maxCant){
        maxCant=vAnios[i];
        maxAnio=i+1;
    }


}

cout << endl << "Anio en el que nacieron mas jugadores: " << maxAnio << endl;

}


