/***
5
Una tienda online dispone de todas las ventas realizadas el mes pasado en los tres pa�ses donde comercializa.
Por cada venta registra:

N�mero de pa�s (1 a 3)
D�a de la venta (1 a 31)
Monto de la venta (float)

Para indicar el fin de la carga de informaci�n se ingresa un n�mero de pa�s igual a -1.
La informaci�n no se encuentra agrupada ni ordenada bajo ning�n criterio.
Se pide calcular e informar:

A) Por cada pa�s y d�a, el total recaudado. S�lo mostrar informaci�n de aquellos d�as en los que hubo recaudaci�n.
B) Por cada pa�s, la cantidad de d�as en los que no hubo recaudaci�n.
C) Los n�meros de d�a en los que no hubo recaudaci�n en ninguno de los pa�ses.






*/
#include <iostream>
using namespace std;

//Declaracion de la funcion


int main(){

int const DIAS=5; //31 REAL

int NumeroPais; //(1 a 3)
int DiaVenta; //(1 a 31)
float MontoVenta;

//PuntoC
int vPais1Cero[DIAS]{}; //triplicarDias
int vPais2Cero[DIAS]{};
int vPais3Cero[DIAS]{};

cout << "Numero de pais (1 a 3): ";
cin >>NumeroPais;

while (NumeroPais!=-1){
    //PuntoA
    int vVentaPorDia[DIAS]={};
    //PuntoB
    int diaSinRecaudacion=0;
    //PuntoC


    for(int i=0; i<DIAS; i++){
    cout << "Dia de venta: ";
    cin >>DiaVenta;
    cout << "Monto de venta: ";
    cin >>MontoVenta;

    vVentaPorDia[i]+=MontoVenta;

        //PuntoC
        if(NumeroPais==1 && MontoVenta==0){
            vPais1Cero[i]+=DiaVenta;
        }
        if(NumeroPais==2 && MontoVenta==0){
            vPais2Cero[i]+=DiaVenta;
        }
        if(NumeroPais==3 && MontoVenta==0){
            vPais3Cero[i]+=DiaVenta;
        }


    }




    //PuntoA

    cout << "Punto A: Total recaudado por dia: " << endl;
    cout << "----------------" << endl;
    for (int x=0; x<DIAS; x++){
        if(vVentaPorDia[x]>0){
            cout << "Dia: " << x+1 << " Monto: " << vVentaPorDia[x] << endl;
        }

    }

    //PuntoB

    cout << "Punto B: Dias en los que no hubo recaudacion.: " << endl;
    cout << "----------------" << endl;
    for (int y=0; y<DIAS; y++){
        if(vVentaPorDia[y]==0){
        diaSinRecaudacion++;
        }
    }

    cout << "Pais: " << NumeroPais << " dias sin recaudacion: " << diaSinRecaudacion << endl;








cout << "----------------" << endl;
cout << "Numero de pais (1 a 3): ";
cin >>NumeroPais;

}

cout << "Punto C: Dias en los que no hubo recaudacion en ninguno de los paises: " << endl;
cout << "----------------" << endl;

for (int y=0; y<DIAS; y++){

    if(vPais1Cero[y]==vPais2Cero[y]){
        if(vPais1Cero[y]==vPais3Cero[y]){
            cout << "Dia sin recaudacion en ningun pasi: " <<  vPais1Cero[y] << endl;
        }



    }

    }


return 0;
}


//Definicion de la funcion



