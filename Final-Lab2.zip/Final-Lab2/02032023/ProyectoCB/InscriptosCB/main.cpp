#include <iostream>
using namespace std;

#include "ExameneFinal.h"
#include "Examen.h"


int main() {


//int cant, archExa=0;
//
//cout << "Ingresar cantidad de examenes a cargar: ";
//cin >> cant;
//
//ExameneFinal *objExa = new ExameneFinal[cant];
//
//
//    for(int i=0; i<cant; i++){
//        objExa[i].cargarExamenes();
//        archExa = objExa[i].grabarenDisco();
//        if(archExa == 1){
//        cout << "Archivo cargado" << endl;
//        }
//    }
//
//delete []objExa;
//
    Examen exa;
    exa.leerExamenes();
    cout<<endl;
    //exa.crearExamenFinal();
    cout<<endl;
    exa.alumnosAprobados();

	return 0;
}
