///MacielNicolas
///Integrador 14/11

#include <cstring>
#include <cstdio>
#include <iostream>
using namespace std;

#include "clases.h"

//Punto1
class resto21{
private:
    int codigoRestaurante;
    char nombre[30];
    int cantReservas;
public:
    resto21(int cod=0, const char nom[30]="hola", int can=0){
    codigoRestaurante = cod;
    strcpy(nombre,nom);
    cantReservas = can;
    }

    int getCodigoRestaurante(){return codigoRestaurante;}
    const char *getNombre(){return nombre;}
    int getCantReservas(){return cantReservas;}

    void setCodigoRestaurante(int cod){codigoRestaurante=cod;}
    void setNombre(const char *n){strcpy(nombre,n);}
    void setCantReservas(int cant){cantReservas=cant;}

    bool leerDeDisco(int pos){
        FILE *p;
        p=fopen("resto21.dat","rb");
        if(p==NULL) return false;
        fseek(p,pos*sizeof *this, 0);
        bool leyo=fread(this, sizeof *this, 1, p);
        fclose(p);
        return leyo;
        }

    bool grabarEnDisco(){
        FILE *p;
        p=fopen("resto21.dat","ab");
        if(p==NULL) return false;
        bool escribio=fwrite(this, sizeof *this, 1, p);
        fclose(p);
        return escribio;
    }

    void Mostrar(){
        cout<<"CODIGO: "<<getCodigoRestaurante()<<endl;
        cout<<"NOMBRE: "<<getNombre()<<endl;
        cout<<"CANTIDAD DE RESERVAS: "<<getCantReservas()<<endl;
    }

};

//Punto5
class mayores50{
private:
    int DNI;
    char nombre[30];
    int medioPago;
    int tipoCliente;
    int edad;
    bool estado;
public:

    void setDNI(int d){DNI=d;}
    void setNombre(const char *n){strcpy(nombre,n);}
    void setMedioPago(int mP){medioPago=mP;}
    void setTipoCliente(int tC){tipoCliente=tC;}
    void setEdad(int e){edad=e;}
    void setEstado(bool e){estado=e;}

    void Mostrar(){
    cout<<"DNI: "<<DNI<<endl;
    cout<<"NOMBRE: "<<nombre<<endl;
    cout<<"MEDIO DE PAGO: "<<medioPago<<endl;
    cout<<"TIPO DE CLIENTE: "<<tipoCliente<<endl;
    cout<<"EDAD: "<<edad<<endl;
    }

    void operator=(Cliente &reg){
        setDNI(reg.getDNI());
        setNombre(reg.getNombre());
        setMedioPago(reg.getMedioPago());
        setTipoCliente(reg.getTipoCliente());
        setEdad(reg.getEdad());
        setEstado(reg.getEstado());

    }

};



///Prototipos

void punto1();
    int buscarReservas(int cod);
void punto2();
    bool modificarArchivo(Restaurante obj, int pos);
void punto5();
    int mayor50();
    void copiar50(Cliente *pCincuenta);
    void mostrar50(Cliente *pCincuenta, int cant);



int main(){

cout << "==== Punto 1 ==== " << endl;
punto1();
resto21 obj;
int pos2=0;
while(obj.leerDeDisco(pos2)){
    obj.Mostrar();
    pos2++;
}

cout << "==== Punto 2 ==== " << endl;
punto2();
Restaurante reg;
int pos=0;
while(reg.leerDeDisco(pos++)){
    if(reg.getEstado()==true){
        reg.Mostrar();
    }
}
cout << "==== Punto 3 al final ==== " << endl;
cout << "==== Punto 4 en clase punto 1==== " << endl;

cout << "==== Punto 5 ==== " << endl;
punto5();


return 0;
}



void punto1(){
Restaurante reg;
resto21 obj;
int pos=0;

while(reg.leerDeDisco(pos)){
    if(reg.getCategoriaRestaurante()==1 && buscarReservas(reg.getCodigoRestaurante())>0){
        obj.setCodigoRestaurante(reg.getCodigoRestaurante());
        obj.setNombre(reg.getNombre());
        obj.setCantReservas(buscarReservas(reg.getCodigoRestaurante()));

        obj.grabarEnDisco();
    }

    pos++;
}



}



int buscarReservas(int cod){

Reserva reg;
int pos=0, cant=0;
while(reg.leerDeDisco(pos)){
    if(reg.getFechaReserva().getAnio()==2021 && cod==reg.getCodigoRestaurante()){
            cant++;
        }
        pos++;
    }
    return cant;
}


void punto2(){
Restaurante obj;
int pos=0;

while(obj.leerDeDisco(pos)){
    if(obj.getProvincia()==6){
        obj.setEstado(false);
        modificarArchivo(obj,pos);
    }
    pos++;
}


}

bool modificarArchivo(Restaurante obj, int pos){
FILE *p = fopen("restaurantes.dat","rb+");
if(p==NULL){return false;}

fseek(p,sizeof(Restaurante)*pos,0);
bool escribio = fwrite(&obj,sizeof obj,1,p);
fclose(p);
return escribio;

}


void punto5(){
Cliente *pCincuenta;
int cant = mayor50();

pCincuenta = new Cliente[cant];
if(pCincuenta==NULL){"Error";}
copiar50(pCincuenta);
mostrar50(pCincuenta,cant);

delete []pCincuenta;


}


int mayor50(){
Cliente reg;
int pos=0, cant=0;

while(reg.leerDeDisco(pos)){
    if(reg.getEdad()>50){
        cant++;
    }

    pos++;
}
return cant;

}
void copiar50(Cliente *pCincuenta){
Cliente reg;
int pos=0, i=0;

while(reg.leerDeDisco(pos)){
    if(reg.getEdad()>50){
        pCincuenta[i++]=reg;
    }
    pos++;
}




}
void mostrar50(Cliente *pCincuenta, int cant){
for(int i=0; i<cant; i++){
    pCincuenta[i].Mostrar();
    cout << endl;
    }
}



/*
Punto 3

class Cliente{
   private:
        ...
    public:
        ....

        bool operador == (Cliente &aux){
            if(edad == aux.getEdad){
                return true;
                }
        }

};




*/
