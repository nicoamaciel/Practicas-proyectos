#include <iostream>
using namespace std;
#include "SegundoParcial.h"

int main() {
    SegundoParcial sp;
    //sp.alumnosDesaprobados();
    //cout << endl;
   // sp.peorCurso();
    //cout << endl;
    //sp.verGeneraciones();
   // cout << endl;
    //sp.generarReporte();
   // cout << endl;
   //sp.generarReporte();
   cout << endl;
   sp.mostrarReporte();
  return 0;
}
