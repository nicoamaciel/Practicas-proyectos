#include <iostream>
using namespace std;
#include "ejercicio6.h"


int main(){

int cantP, cantA, opc;
profesores *vec = new profesores[cantP]{};
alumnos *reg = new alumnos[cantA]{};


while (true){
    system("cls");
    cout << " MENU PROFESORES - ALUMNOS " << endl;
    cout << " - - - - - - - - - - - - - " << endl;
    cout << " 1-   CARGAR PROFESOR      " << endl;
    cout << " 2-   CARGAR ALUMNOS       " << endl;
    cout << " 3-   ESTADISTICAS         " << endl;
    cout << " 0-   SALIR                " << endl;
    cout << " - - - - - - - - - - - - - " << endl;
    cout << "OPCION: " << endl;
    cin >> opc;
    system("cls");

        switch(opc){
        case 1:
            cout << "Cantidad de profesores: ";
            cin >> cantP;


                for(int i=0; i<cantP ; i++){
                vec[i].cargar();
                cout << endl;

                }

                if(vec!=nullptr){
                for(int i=0; i<cantP; i++){
                vec[i].mostrar();
                    }

                }



            break;
        case 2:
            cout << "Cantidad de alumnos: ";
            cin >> cantA;


                for(int i=0; i<cantA ; i++){
                reg[i].cargar();
                cout << endl;

                }

                if(reg!=nullptr){
                for(int i=0; i<cantA; i++){
                reg[i].mostrar();
                    }

                }



            break;
        case 3:
            break;
        case 0: return 0;
            break;
        }
        delete []vec;
        delete []reg;


        system("pause");
    }
    cout<<endl;


return 0;
}
