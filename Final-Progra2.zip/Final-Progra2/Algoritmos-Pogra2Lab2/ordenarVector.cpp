
===============================================================================================
===============================================================================================
Datos de punto --->> Hacer un listado de países ordenado por población de manera decreciente. 
Indicar en el listado:Código del país, nombre del país y población.
===============================================================================================
===============================================================================================

en punto h !!FUNCIONES GLOBALES!!
pais.h

int cantidadPais(); --->> Cantidad de archivos (Usar algoritmo especial)
void leerPaises(Pais *obj,int cant);  --->> Usar lectura para recorrer
void ordenerVector(Pais *obj, int cant); --->> Algoritmo de orden 



===============================================================================================
===============================================================================================
en cpp --->> Pais.cpp

#include "Pais.h"
#include <cstring>
#include <cstdio>
#include <iostream>
using namespace std;

int cantidadPais(){
int cant=0;
FILE *pPais = fopen("paises.dat","rb");
if(pPais==nullptr){return -1;}

fseek(pPais,0,SEEK_END);
cant = ftell(pPais)/sizeof(Pais);  --->> Calcula cantidad
fclose(pPais);
return cant;


}


void ordenerVector(Pais *obj, int cant){

Pais aux;
int comp;
for (int i=0; i<cant-1; i++){
    for(int j=i+1; j<cant; j++){
        comp = strcmp(obj[i].getCodigo(),obj[j].getCodigo());
        if(comp<0){
            aux = obj[i];
            obj[i] = obj[j];
            obj[j] = aux;

        }
    }
}


}

===============================================================================================
==============================COMO MOSTRAR ORDENADOS===========================================
===============================================================================================


{
   cant = cantidadPais();
   Pais *obj = new Pais[cant];

   leerPaises(obj,cant);
   ordenerVector(obj,cant);

   for(int i=0; i<cant; i++){
      cout << obj[i].getCodigo() << endl;
      cout << obj[i].getNombre() << endl;
      cout << obj[i].getPoblacion() << endl;
      cout << endl;
      }
   
   delete []obj;
   }
