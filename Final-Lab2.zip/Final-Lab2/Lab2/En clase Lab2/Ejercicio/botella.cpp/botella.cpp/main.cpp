

/*
Realizar el diagrama de clases y la codificaci�n del objeto Botella que contenga las
siguientes caracter�sticas y comportamientos:

Caracter�sticas
float Capacidad: La capacidad total de carga del recipiente.
float Ocupaci�n: La carga actual del recipiente.
bool Tapada: Determina si la botella se encuentra tapada o no.

Comportamientos
Llenar (float): Debe permitir aumentar la ocupaci�n del recipiente pero nunca por encima de su capacidad.
Vaciar(float): Debe permitir disminuir la ocupaci�n del recipiente pero nunca por debajo de 0.
Tapar(): Debe tapar la botella.
Destapar(): Debe destapar la botella.

Hacer los m�todos que nos permitan obtener la capacidad,
la ocupaci�n y la disponibilidad de la botella(esto �ltimo representa cu�nto tiene disponible a�n para cargar).
Al crear un objeto Botella se puede suministrar la capacidad del mismo. Si no se indica, debe ser 100 por defecto.
En cualquier caso, la ocupaci�n ser� inicialmente de 0.

Todos los m�todos que consideren necesarios deben limitarse a que la botella se encuentre destapada. De lo contrario, no podr�n realizarse. Ejemplo: No se puede vaciar una botella tapada.


*/

#include <iostream>

using namespace std;
#include "botella.h"


int main()
{
    int opcion;
    float contenido, contenido2;
    botella obj;

    cout << obj.getCapacidad();

    while(true){
    system("cls");
    cout<<"-------MENU PRINCIPAL -------"<<endl;
    cout<<"1.     Destapar botella"<<endl;
    cout<<"2.     Tapar botella"<<endl;
    cout<<"3.     Llenar botella"<<endl;
    cout<<"4.     Vaciar botella"<<endl;
    cout<<"5.     Mostar contenido"<<endl;
    cout<<"0.     SALIR"<<endl;
    cout<<"-----------------------------"<<endl<<endl;
    cout<<"OPCION: ";
    cin>>opcion;
    system("cls");
    switch(opcion){
    case 1:
        obj.destapar();
    break;
    case 2:
        obj.tapar();
    break;
    case 3:
        cout << "Contenido para llenar: ";
        cin >> contenido;
        obj.llenar(contenido);
    break;
    case 4:
        cout << "Contenido para vaciar: ";
        cin >> contenido2;
        obj.vaciar(contenido2);
    break;
    case 5:
        obj.mostrar();
    break;
    case 0: return 0;
    break;
        }
        system("pause");

    }

	cout<<endl;
	system("pause");

    return 0;
}
