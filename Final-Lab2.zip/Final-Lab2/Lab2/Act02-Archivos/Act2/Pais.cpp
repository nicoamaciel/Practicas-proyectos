#include "Pais.h"
#include <cstring>
#include <cstdio>
#include <iostream>
using namespace std;

void Pais::mostrar(){
    cout << _codigo << " " << _codigo2 << " " << _nombre << " " << _continente << " " << _superficie << " ";
    cout << _poblacion << " " << _independencia << " " << _expectativaDeVida << " " << _capital << endl;
}
void Pais::setCodigo(const char *codigo){
    strcpy(_codigo, codigo);
}
void Pais::setCodigo2(const char *codigo2){
    strcpy(_codigo2, codigo2);
}
void Pais::setNombre(const char *nombre){
    strcpy(_nombre, nombre);
}
void Pais::setContinente(const char *continente){
    strcpy(_continente, continente);
}
void Pais::setSuperficie(float superficie){
    _superficie = superficie;
}
void Pais::setPoblacion(int poblacion){
    _poblacion = poblacion;
}
void Pais::setIndependencia(short independencia){
    _independencia = independencia;
}
void Pais::setExpectativaDeVida(float expectativa){
    _expectativaDeVida = expectativa;
}
void Pais::setIDCapital(int IDCapital){
    _capital = IDCapital;
}
char * Pais::getCodigo(){
    return _codigo;
}
char * Pais::getCodigo2(){
    return _codigo2;
}
char * Pais::getNombre(){
    return _nombre;
}
char * Pais::getContinente(){
    return _continente;
}
float Pais::getSuperficie(){
    return _superficie;
}
int Pais::getPoblacion(){
    return _poblacion;
}
short Pais::getIndependencia(){
    return _independencia;
}
float Pais::getExpectativaDeVida(){
    return _expectativaDeVida;
}
int Pais::getIDCapital(){
    return _capital;
}


int cantidadPais(){
int cant=0;
FILE *pPais = fopen("paises.dat","rb");
if(pPais==nullptr){return -1;}

fseek(pPais,0,SEEK_END);
cant = ftell(pPais)/sizeof(Pais);
fclose(pPais);
return cant;


}


void leerPaises(Pais obj[],int cant){
FILE *pPais = fopen("paises.dat","rb");
if(pPais==nullptr){"Error de lectura";}

fread(obj,sizeof(Pais),cant,pPais);
fclose(pPais);
}


void ordenerVector(Pais *obj, int cant){

Pais aux;
int comp;
for (int i=0; i<cant-1; i++){
    for(int j=i+1; j<cant; j++){
        comp = strcmp(obj[i].getCodigo(),obj[j].getCodigo());
        if(comp<0){
            aux = obj[i];
            obj[i] = obj[j];
            obj[j] = aux;

        }
    }
}


}


void mostrarPaises(){
Pais reg;
FILE *pPais = fopen("paises.dat","rb");
if(pPais==nullptr){"Error de lectura";}

while(fread(&reg,sizeof(Pais),1,pPais)==1){
    reg.mostrar();
}
fclose(pPais);
}


bool buscarPais(){
char cod[4];
cout << "Ingrese codigo de pais: ";
cin >> cod;

Pais reg;
int comp;
FILE *pPais = fopen("paises.dat","rb");
if(pPais==nullptr){return false;}

while(fread(&reg,sizeof(Pais),1,pPais)==1){
    comp = strcmp(cod,reg.getCodigo());
    if(comp==0){
        return true;
    }

}





}
