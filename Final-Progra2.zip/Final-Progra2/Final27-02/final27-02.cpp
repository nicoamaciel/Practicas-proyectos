///MacielNicolas
///Final 27/02/23

#include <cstring>
#include <cstdio>
#include <iostream>
using namespace std;




//Punto1
class SinPlayas{
private:
    int _DNI;
    char _nombre[30];
    char _apellido[30];
    int _sueldo;
public:
    SinPlayas(int dn=0, const char nom[30]="xxxxxx", const char ape[30]="xxxxxx", int suel=0){
    _DNI = dn;
    strcpy(_nombre,nom);
    strcpy(_apellido,ape);
    _sueldo = suel;
    }

    int getDNI(){return _DNI;}
    const char *getNombre(){return _nombre;}
    const char *getApellido(){return _apellido;}
    int getSueldo(){return _sueldo;}

    void setDNI(int dn){_DNI=dn;}
    void setNombre(const char *n){strcpy(_nombre,n);}
    void setApellido(const char *a){strcpy(_apellido,a);}
    void setSueldo(int suel){_sueldo=suel;}

    bool leerDeDisco(int pos){
        FILE *p;
        p=fopen("sinplayas.dat","rb");
        if(p==NULL) return false;
        fseek(p,pos*sizeof *this, 0);
        bool leyo=fread(this, sizeof *this, 1, p);
        fclose(p);
        return leyo;
        }

    bool grabarEnDisco(){
        FILE *p;
        p=fopen("sinplayas.dat","ab");
        if(p==NULL) return false;
        bool escribio=fwrite(this, sizeof *this, 1, p);
        fclose(p);
        return escribio;
    }

    void Mostrar(){
        cout<<"DNI: "<<getDNI()<<endl;
        cout<<"NOMBRE: "<<getNombre()<<endl;
        cout<<"APELLIDO: "<<getApellido()<<endl;
        cout<<"SUELDO: "<<getSueldo()<<endl;
    }


};





///Prototipos

void punto1();
    bool buscarPlayas(int dni);
void punto2();
    void mostrarMayor(int *vLocal, int cant);



int main(){

cout << "==== Punto 1 ==== " << endl;
punto1();
SinPlayas obj;
int pos=0;
while(obj.leerDeDisco(pos)){
    obj.Mostrar();
    pos++;
    }
cout << "==== Punto 2 ==== " << endl;
punto2();

}




void punto1(){
Guardavidas reg;
SinPlayas obj;
int pos=0;

while(reg.leerDeDisco(pos)){
    if(buscarPlayas(reg.getDNI())==0){
        obj.setDNI(reg.getDNI());
        obj.setNombre(reg.getNombre());
        obj.setApellido(reg.getApellido());
        obj.setSueldo(reg.getSueldo());

        obj.grabarEnDisco();
    }

    pos++;
}



}



bool buscarPlayas(int dni){

Guardavidas_playas reg;
int pos=0;
while(reg.leerDeDisco(pos)){
    if(dni==reg.getDNIguardavidas() && reg.getFechaDeInicio().getAnio()==2023){
            return true;
        }
        pos++;
    }
    return false;
}


//Punto2
void punto2(){
Guardavidas reg;
int vLocal[20]{};
int pos=0;

while(reg.leerDeDisco(pos)){
    if(reg.getLocalidad()>0){
        vLocal[reg.getLocalidad()-1]++;
    }

    pos++;
}

mostrarMayor(vLocal,20);

}


}
void mostrarMayor(int *vLocal, int cant){

int maxCant=0;
int maxLocal=0;

for(int i=0; i<cant; i++){

    if(vLocal[i]>maxCant){
        maxCant=vLocal[i];
        maxLocal=i+1;
    }


}

cout << endl << "Localidad con mas guardavidas: " << maxLocal << endl;



}
