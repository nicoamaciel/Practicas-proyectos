

#include <iostream>
#include <cstring>
#include <cstdlib>
using namespace std;
#include "parcialm1.h"

/*
A)
Generar un archivo con el c�digo de obra, la direcci�n y el importe total de las compras para esa obra.
Es decir, por cada obra se debe registrar el c�digo de obra, la direcci�n de la obra y el importe total de las compras para esa obra.

B)
La provincia con menos proveedores (ignorando las provincias sin proveedores).

*/

class archivo{
private:
        char _codigoObra[5];
        char _direccion[30];
        int _importe;

public:

    //Sets

        void setCodigoObra(const char *cod ){strcpy(_codigoObra,cod);}
        void setDireccion(const char *dir ){strcpy(_direccion,dir);}
        void setImporte(int imp){_importe=imp;}

    //Comportamiento
    bool grabarEnDisco();



};


//Prototipo
void puntoA();
    int buscarImporte(char const *cad);
void puntoB();
    void leerVector(int*vec, int tam);





int main()
{
//    Proveedor obj;
//    int pos=0;
//
//    while(obj.leerDeDisco(pos++)){
//        obj.Mostrar();
//        cout << endl;
//    }
    puntoA();

    cout << endl;
    puntoB();



    return 0;
}


void puntoA(){
Obra reg;


archivo obj;
int importe=0;


int pos1=0, prueba=0;
while(reg.leerDeDisco(pos1)){
        importe = buscarImporte(reg.getCodigoObra());
        if(importe>0){
        obj.setCodigoObra(reg.getCodigoObra());
        obj.setDireccion(reg.getDireccion());
        obj.setImporte(importe);

        obj.grabarEnDisco();

        }



        pos1++;
    }
}


int buscarImporte(char const*cad){
Compra reg;
int pos=0;
int comp;

while(reg.leerDeDisco(pos)){
    comp = strcmp(reg.getCodigoObra(),cad);
    if(comp==0){
        return reg.getImporte();
    }
    else{
       return -1;
    }
    pos++;
}



}



bool archivo::grabarEnDisco(){
        FILE *pA;
        pA = fopen("archivo.dat","ab");
        if(pA==NULL){
            return false;
        }
        bool escribio = fwrite(this,sizeof(archivo),1,pA);
        fclose(pA);
        return escribio;
}




void puntoB(){
int vProv[24]={0};
Proveedor reg;
int pos=0;

while(reg.leerDeDisco(pos)){
vProv[reg.getProvincia()-1]++;

pos++;
}

leerVector(vProv,24);


}

void leerVector(int *vProv,int tam){
int menor=0;
int proMenor=0;

for(int i=0; i<tam; i++){
        if(vProv[i]>0 && i==0){
          proMenor=vProv[i];
          menor=i+1;
        }
        else{
             if(vProv[i]>0 && vProv[i]<proMenor){
                proMenor=vProv[i];
                menor=i+1;
            }
        }



    }
cout << "Provincia con menos provedores: " << menor << endl;

}
