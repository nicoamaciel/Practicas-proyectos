
===================================================================================================================================
============================================== Buscar ejemplo de puntos parcial progra=============================================
===================================================================================================================================

En cpp -->> clase creada antes de main y con class
//Punto1

class Punto1{

private:
    int _codResto;
    char _nomRestaurante[20];
    int _cantReservas21;

public:
    int getCodResto(){return _codResto;}
    const char *getNomRestaurante(){return _nomRestaurante;}
    int getCanReservas21(){return _cantReservas21;}

    void setCodResto(int cod){_codResto=cod;}
    void setNomRestaurante(const char *nom){strcpy(_nomRestaurante,nom);}
    void setCanReservas21(int cant21){_cantReservas21=cant21;}


    void grabarEnDisco();
    void leerDeDisco();
    void mostar();

};


void punto1();
    bool buscarAnio(int);
    int buscarReservas(int);


ANTES DE MAIN!


===================================================================================================================================
===================================================================================================================================


void Punto1::mostar(){

cout << "Codigo resto: " << getCodResto() << endl;
cout << "Nombre resto: " << getNomRestaurante() << endl;
cout << "Cantidad reservas 21: " <<getCanReservas21()<< endl;

}



void Punto1::grabarEnDisco(){
FILE *pPunto1;
pPunto1 = fopen("punto1.dat","ab");
if(pPunto1==NULL){
    cout << "Error en archivo";
    //return -1;
    }

   int escribio = fwrite(this, sizeof(Punto1), 1, pPunto1);
   fclose(pPunto1);
   //return escribio;


}


void punto1(){
Restaurante reg;
Punto1 obj;
int pos=0;

while(reg.leerDeDisco(pos)){
    if(reg.getCategoriaRestaurante()==2 && buscarAnio(reg.getCodigoRestaurante())==true){
        obj.setCodResto(reg.getCodigoRestaurante());
        obj.setNomRestaurante(reg.getNombre());
        obj.setCanReservas21(buscarReservas(reg.getCodigoRestaurante()));

        obj.grabarEnDisco();
    }

    pos++;
}

}



bool buscarAnio(int codResto){
Reserva reg;
int pos=0;

while(reg.leerDeDisco(pos)){
    if(codResto==reg.getCodigoRestaurante() && reg.getFechaReserva().getAnio()==2021){
        return true;
    }
    pos++;
}


}


int buscarReservas(int codResto){
Reserva reg;
int cant=0, pos=0;


while(reg.leerDeDisco(pos)){
    if(codResto==reg.getCodigoRestaurante() && reg.getFechaReserva().getAnio()==2021){
        cant++;
    }
    pos++;
}


return cant;

}
