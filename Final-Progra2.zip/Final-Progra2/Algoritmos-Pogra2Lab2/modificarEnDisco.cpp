
=================================================================================
==========================Modificar en disco local en clase======================
=================================================================================


bool equipos::modificarEnDisco(int pos){
   FILE *p;
   p=fopen("equipos.dat","rb+");
   if(p==NULL) return false;
   fseek(p, pos * sizeof(equipos), 0);
   bool escribio=fwrite(this, sizeof (equipos), 1, p);
   fclose(p);
   return escribio;
}

=================================================================================
==========================Ejemplo parcial========================================
=================================================================================
Punto 2 baja logica 
void punto2(); --->> Funcion global
	bool modificarArchivo(vuelo reg, int pos); ---->> Class a editar y posicion del archivo vieja

void punto2(){
vuelo reg;
int pos=0;

 while(reg.leerDeDisco(pos)){
	if(reg.gettipoViaje()==4){
	reg.setArchivo(false); ----->> En false y graba;
	modificarArchivo(reg,pos)	

	} 

	pos++;
 }

}

bool modificarArchivo(vuelo reg, int pos){
FILE *p = fopen("vuelos.dat", "rb+");
if(p==NULL) return false;
fseek(p,sizeof(vuelo)*pos,0);
bool escribio = fwrite(&reg, sizeof reg, 1 ,p);
fclose(p);
return escribio;
}


}
