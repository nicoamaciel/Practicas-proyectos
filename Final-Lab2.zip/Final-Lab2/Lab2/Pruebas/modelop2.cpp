/*
1-Generar un archivo con los pasajeros que no hayan comprado pasajes en el presente a�o.
El formato del archivo debe ser igual que el del archivo de pasajeros.

3-Generar un vector din�mico con los aviones de tipo propio y mostrarlo por pantalla.
El vector debe contener el c�digo de avi�n, el nombre y la marca.

*/



#include <iostream>
#include <cstring>
#include <cstdlib>
using namespace std;

#include "parcial2.h"

//Punto1

class PasajeroSin22{
private:
    int numeroPasajero;
    char nombre[30];
    char telefono[30];
    char direccion[30];
    int provincia;
    bool activo;
public:

    void setNumeroPasajero(int np){numeroPasajero=np;}
    void setProvincia(int np){provincia=np;}
    void setNombre(const char *n){strcpy(nombre,n);}
    void setTelefono(const char *n){strcpy(telefono,n);}
    void setDireccion(const char *n){strcpy(direccion,n);}
    void setActivo(bool a){activo=a;}

    int grabarEnDisco(){
        FILE *p;
        p=fopen("pasajeros.dat", "ab");
        if(p==NULL) return -1;
        int grabo=fwrite(this, sizeof *this,1, p);
        fclose(p);
        return grabo;
    }
};


//Punto1

void punto1();
bool buscarCompra(int pas);

//Punto3

void punto3();



int main(){

punto1();

return 0;
}





void punto1(){

Pasajero obj;
PasajeroSin22 reg;
int pos=0;

while(obj.leerDeDisco(pos)){
    if(buscarCompra(obj.getNumeroPasajero())){
        reg.setNumeroPasajero(obj.getNumeroPasajero());
        reg.setProvincia(obj.getProvincia());
        reg.setNombre(obj.getNombre());
        reg.setTelefono(obj.getTelefono());
        reg.setDireccion(obj.getDireccion());
        reg.setActivo(obj.getActivo());
        }

        pos++;
    }


}


bool buscarCompra(int pas){

Pasaje reg;
int pos=0;

while(reg.leerDeDisco(pos)){
    if(reg.getNumeroPasajero()==pas && reg.getFechaCompra().getAnio()!=2022){
     return true;
    }
    pos++;
}



}

void punto3(){

int cant = cantAvionPropio());

Avion *vAvionPropio = Avion new[cant];


Avion reg;
int pos=0;

while(reg.leerDeDisco(pos)){
    if(reg.getTipo()==1){

    }

    pos++;

}


}
