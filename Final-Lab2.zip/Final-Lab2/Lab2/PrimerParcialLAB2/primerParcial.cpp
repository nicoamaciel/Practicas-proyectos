#include <iostream>
#include <cstdlib>
using namespace std;

#include "primerParcial.h"
#include "PagosArchivo.h"
#include "EstudiantesArchivo.h"
#include "Estudiante.h"
#include "Pago.h"

void primerParcial::listarRecaudacion(){


int vCursos[10]{};


for(int i=0; i<10; i++){
    vCursos[i-1] += buscarCurso(i+1);

    }

for(int i=0; i<10; i++){
    cout << i+1 << " - monto:"<< vCursos[i-1] << endl;

    }





}

int  primerParcial::buscarCurso(int curso){
PagosArchivo pag;
int cant =0;

cant = pag.getCantidad();

Pago *vPag = new Pago[cant];

for(int i=0; i<cant; i++){
    vPag[i] = pag.leer(i);

    }

for(int i=0; i<cant; i++){
    if(curso == vPag[i].getIdCurso()){
        if(vPag[i].getFecha().getDia()>=10 && vPag[i].getFecha().getMes()>=5 && vPag[i].getFecha().getAnio()>=2020){
            return vPag[i].getMonto();
            }
        }
    }

delete []vPag;

}

bool Pago::esPagoVencido(int leg){
PagosArchivo pag;
int cant =0;

cant = pag.getCantidad();

Pago *vPag = new Pago[cant];

for(int i=0; i<cant; i++){
    vPag[i] = pag.leer(i);
    }

for(int i=0; i<cant; i++){
    if(leg == vPag[i].getLegajo()){
        if(vPag[i].getFecha().getMes() == vPag[i].getMes()){
            return false;
        }


    }
}
delete []vPag;

}


void primerParcial::listarAlumnosNoMorosos(){
Pago obj;
EstudiantesArchivo est;
int cant =0;

cant = est.getCantidad();

Estudiante *vEst = new Estudiante[cant];

for(int i=0; i<cant; i++){
    vEst[i] = est.leer(i);
    }

for(int i=0; i<cant; i++){

    if(obj.esPagoVencido(vEst[i].getLegajo())){
        cout << "Legajo: " << vEst[i].getLegajo() << endl;
        cout << "Pago vencido" << endl;

        }
    else{
         cout << "Legajo: " << vEst[i].getLegajo() << endl;
    }
    cout << " - - - - - - - - - - - - - " << endl;
}

delete []vEst;

}


//void primerParcial::soloUnCurso(){
//
//EstudiantesArchivo est;
//int cant =0;
//
//cant = est.getCantidad();
//
//Estudiante *vEst = new Estudiante[cant];
//
//for(int i=0; i<cant; i++){
//    vEst[i] = est.leer(i);
//    }
//
//for(int i=0; i<cant; i++){
//    cout << vEst[i].getLegajo() << endl;
//    cout << unoSolo(vEst[i].getLegajo()) << endl;
//
//}

//
//delete[]vEst;
//}


//int primerParcial::unoSolo(int leg){
//PagosArchivo pag;
//
//int cant =0;
//cant = pag.getCantidad();
//Pago *vPag = new Pago[cant];
//
//for(int i=0; i<cant; i++){
//    vPag[i] = pag.leer(i);
//    }
//
//int pagos=0;
//for (int i=0; i<cant; i++){
//  if (vPag[i].getLegajo() && vPag[i]){
//    pagos++;
//  }
//  return pagos;
//}
//
//delete[]vPag;
//
//}


int primerParcial::grabarEnEstadistica(){
    Pago reg;
    FILE *pEstadistica;
    pEstadistica = fopen("estadisticas.dat", "ab");
    if(pEstadistica == nullptr){
    cout << "ERROR DE ARCHIVO"<< endl;
    system("pause");
    return -1;
    }

    int escribio = fwrite(&reg, sizeof(Pago), 1,pEstadistica);
    fclose(pEstadistica);
    return escribio;
}

void primerParcial::generarEstadistica(){



PagosArchivo pag;
int cant =0;

cant = pag.getCantidad();

Pago *vPag = new Pago[cant];
estadistica *vEsta = new estadistica[cant]{};

for(int i=0; i<cant; i++){
    vPag[i] = pag.leer(i);

    }

for(int i=0; i<cant; i++){
    vEsta[i].setAnioEstadistica(vPag[i].getFecha().getAnio());
    vEsta[i].seTrecaudacionEstadistica(vPag[i].getMonto());
    grabarEnEstadistica();
    }

delete[]vPag;
delete[]vEsta;
}

//void primerParcial::mostrarEstadisticas(){
//    estadistica aux;
//    FILE *pEstadistica;
//    pEstadistica = fopen("estadisticas.dat", "rb");
//    if(pEstadistica == nullptr){
//    cout << "ERROR DE ARCHIVO"<< endl;
//    system("pause");
//    }
//
//    while(fread(&aux,sizeof aux, 1, pEstadistica)==1){
//    reg.mostrar();
//    cout << endl;
//    }
//
//}
//
//void primerParcial::mostrar(){
//
//    estadistica reg;
//    cout << "Anio: "<< reg.getAnioEstadistica() << endl;
//    cout << "Reacaudacion: " << reg.geTrecaudacionEstadistica() << endl;
//
//
//}






