#ifndef EXAMEN_H_INCLUDED
#define EXAMEN_H_INCLUDED


class Examen{
private:


public:

    void leerComentarios();

    void crearComentario();
    void fullComentado();
    void cortitaYAlPie();

};
bool validarLegajo(int leg, int id, int foro);


#endif // EXAMEN_H_INCLUDED
