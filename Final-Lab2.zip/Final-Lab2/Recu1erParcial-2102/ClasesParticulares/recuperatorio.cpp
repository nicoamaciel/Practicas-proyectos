
/*
1- Crear un m�todo llamado cursosConMayorAyuda que muestre el IDCurso
con la mayor cantidad de horas acumuladas en las clases particulares
(en caso de haber m�s de uno, mostrar todos los que cumplan dicha condici�n ).
(25- Puntos)

2- Crear un m�todo llamado alumnosConPocaAyuda que muestre el legajo y
nombre de los alumnos que nunca tuvieron una clase particular con una duraci�n mayor a 1 hora.
(25- Puntos)

3- Crear un m�todo llamado generarEstadisticasAyuda que guarde en un archivo estadisticas.dat
para cada curso el promedio de recaudaci�n (monto).
Crear otro m�todo mostrarEstadisticas que lea el archivo de estadisticas.dat y lo muestre por pantalla.
(25- Puntos)

4- Crear un m�todo llamado nuncaRecibioAyuda que reciba el legajo del profesor y
muestre todos los legajos de los alumnos a los que �l no les haya dado nunca clases particulares.
(25- Puntos)
*/

#include <iostream>
#include <cstdlib>
using namespace std;

#include "ClaseParticular.h"
#include "ClasesParticularesArchivo.h"
#include "Estudiante.h"
#include "EstudiantesArchivo.h"
#include "recuperatorio.h"

#include "Estadisticas.h"

void Recuperatorio::cursosConMayorAyuda(){
ClasesParticularesArchivo cp;

int cantidadClases= cp.getCantidad();

ClaseParticular* vecClase = new ClaseParticular[cantidadClases];

for(int i=0; i<cantidadClases; i++){
    vecClase[i] = cp.leer(i);
}

int vecCursos[10]{};

for(int x=0; x<cantidadClases; x++){
        if(vecClase[x].getDuracion()>0){
            vecCursos[vecClase[x].getIdCurso()-1]+=vecClase[x].getDuracion();
        }
    }


for(int y=0; y<10; y++){
    cout << "Curso: " <<y+1 << " Acumulado de duracion: " << vecCursos[y] << endl;
}

int maxAcumulado=0;
int maxId=0;

for(int y=0; y<10; y++){
    if(vecCursos[y]>maxAcumulado){
        maxAcumulado=vecCursos[y];
        maxId=y+1;
    }

}
cout << "--------------------" << endl;
cout << " Curso con mas ayuda: "<< maxId;
cout << endl << "--------------------" << endl;


delete []vecClase;

}


void Recuperatorio::alumnosConPocaAyuda(){
ClasesParticularesArchivo cp;

int cantidadClases= cp.getCantidad();

ClaseParticular* vecClase = new ClaseParticular[cantidadClases];

for(int i=0; i<cantidadClases; i++){
    vecClase[i] = cp.leer(i);
    }

EstudiantesArchivo est;

int cantidadEst= est.getCantidad();

Estudiante* vecEst = new Estudiante[cantidadEst];
for(int y=0; y<cantidadEst; y++){
    vecEst[y] = est.leer(y);
    }



for(int x=0; x<cantidadEst; x++){
        int cont=0;
        for(int y=0; y<cantidadClases; y++){
            if(vecEst[x].getLegajo()==vecClase[y].getLegajoAlumno()){
                if(vecClase[y].getDuracion()>60){
                    cont++;
                }
            }

        }

        if(cont==0){
            cout << "Legajo: " << vecEst[x].getLegajo() << " Apellido: " << vecEst[x].getApellidos() << endl;
        }


    }

}



void Recuperatorio::generarEstadisticasAyuda(){

ClasesParticularesArchivo cp;

int cantidadClases= cp.getCantidad();

ClaseParticular* vecClase = new ClaseParticular[cantidadClases];

for(int i=0; i<cantidadClases; i++){
    vecClase[i] = cp.leer(i);
}

int RecaCurso[10]{};
int CantPagos[10]{};

for(int y=0; y<cantidadClases; y++){
    if(vecClase[y].getMonto()>0){
        CantPagos[vecClase[y].getIdCurso()-1]++;
        RecaCurso[vecClase[y].getIdCurso()-1]=+vecClase[y].getMonto();
    }
}

Estadisticas recu[10]{};

for(int i=0; i<10; i++){
        float promedio=0;
        promedio=RecaCurso[i]/CantPagos[i];

        recu[i].setCurso(i+1);
        recu[i].setRecaudacion(promedio);

    }

FILE* pFile;
pFile = fopen("estadisticas.dat","wb");
fwrite(recu, sizeof (Estadisticas), 10, pFile);
fclose(pFile);


delete []vecClase;

}



void Recuperatorio::mostrarEstadisticas(){
FILE* pFile;
pFile = fopen("estadisticas.dat","rb");
Estadisticas est;
while(fread(&est,sizeof (Estadisticas), 1, pFile)==1){
        est.verEstadisticas();
    }


}

void Recuperatorio::nuncaRecibioAyuda(int leg){

EstudiantesArchivo est;

int cantidadEst= est.getCantidad();

Estudiante* vecEst = new Estudiante[cantidadEst];
for(int y=0; y<cantidadEst; y++){
    vecEst[y] = est.leer(y);
    }

ClasesParticularesArchivo cp;

int cantidadClases= cp.getCantidad();

ClaseParticular* vecClase = new ClaseParticular[cantidadClases];

for(int i=0; i<cantidadClases; i++){
    vecClase[i] = cp.leer(i);
    }


    for(int y=0; y<cantidadEst; y++){
        int cont=0;
        for(int x=0; x<cantidadClases; x++){
            if(vecEst[y].getLegajo()==vecClase[x].getLegajoAlumno() && vecClase[x].getLegajoProfesor()==leg){
                if(vecClase[x].getDuracion()>0){
                    cont++;
                }
            }

        }

        if(cont==0){
            cout << vecEst[y].getLegajo() << endl;
        }




    }








}
