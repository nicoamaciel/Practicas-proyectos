/*

LAS AUTORIDADES DE LA CARRERA TUP DE LA UTN EST�N REALIZANDO UN AN�LISIS DE LOS CURSOS VIRTUALES DE LAS DISTINTAS
MATERIAS. POR CADA UNA DE LAS 20 MATERIAS DE LA CARRERA TIENE LA SIGUIENTE INFORMACI�N
� N�MERO DE MATERIA (ENTRE 1 Y 20),
NOMBRE,
CANTIDAD DE ALUMNOS INSCRIPTOS,
CANTIDAD DE PROFESORES
ADEM�S POR CADA INGRESO DE LOS ESTUDIANTES AL AULA VIRTUAL SE REGISTRA LO SIGUIENTE:
� LEGAJO,
FECHA DE ACCESO (D�A Y MES),
N�MERO DE LA MATERIA A LA QUE INGRESO,
CANTIDAD DE HORAS (N�MERO REAL)

EL FIN DE LOS DATOS SE INDICA CON UN N�MERO DE LEGAJO IGUAL A 0.
SE QUIERE RESPONDER LAS SIGUIENTES PREGUNTAS:

a) LAS MATERIAS QUE NO TUVIERON ACCESO DE ALUMNOS NUNCA
b) LA MATERIA QUE M�S CANTIDAD DE HORAS REGISTRO DE ACCESO DE ALUMNOS
c) POR CADA MATERIA Y D�A DE MARZO, LA CANTIDAD DE ACCESOS DE ALUMNOS A LAS AULAS VIRTUALES.
� HACER UN PROGRAMA EN EL MARCO DE UN PROYECTO DE CODEBLOCK CON UN MEN� CON OPCIONES PARA CARGAR LOS DATOS,
MOSTRAR CADA PUNTO Y SALIR DEL PROGRAMA



*/


void CargarMaterias();
void CargarAlumnos();




#include <iostream>
using namespace std;
int main(){

int numMateria; (ENTRE 1 Y 20),
char nombre;
int cantAlumnos;
int cantProfesores;

//Alumnos
int legajo;
int dia;
int mes;
int numMateriaIngreso;
int horas;



    cout << "-------MENU-----" << endl;
    cout << "1 - Cargar Materias " << endl;
    cout << "2 - Cargar Alumno: "<< endl;
    cout << "3 - Categoria de empresa con mas empleados: "<< endl;
    cout << "----------------" << endl;
    cout << "Opcion: ";
    cin >> opcion;
    system("cls");

    switch(opcion){
        case 1:

                obj.cargar();
                obj.mostrar();
                grabarArchivo(obj);

        break;
        case 2:
        break;

    }





return 0;
}
