
===================================================================================================================================
============================================== leer y mostrar en misma funcion ====================================================
===================================================================================================================================

En punto h -->> Pais.h

void mostrarPaises();

===================================================================================================================================
===================================================================================================================================

En cpp --->> Pais.cpp

Muestra cuando --> freead es igual a 1

void mostrarPaises(){
Pais reg;
FILE *pPais = fopen("paises.dat","rb");
if(pPais==nullptr){"Error de lectura";}

while(fread(&reg,sizeof(Pais),1,pPais)==1){
    reg.mostrar();
}
fclose(pPais);
}


===================================================================================================================================
===================================================================================================================================

Mostrar y leer locales a la clase.
void leerDeDisco();
void mostar();

===================================================================================================================================

En main invocar y recorrer para mostrar.

Restaurante obj2;
int pos;

cout << "- - - - - - - - " << endl;
while(obj2.leerDeDisco(pos2)){
    obj2.Mostrar();
    pos2++;
    cout << endl;
}



===================================================================================================================================


bool leerDeDisco(int pos){
            FILE *p;
            p=fopen("restaurantes.dat","rb");
            if(p==NULL) return false;
            fseek(p,pos*sizeof *this, 0);
            bool leyo=fread(this, sizeof *this, 1, p);
            fclose(p);
            return leyo;
        }


void Mostrar(){
            cout<<"CODIGO: "<<codigoRestaurante<<endl;
            cout<<"NOMBRE: "<<nombre<<endl;
            cout<<"PROVINCIA: "<<provincia<<endl;
            cout<<"GERENTE: "<<nombreGerente<<endl;
            cout<<"CATEGORIA: "<<categoriaRestaurante<<endl;
        }


