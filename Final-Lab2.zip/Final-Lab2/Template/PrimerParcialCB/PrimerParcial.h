#ifndef PRIMERPARCIAL_H_INCLUDED
#define PRIMERPARCIAL_H_INCLUDED
//MacielNicolas
class PrimerParcial{

private:

public:
    void listarRecaudacion(); //Punto1
    void listarAlumnosNoMorosos(); //Punto2 - 3
    void soloUnCurso(); //Punto4
    void generarEstadistica(); //Punto5
    void mostrarEstadisticas();//Punto5
    void cursosPremium(int leg); //Punto6

};






#endif // PRIMERPARCIAL_H_INCLUDED
