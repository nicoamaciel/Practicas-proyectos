#include <iostream>
using namespace std;
#include "primerParcial.h"
#include "Pago.h"

/*
4) Un m�todo llamado  soloUnCurso  que muestre el legajo, nombre y
apellido de todos los alumnos que pagaron solamente un curso del periodo (a�o per�odo de cursada)  2021 .
(2 Puntos)

5) Crear un m�todo  generarEstadistica  que genere un archivo llamado estadisticas.dat que guarde el a�o y la
recaudaci�n de cada a�o del archivo de pagos Crear un m�todo llamado  mostrarEstadisticas  que
muestre el archivo generado en el punto anterior.
(2 Puntos)

6)Crear un m�todo llamado  cursosPremium  que reciba el legajo de un estudiante y muestre el/los id de curso/s al que realiz� el mayor pago individual.
(1 Punto)


*/



int main() {
primerParcial reg;
// Pago obj;
//int leg=25;
// //reg.listarRecaudacion();
//bool cacho = obj.esPagoVencido(leg);
// cout << cacho<< endl;

reg.generarEstadistica();




  return 0;
}
