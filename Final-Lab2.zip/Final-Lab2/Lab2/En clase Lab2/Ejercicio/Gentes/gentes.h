#ifndef GENTES_H_INCLUDED
#define GENTES_H_INCLUDED

class gentes{

private:
    string _Nombre;
    int _Dni;
public:
    //Gets

    string getNombre();
    int getDni();
    //Sets

    void setNombre(string);
    void setDni(int);

    //Comportamiento
    void cargarInvitados();
    void mostrarInvitados();


};





#endif // GENTES_H_INCLUDED
