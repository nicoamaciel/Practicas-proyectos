
/*
1- Crear un m�todo llamado cursosConMayorAyuda que muestre el IDCurso
con la mayor cantidad de horas acumuladas en las clases particulares
(en caso de haber m�s de uno, mostrar todos los que cumplan dicha condici�n ).
(25- Puntos)

2- Crear un m�todo llamado alumnosConPocaAyuda que muestre el legajo y
nombre de los alumnos que nunca tuvieron una clase particular con una duraci�n mayor a 1 hora.
(25- Puntos)

3-3- Crear un m�todo llamado generarEstadisticasAyuda que guarde en un archivo estadisticas.dat
para cada curso el promedio de recaudaci�n (monto).
Crear otro m�todo mostrarEstadisticas que lea el archivo de estadisticas.dat y lo muestre por pantalla.
(25- Puntos)

4- Crear un m�todo llamado nuncaRecibioAyuda que reciba el legajo del profesor y
muestre todos los legajos de los alumnos a los que �l no les haya dado nunca clases particulares.
(25- Puntos)


*/


#include <iostream>
using namespace std;

#include "Estudiante.h"
#include "EstudiantesArchivo.h"
#include "ClaseParticular.h"
#include "ClasesParticularesArchivo.h"
#include "RecuperatorioPrimerParcial.h"

#include "estadisticas.h"

void RecuperatorioPrimerParcial::cursosConMayorAyuda(){

ClasesParticularesArchivo obj;
int cantClases = obj.getCantidad();

ClaseParticular *vClases = new ClaseParticular[cantClases];

for(int x=0; x<cantClases; x++){
    vClases[x] = obj.leer(x);
}

int vAcumulados[10]{};

for(int i=0; i<cantClases; i++){
    vAcumulados[vClases[i].getIdCurso()-1]+=vClases[i].getDuracion();
}

int maxAcu=0;
int maxId=0;
for(int i=0; i<10; i++){
    if(i==0){
        maxAcu=vAcumulados[i];
    }

    if(vAcumulados[i]>maxAcu){
        maxAcu=vAcumulados[i];
        maxId=i+1;
    }

}



cout << "IDCurso con la mayor cantidad de horas acumuladas: " << maxId << endl;

delete []vClases;

}

void RecuperatorioPrimerParcial::alumnosConPocaAyuda(){

ClasesParticularesArchivo obj;
int cantClases = obj.getCantidad();

ClaseParticular *vClases = new ClaseParticular[cantClases];

for(int x=0; x<cantClases; x++){
    vClases[x] = obj.leer(x);
}

EstudiantesArchivo reg;
int cantEstu = reg.getCantidad();

Estudiante *vEstu = new Estudiante[cantEstu];

for(int x=0; x<cantEstu; x++){
    vEstu[x] = reg.leer(x);
}

for(int i=0; i<cantEstu; i++){
    int cont=0;
    for(int j=0; j<cantClases; j++){
        if(vEstu[i].getLegajo()==vClases[j].getLegajoAlumno() && vClases[j].getDuracion()>60){
            cont++;
        }
    }

    if(cont==0){
      cout << vEstu[i].getLegajo() << " " << vEstu[i].getNombres() << endl;
    }

}


delete []vClases;
delete []vEstu;

}

void RecuperatorioPrimerParcial::generarEstadisticasAyuda(){

ClasesParticularesArchivo obj;
int cantClases = obj.getCantidad();

ClaseParticular *vClases = new ClaseParticular[cantClases];

for(int x=0; x<cantClases; x++){
    vClases[x] = obj.leer(x);
}

int vRecaudacion[10]{};

for(int x=0; x<cantClases; x++){
    vRecaudacion[vClases[x].getIdCurso()-1]+=vClases[x].getMonto();
}


estadistica *estadis = new estadistica[10];

for(int x=0; x<10; x++){
    estadis[x].setCurso(x+1);
    estadis[x].setRecaudacion(vRecaudacion[x-1]/10);
}

FILE* pFile;
pFile = fopen("estadisticas.dat","wb");
fwrite(estadis, sizeof (estadistica), 10, pFile);
fclose(pFile);


}

void RecuperatorioPrimerParcial::mostrarEstadisticas(){

FILE* pFile;
pFile = fopen("estadisticas.dat","rb");
estadistica est;
while(fread(&est,sizeof (estadistica), 1, pFile)==1){
    est.verEstadisticas();
    }

}

void RecuperatorioPrimerParcial::nuncaRecibioAyuda(int leg){
ClasesParticularesArchivo obj;
int cantClases = obj.getCantidad();

ClaseParticular *vClases = new ClaseParticular[cantClases];

for(int x=0; x<cantClases; x++){
    vClases[x] = obj.leer(x);
    }

EstudiantesArchivo reg;
int cantEstu = reg.getCantidad();

Estudiante *vEstu = new Estudiante[cantEstu];

for(int x=0; x<cantEstu; x++){
    vEstu[x] = reg.leer(x);
}

//for(int x=0; x<cantClases; x++){
//    cout << vClases[x].getLegajoProfesor() << endl;
//}


for(int x=0; x<cantEstu; x++){
    int con=0;
    for(int i=0; i<cantClases; i++){
        if(vEstu[x].getLegajo()==vClases[i].getLegajoAlumno() && leg==vClases[i].getLegajoProfesor()){
            if(vClases[i].getDuracion()>0){
                con++;
            }

        }
    }

    if(con==0){
        cout << vEstu[x].getLegajo() << endl;
    }

}

}

//MacielNicolas 01-12 legajo24290
