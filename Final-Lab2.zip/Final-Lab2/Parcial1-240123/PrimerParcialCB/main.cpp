#include <iostream>
using namespace std;

#include "PrimerParcial.h"


int main() {
 PrimerParcial obj;

 obj.listarRecaudacion();
 cout <<" - - - -- - - - - - - " << endl;
 obj.soloUnCurso();
 cout <<" - - - -- - - - - - - " << endl;
 obj.generarEstadistica();
 cout <<" - - - -- - - - - - - " << endl;
// obj.mostraEstadistica();


  return 0;
}
