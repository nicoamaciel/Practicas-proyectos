#include <iostream>

using namespace std;
#include "fecha.h"

//Gets
    int fecha::getDia(){
        return _dia;
    }
    int fecha::getMes(){
        return _mes;
    }
    int fecha::getAnio(){
        return _anio;
    }

//Sets
    void fecha::setDia(int dia){
        _dia=dia;
    }
    void fecha::setMes(int mes){
        _mes=mes;
    }
    void fecha::setAnio(int anio){
        _anio=anio;
    }

//Comportamientos
    void fecha::cargarFecha(){
    int d,m,a;

    do{
        cout << "Dia: ";
        cin >> d;
        if(d<0 || d>31){
        cout << "Dia fuera de parametro ingrese nuevamente" << endl;
        system("pause");
        }
        else{
            setDia(d);
            }
    }while(d<0 || d>31);

    do{
        cout << "Mes: ";
        cin >> m;

        if(m<0 || m>12){
        cout << "Mes fuera de parametro ingrese nuevamente" << endl;
        system("pause");
        }
        else{
            setMes(m);
            }
    }while(m<0 || m>12);

    do{
        cout << "Anio: ";
        cin >> a;

        if(a<1800 || a>2030){
        cout << "Mes fuera de parametro ingrese nuevamente" << endl;
        system("pause");
        }
        else{
            setAnio(a);
            }
    }while(a<1800 || a>2030);




    }

    void fecha::mostrarFecha(){
    cout << getDia() << "/ " << getMes() << "/ " << getAnio() << endl;
    }

