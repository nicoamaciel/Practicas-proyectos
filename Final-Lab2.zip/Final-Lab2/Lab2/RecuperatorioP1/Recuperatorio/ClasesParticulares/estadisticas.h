#ifndef ESTADISTICAS_H_INCLUDED
#define ESTADISTICAS_H_INCLUDED

class estadistica{
private:
    int _curso;
    float _recaudacion;
public:
    int getCurso();
    int getRecaudacion();
    void setCurso(int cur);
    void setRecaudacion(float reca);
    void verEstadisticas();
};

//MacielNicolas 01-12 legajo24290
#endif // ESTADISTICAS_H_INCLUDED
