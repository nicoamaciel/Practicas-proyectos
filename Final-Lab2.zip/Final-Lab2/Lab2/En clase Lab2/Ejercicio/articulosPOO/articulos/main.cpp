/*
Un local de ventas de art�culos dispone de 10 art�culos a la venta, cada articulo tiene:

- C�digo (1-10)
- Nombre (string)
- Precio (float)
- Stock Disponible (int)

Nos piden hacer un programa para procesar las ventas que realizo el d�a anterior, cada venta esta compuesta por:

- C�digo de articulo
- Cantidad vendida

La carga de ventas finaliza con un C�digo de articulo igual a cero.

Antes de comenzar con las ventas, se deben cargar los 10 art�culos que tienen a la venta en ese d�a.

Informar:

1. Para cada venta, el monto de dicha venta
2. Mostrar la cantidad de stock disponible para cada uno de los art�culos del local


*/

#include <iostream>

using namespace std;

#include "clases.h"

int main()
{
    articulos vObj[3];



    int opcion, codigo_articulo, cantidad_vendida;


    while(true){
    system("cls");
    cout << " - - - - - MENU - - - - - " << endl;
    cout << "1 - CARGAR DIEZ ARTICULOS" << endl;
    cout << "2 - CARGAR VENTAS DEL DIA ANTERIOR" << endl;
    cout << "3 - MOSTAR ARTICULOS CARGADOS" << endl;
    cout << "0 - SALIR" << endl;
    cin >> opcion;
    system("cls");
    switch(opcion){
    case 1:
        for (int i=0; i<3; i++){
            vObj[i].cargarArticulo();
        }

        break;
    case 2:
        cout << "Codigo de articulo: ";
        cin >> codigo_articulo;

        while(codigo_articulo!=0){
            cout << "Cantidad vendida: ";
            cin >> cantidad_vendida;


            for (int i=0; i<3; i++){
                if(codigo_articulo == vObj[i].getCodigo()){
                    vObj[i].restarStock(cantidad_vendida);
                }
            }

        cout << " - - - - - - - - - - - - - - " << endl;
        cout << "Codigo de articulo: ";
        cin >> codigo_articulo;
        }
        break;
    case 3:
         for (int i=0; i<3; i++){
            vObj[i].mostarArticulos();
        }

        break;
    case 0: return 0;
        break;
    }








    system("pause");
    }






    return 0;
}
