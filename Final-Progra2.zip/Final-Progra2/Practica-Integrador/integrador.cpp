#include <iostream>
#include <cstring>
#include <cstdlib>
using namespace std;

#include "clases_p.h"


/*
1-Generar un archivo con la cantidad de reservas que cada restaurante de la categor�a 2 tuvo el a�o pasado.
Cada registro debe tener el siguiente formato:

-   C�digo de restaurante,
-   nombre de restaurante,
-   cantidad de reservas del a�o pasado.

2- Informar el mes de este a�o con m�s cantidad de reservas.

*/


int main (){

return 0;
}
