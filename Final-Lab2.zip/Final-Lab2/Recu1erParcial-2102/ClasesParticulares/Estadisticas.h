#ifndef ESTADISTICAS_H_INCLUDED
#define ESTADISTICAS_H_INCLUDED

class Estadisticas{
private:
    int _curso;
    float _recaudacion;

public:
    int getCurso();
    float getRecaudacion();
    void setCurso(int cur);
    void setRecaudacion(float reca);
    void verEstadisticas();

};



#endif // ESTADISTICAS_H_INCLUDED
//private:
//    int _anio;
//    float _recaudacion;
//public:
//    int getRecaudacion();
//    int getAnio();
//    void setAnio(int an);
//    void setRecaudacion(float reca);
//    void add(float reca);
//    void verEstadisticas();
//
