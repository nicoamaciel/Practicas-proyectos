#ifndef EGRESO_H_INCLUDED
#define EGRESO_H_INCLUDED

class egreso{

private:
    int _Dni;
    int _HoraEgreso;

public:
    //Gets

    int getDni();
    int getHoraEgreso();
    //Sets
    void setDni(int);
    void setHoraEgreso(int);

    //Comportamiento

    void cargarEgreso();


};

#endif // EGRESO_H_INCLUDED
