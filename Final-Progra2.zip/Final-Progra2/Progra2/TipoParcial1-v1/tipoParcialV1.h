#ifndef TIPOPARCIALV1_H_INCLUDED
#define TIPOPARCIALV1_H_INCLUDED

#include <cstring>
#include <iostream>
using namespace std;
class Empresa{
private:

    int numeroEmpresa;//(no se repite en el archivo. Es �nico para cada empresa)
    char nombreEmpresa[30];//(char[30])
    int cantidadEmpleados;
    int Categoria; //(1 a 80)
    int Municipio;//(1 a 135)
    bool Estado;


public:

    //gets() para todas las propiedades
	int getNumeroEmpresa(){return numeroEmpresa;}
    const char *getNombreEmpresa(){return nombreEmpresa;}
    int getCantidadEmpleados(){return cantidadEmpleados;}
    int getCategoria(){return Categoria;}
    int getMunicipio(){return Municipio;}
    bool getEstado(){return Estado;}

	//sets() para todas las propiedades
	void setNumeroEmpresa(int numEmp){ numeroEmpresa = numEmp;}
    void setNombreEmpresa(const char *n){strcpy(nombreEmpresa,n);}
    void setCantidadEmpleados(int can){cantidadEmpleados = can;}
    void setCategoria(int catego){Categoria = catego;}
    void setMunicipio(int muni){Municipio = muni;}
    void SetEstado(bool est) {Estado=est;}

    //Comportamiento
    void Cargar();
    void Mostrar();
    bool grabarEnDisco();
    bool leerDeDisco(int);

	//bool leerDeDisco(int) para leer un registro del archivo


};

void Empresa::Cargar(){
int numEmp, cant, cate, muni;
char nom[30];
bool est;


    cout << "Cargar numero de empresa: ";
    cin >> numEmp;
    cout << "Cargar nombre empresa: ";
    cin >> nom;
    cout << "Cargar cantidad de empleados: ";
    cin >> cant;
    cout << "Cargar categoria: ";
    cin >> cate;
    cout << "Cargar numero de municipio: ";
    cin >> muni;
    est=true;

    setNumeroEmpresa(numEmp);
    setNombreEmpresa(nom);
    setCantidadEmpleados(cant);
    setCategoria(cate);
    setMunicipio(muni);
    SetEstado(est);


}

void Empresa::Mostrar(){
    if(Estado == true){
        cout << "Numero de empresa: " << getNumeroEmpresa() << endl;
        cout << "Nombre empresa: " << getNombreEmpresa() << endl;
        cout << "Cantidad de empleados: " << getCantidadEmpleados() << endl;
        cout << "Categoria: " << getCategoria() <<endl;
        cout << "Numero de municipio: " << getMunicipio() << endl;
    }

}

bool Empresa::grabarEnDisco(){
FILE *p = fopen("empresa.dat", "ab");
if(p == NULL) return false;
bool escribio = fwrite(this, sizeof(Empresa),1,p);
fclose(p);
return escribio;
}

bool Empresa::leerDeDisco(int pos){
bool leyo;
FILE *pEmp;
pEmp = fopen("empresa.dat","rb");
if(pEmp == NULL){
    return false;
}
fseek(pEmp, pos*sizeof(Empresa),0);
leyo = fread(this, sizeof(Empresa),1,pEmp);
fclose(pEmp);
return leyo;
}



class Municipio{
private:
    int numero;
    char nombreMunicipio[30];
    int seccion, cantidadHabitantes;
    bool estado;

public:
    //gets() para todas las propiedades
    int getNumero(){return numero;}
    const char *getNombreMunicipio(){return nombreMunicipio;}
    int getSeccion(){return seccion;}
    int getCantidadHabitantes(){return cantidadHabitantes;};
    bool getEstado(){return estado;}

	//sets() para todas las propiedades

	void setNumero(int num){numero=num;}
    void setNombreMunicipio(const char *mun){strcpy(nombreMunicipio,mun);}
    void setSeccion(int sec){seccion=sec;}
    void setCantidadHabitantes(int canH){cantidadHabitantes=canH;}
    void setEstado(bool est){estado=est;}



    //bool leerDeDisco(int) para leer un registro del archivo

    //Comportamiento
    void Cargar();
    void Mostrar();
    bool grabarEnDisco();
    bool leerDeDisco(int);


};

    void Municipio::Cargar(){
    int num;
    char nomMun[30];
    int sec, canHab;
    bool est;
    cout << "Cargar numero de municipio: ";
    cin >> num;
    cout << "Cargar nombre de municipio: ";
    cin >>nomMun;
    cout << "Cargar seccion: ";
    cin >>sec;
    cout << "Cargar cantidad de habitantes: ";
    cin >>canHab;
    est = true;

    setNumero(num);
    setNombreMunicipio(nomMun);
    setSeccion(sec);
    setCantidadHabitantes(canHab);
    setEstado(est);

    }
    void Municipio::Mostrar(){

        if(estado == true){
        cout << "Numero de municipio: " << getNombreMunicipio() << endl;
        cout << "Nombre de municipio: " << getNumero() << endl;
        cout << "Seccion: " << getSeccion() << endl;
        cout << "Cantidad de habitantes: " << getCantidadHabitantes() <<endl;
        }

    }
    bool Municipio::grabarEnDisco(){
        FILE *pMun;
        pMun = fopen("municipios.dat","ab");
        if(pMun==NULL){
            return false;
        }
        bool escribio = fwrite(this,sizeof(Municipio),1,pMun);
        fclose(pMun);
        return escribio;
    }
    bool Municipio::leerDeDisco(int pos){
        bool leyo;
        FILE *pMun;
        pMun = fopen("municipios.dat","rb");
        if(pMun==NULL){
            return false;
        }
        fseek(pMun,pos*sizeof(Municipio),0);
        leyo = fread(this,sizeof(Municipio),1,pMun);
        fclose(pMun);
        return leyo;

    }


class Categoria{
    private:
        int numeroCategoria;
        char nombreCategoria[30];
        bool esencial;
        bool estado;
    public:
    ///gets() para todas las propiedades
        int getNumeroCategoria(){return numeroCategoria;}
        const char *getNombreCategoria(){return nombreCategoria;}
        bool getEsencial(){return esencial;}
        bool getEstado(){return estado;}

	///sets() para todas las propiedades

        void setNumeroCategoria(int num){numeroCategoria=num;}
        void setNombreCategoria(const char *nomCat){strcpy(nombreCategoria,nomCat);}
        void setEsencial(bool es){esencial=es;}
        void setEstado(bool esta){estado=esta;}


	///bool leerDeDisco(int) para leer un registro del archivo

    //Comportamiento
    void Cargar();
    void Mostrar();
    bool grabarEnDisco();
    bool leerDeDisco(int);

};

    void Categoria::Cargar(){
    int num;
    char nomCat[30];
    bool ese;
    bool est;
    cout << "Cargar numero de categoria: ";
    cin >> num;
    cout << "Cargar nombre de categoria: ";
    cin >>nomCat;
    cout << "Escencial ? 1-si 0-no: ";
    cin >>ese;
    est = true;

    setNumeroCategoria(num);
    setNombreCategoria(nomCat);
    setEsencial(ese);
    setEstado(est);
    }
    void Categoria::Mostrar(){
        cout << "Numero de categoria: " << getNumeroCategoria() << endl;
        cout << "Nombre de categoria: " << getNombreCategoria() << endl;
        cout << "Escencial: " << getEsencial() << endl;

    }
    bool Categoria::grabarEnDisco(){
        FILE *pCat;
        pCat = fopen("categorias.dat","ab");
        if(pCat==NULL){
            return false;
        }
        bool escribio = fwrite(this,sizeof(Categoria),1,pCat);
        fclose(pCat);
        return escribio;
    }
    bool Categoria::leerDeDisco(int pos){
        bool leyo;
        FILE *pCat;
        pCat = fopen("categorias.dat","rb");
        if(pCat==NULL){
            return false;
        }
        fseek(pCat,pos*sizeof(Categoria),0);
        leyo = fread(this,sizeof(Categoria),1,pCat);
        fclose(pCat);
        return leyo;


    }







#endif // TIPOPARCIALV1_H_INCLUDED
