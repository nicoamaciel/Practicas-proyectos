
/*
Cerca de la facultad hay un puesto de batidos llamado �**MaxiBatidos**� que es atendido por una persona de pelo largo y lacio�

En ella vende 3 tipo de batidos, para ello tienen 1 bid�n de 20L con sabor �Banana�,
1 bid�n de 35L con sabor a �Anan� y otra bid�n de 44L con sabor a �Sandia�

Siempre al comenzar el d�a llenan los 3 bidones para comenzar a vender.

Nos piden hacer un programa para procesar las ventas del d�a, cada venta esta compuesta por:

- C�digo de Batido (1- Banana, 2- Anan� y 3 - Sandia)
- Tipo de Vaso (1-  150 ml, 2- 200ml, 3- 300ml)

La carga de ventas finaliza con un C�digo de Batido igual a cero.

Informar:

Para cada tipo de batido, cuanto fue lo que le quedo al finalizar el d�a.


*/
#include <iostream>

using namespace std;
#include "funciones.h"


int main()
{

    float vasos[3] = {0.15, 0.2, 0.3};

    bidones vBidon[3] =
    {
    bidones(35,"Anana"),
    bidones(20, "Banana"),
    bidones(44,"Sandia")
    };

    int tipo_vasos, numero_batido;


    cout << "Ingrese numero de batido: ";
    cin >> numero_batido;
    while (numero_batido != 0){
    cout << "Ingrese tipo de vaso: ";
    cin >> tipo_vasos;



    vBidon[numero_batido - 1].extraerLitros(vasos[tipo_vasos - 1 ]);


    cout << "Ingrese numero de batido: ";
    cin >> numero_batido;
    }
    cout << "---------------------" << endl;


 for(int x=0; x<3; x++){
    cout << vBidon[x].getNombres() << ": " << vBidon[x].getLitros() << endl;



 }


    return 0;
}
