#ifndef SEGUNDOPARCIAL_H_INCLUDED
#define SEGUNDOPARCIAL_H_INCLUDED

class SegundoParcial{
private:


public:
    void alumnosDesaprobados();
    void peorCurso();
    void verGeneraciones();
    void generarReporte();
    void mostrarReporte();

};


#endif // SEGUNDOPARCIAL_H_INCLUDED
