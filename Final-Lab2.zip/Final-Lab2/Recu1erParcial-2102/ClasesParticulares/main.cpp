#include <iostream>
using namespace std;

#include "recuperatorio.h"

int main() {
    Recuperatorio recu;
//    recu.cursosConMayorAyuda();
//    cout << endl;
//    cout << "- - - - - - - - - - - - - " << endl;
//    recu.alumnosConPocaAyuda();
//    cout << endl;
//    cout << "- - - - - - - - - - - - - " << endl;
//    recu.generarEstadisticasAyuda();
//    recu.mostrarEstadisticas();
    recu.nuncaRecibioAyuda(1000);
  return 0;
}
