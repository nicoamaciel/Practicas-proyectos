#ifndef REPORTES_H_INCLUDED
#define REPORTES_H_INCLUDED

class Reportes{
private:
    int _curso;
    float _aprobados;
    float _desaprobados;
public:
    int getCurso();
    float getAprobados();
    float getDesaprobados();
    void setCurso(int cur);
    void setAprobados(float apr);
    void setDesaprobados(float des);

    void verReportes();

};

#endif // REPORTES_H_INCLUDED
//private:
//    int _anio;
//    float _recaudacion;
//public:
//    int getRecaudacion();
//    int getAnio();
//    void setAnio(int an);
//    void setRecaudacion(float reca);
//    void add(float reca);
//    void verEstadisticas();
//
