#include "Ciudad.h"
#include <cstring>
#include <cstdio>
#include <iostream>
using namespace std;

int  Ciudad::getID()
{
    return _ID;
}
char * Ciudad::getNombre()
{
    return _nombre;
}
char * Ciudad::getIDPais()
{
    return _idpais;
}
int  Ciudad::getPoblacion()
{
    return _poblacion;
}
void Ciudad::setID(int val)
{
    _ID = val;
}
void Ciudad::setNombre(const char * val)
{
    strcpy(_nombre, val);
}
void Ciudad::setIDPais(const char * val)
{
    strcpy(_idpais, val);
}
void Ciudad::setPoblacion(int val)
{
    _poblacion = val;
}
void Ciudad::mostrar(){
    cout << _ID << " " << _idpais << " " << _nombre << " " << _poblacion << endl;
}

bool buscarId(){
int id;
cout << "Ingresar id: ";
cin >> id;
Ciudad reg;
FILE *pCity = fopen("ciudades.dat","rb");
if(pCity==nullptr){return false;}

while(fread(&reg,sizeof(Ciudad),1,pCity)==1){
        if(reg.getID() == id){
         return true;
        }

    }
}


void leerCiudad(){
Ciudad reg;
FILE *pCity = fopen("ciudades.dat","rb");
if(pCity==nullptr){cout << "Error de lectura";}

while (fread(&reg, sizeof(Ciudad),1,pCity)==1){
    reg.mostrar();
    cout << endl;
}


}

