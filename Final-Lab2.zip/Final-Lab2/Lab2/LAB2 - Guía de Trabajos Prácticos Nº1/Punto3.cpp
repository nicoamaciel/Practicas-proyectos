//3
//Hacer una funci�n que reciba como par�metros un vector
//de enteros, su tama�o y un valor entero a buscar y que devuelva en qu� posici�n se encuentra el valor dentro del vector.
//En caso de no encontrarlo, devolver -1.


#include <iostream>
using namespace std;

//Definicion de funcion

int buscarPosicion(int *vEnteros, int TAMANIO);
void leerVector(int *vEnteros, int TAMANIO);




int main(){

int const TAMANIO=10;
int posicion=0;


int vEnteros[TAMANIO]{2,7,8,9,25,14,253,1,69,12};

leerVector(vEnteros, TAMANIO);
posicion = buscarPosicion(vEnteros, TAMANIO);

cout << "Posicion: " << posicion;


return 0;
}




//Declaracion de funcion

int buscarPosicion(int *vEnteros, int TAMANIO){

int pos, devolver=-1;


cout << "Buscar posicion x valor: ";
cin >> pos;

for (int x=0; x<TAMANIO; x++){

    if(pos==vEnteros[x]){
        devolver = x;
    }
}


  return devolver;



}


void leerVector(int *vEnteros, int TAMANIO){


for (int y=0; y<TAMANIO; y++){

    cout << vEnteros[y] << ", ";

}
cout << endl;


}
