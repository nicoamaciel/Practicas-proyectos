
===============================================================================================
===============================================================================================
Usco con strcmp

desde .h -->> Pais.h 

bool buscarPais();

===============================================================================================
===============================================================================================

desde .cpp -->> Pais.cpp

bool buscarPais(){
char cod[4];
cout << "Ingrese codigo de pais: ";
cin >> cod;

Pais reg;
int comp;
FILE *pPais = fopen("paises.dat","rb");
if(pPais==nullptr){return false;}

while(fread(&reg,sizeof(Pais),1,pPais)==1){
    comp = strcmp(cod,reg.getCodigo());
    if(comp==0){
        return true;
	    }

	}

}

===============================================================================================

if(buscarId())
{
 cout << "Id de ciudad ya ingresado previamente"<<endl;
	}
	else{
               if(buscarPais()==false){
               cout << "Cod de pais no existe en el archivo"<<endl;
               }
		else{
                    cargarCiudad();
                    grabarCiudad();
                }

            }

