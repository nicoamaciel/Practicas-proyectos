#ifndef COMENTARIOARCHIVO_H_INCLUDED
#define COMENTARIOARCHIVO_H_INCLUDED

#include "Comentarios.h"
class comentarioArchivo
{
public:
  comentario leer(int nroRegistro);
  int getCantidad();
};


#endif // COMENTARIOARCHIVO_H_INCLUDED
