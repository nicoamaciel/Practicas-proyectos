
#include <iostream>
using namespace std;
#include "modelo.h"
#include "ExamenesArchivo.h"
#include "EstudiantesArchivo.h"



void modelo::punto1(){
ExamenesArchivo exa;

int cantExa =0;

cantExa = exa.getCantidad();


Examen *examenes = new Examen[cantExa];

for(int i=0; i<cantExa; i++){
    examenes[i] = exa.leer(i);
    }



    for(int j=0; j<cantExa; j++){
        if(examenes[j].getFecha().getAnio() != 2022){
            buscarLegajo(examenes[j].getLegajo());
        cout << "- - - - - - - - - - - - - - - - - - " << endl;
        }
    }

    delete []examenes;


}


void modelo::buscarLegajo(int leg){
EstudiantesArchivo est;
int cantEst =0;

cantEst = est.getCantidad();
Estudiante *estu = new Estudiante[cantEst];

for(int i=0; i<cantEst; i++){
    estu[i] = est.leer(i);

}

for(int j=0; j<cantEst; j++){
    if(leg==estu[j].getLegajo()){
        cout << estu[j].getLegajo() << endl;
        cout << estu[j].getNombres() << endl;
        cout << estu[j].getApellidos() << endl;
    }

}

delete []estu;
}




void modelo::punto2(){

EstudiantesArchivo est;
int cantEst =0;

cantEst = est.getCantidad();
Estudiante *estu = new Estudiante[cantEst];

for(int i=0; i<cantEst; i++){
    estu[i] = est.leer(i);

}
cout << "Legajo - Nombre - Apellido" << endl;
cout << "- - - - - - - - - - - - " << endl;
for(int j=0; j<cantEst; j++){
 cout << estu[j].getLegajo()<< "    " << estu[j].getNombres()<< "    " << estu[j].getApellidos()<< endl;
 cout << "Aprobo: " << aprobo(estu[j].getLegajo()) << endl;
 cout << "Desaprobo: " << desaprobo(estu[j].getLegajo()) << endl;
 cout << "----------------------" << endl;
}
cout << "- - - - - - - - - - - - " << endl;



delete []estu;

}


int modelo::aprobo(int leg){
ExamenesArchivo exa;
int cantExa =0;
cantExa = exa.getCantidad();


Examen *examenes = new Examen[cantExa];

for(int i=0; i<cantExa; i++){
    examenes[i] = exa.leer(i);
    }

int apr=0;

    for(int j=0; j<cantExa; j++){
        if(examenes[j].getLegajo()== leg && examenes[j].getNota() >= 6){
        apr++;
        }
    }

    delete []examenes;
    return apr;
}


int modelo::desaprobo(int leg){
ExamenesArchivo exa;
int cantExa =0;
cantExa = exa.getCantidad();


Examen *examenes = new Examen[cantExa];

for(int i=0; i<cantExa; i++){
    examenes[i] = exa.leer(i);
    }

int desa=0;

    for(int j=0; j<cantExa; j++){
        if(examenes[j].getLegajo()== leg && examenes[j].getNota() < 6){
        desa++;
        }
    }

    delete []examenes;
    return desa;
}



void modelo::punto3(){


EstudiantesArchivo est;
int cantEx = est.getCantidad();

Estudiante *estu = new Estudiante[cantEx];

for(int i=0; i<cantEx; i++){
    estu[i] = est.leer(i);
}

int cantidadAlumnos=0;



for (int j=0; j<cantEx; j++){
    if(siRindio(estu[j].getLegajo())){
        cantidadAlumnos++;
    }

}

cout << "Cantidad de alumnos que rindieron mas de una vez: " << cantidadAlumnos << endl;

}


bool modelo::siRindio(int leg){

ExamenesArchivo exa;
int cantExa =0;
cantExa = exa.getCantidad();


Examen *examenes = new Examen[cantExa];

for(int i=0; i<cantExa; i++){
    examenes[i] = exa.leer(i);
    }



    for(int j=0; j<cantExa; j++){
        int rindio=0;
        if(leg == examenes[j].getLegajo()){
        if(examenes[j].getFecha().getAnio()>=2018 && examenes[j].getFecha().getAnio()<=2022){
            rindio++;

            }

        }else{
            if(examenes[j].getFecha().getAnio()>=2018 && examenes[j].getFecha().getAnio()<=2022){
            rindio++;
            }

        }

        if(rindio>2){
            return true;
        }

    }

    delete []examenes;




}



