/*

1)El nombre del tipo de combustible que haya registrado el precio por litro m�s caro. Si
existe m�s de un tipo de combustible que cumpla esta condici�n, mostrar el primero
que encuentren en el archivo.

2) A partir de un IDEstaci�n que se ingresa como par�metro, mostrar los meses en los
que no se haya vendido Nafta S�per en esa estaci�n.

3)  El nombre del tipo de combustible que haya registrado el precio por litro promedio
m�s caro. Mostrar todos los tipos de combustibles que cumplan esta condici�n.

4) Hacer un archivo llamado Anuario.dat que a partir de un a�o que se ingrese por
teclado genere un resumen mensual con el total de litros de combustibles vendidos
en ese a�o y mes (en total se deben generar 12 registros).

Aclaraciones:
- El archivo Anuario.dat debe contener solamente el resumen del �ltimo a�o
que se ingres�.

- Si el a�o ingresado no tiene litros acumulados para ninguno de los 12 meses,
entonces no debe generar el anuario y mostrar un mensaje aclaratorio al
usuario.

*/


#include <iostream>
#include "macielNicolas.h"
using namespace std;

#include "ResumenDiarioArchivo.h"
#include "ResumenDiario.h"


void modelo::punto1(){
ResumenDiarioArchivo obj;
int cant = obj.getCantidad();

ResumenDiario *vecEstaciones = new ResumenDiario[cant];

for(int i=0; i<cant; i++){
    vecEstaciones[i] = obj.leer(i);
}
    int precioMasCaro=0;
    int idMasCaro=0;

    for(int i=0; i<cant; i++){
        if(vecEstaciones[i].getPrecioPorLitro()>precioMasCaro){
            precioMasCaro=vecEstaciones[i].getPrecioPorLitro();
            idMasCaro=vecEstaciones[i].getIDTipoCombustible();
        }

    }

    buscarCombus(idMasCaro);



delete []vecEstaciones;

}

void buscarCombus(int id){

if(id==1){
    cout << "Nafta super"<<endl;
}

if(id==2){
    cout << "Nafta comun"<<endl;
}

if(id==3){
    cout << "Diesel"<<endl;
}

if(id==4){
    cout << "Gasoil"<<endl;
}

if(id==5){
    cout << "Gnc"<<endl;
}



}

void modelo::punto2(){

ResumenDiarioArchivo obj;
int cant = obj.getCantidad();

ResumenDiario *vecEstaciones = new ResumenDiario[cant];

int idEstacion;
cout << "Ingrese estacion: ";
cin >> idEstacion;

    for(int i=0; i<cant; i++){
        vecEstaciones[i] = obj.leer(i);
    }
    int precioMasCaro=0;
    int idMasCaro=0;

    int vecMesesConNafta[12]{};

    for(int i=0; i<cant; i++){
        if(idEstacion==vecEstaciones[i].getIDEstacion() && vecEstaciones[i].getIDTipoCombustible()==1){
            vecMesesConNafta[vecEstaciones[i].getFecha().getMes()-1]++;
        }
    }

    buscarMeses(vecMesesConNafta,12);

delete []vecEstaciones;


}



void buscarMeses(int *vecMesesConNafta, int tam){
    cout << "Mes sin nafta super: " << endl;
    for(int x=0; x<tam; x++){
        if(vecMesesConNafta[x]==0){
            cout << x+1 << " ";
        }
    }

}


void modelo::punto3(){

ResumenDiarioArchivo obj;
int cant = obj.getCantidad();

ResumenDiario *vecEstaciones = new ResumenDiario[cant];



for(int i=0; i<cant; i++){
    vecEstaciones[i] = obj.leer(i);
}


int vecLitros[5]{};
int vecContador[5]{};

for(int i=0; i<cant; i++){
    if(vecEstaciones[i].getIDTipoCombustible()==1){
        vecLitros[0] += vecEstaciones[i].getPrecioPorLitro();
        vecContador[0] ++;
    }

    if(vecEstaciones[i].getIDTipoCombustible()==2){
        vecLitros[1] += vecEstaciones[i].getPrecioPorLitro();
        vecContador[1] ++;
    }

    if(vecEstaciones[i].getIDTipoCombustible()==3){
        vecLitros[2] += vecEstaciones[i].getPrecioPorLitro();
        vecContador[2] ++;
    }

    if(vecEstaciones[i].getIDTipoCombustible()==4){
        vecLitros[3] += vecEstaciones[i].getPrecioPorLitro();
        vecContador[3] ++;
    }

    if(vecEstaciones[i].getIDTipoCombustible()==5){
        vecLitros[4] += vecEstaciones[i].getPrecioPorLitro();
        vecContador[4] ++;
    }

}

int vecPromedios[5]{};
int maxPromedio=0;
int maxPosicion=0;

for(int x=0; x<5; x++){
    vecPromedios[x] += vecLitros[x]/vecContador[x];
    if(vecPromedios[x]>maxPromedio){
        maxPromedio=vecPromedios[x];
        maxPosicion=x;
    }

}

cout << "Combustible: ";
buscarCombus(maxPosicion+1);
cout << "Max promedio: " << maxPromedio;


delete []vecEstaciones;



}


void modelo::punto4(){

ResumenDiarioArchivo obj;
int cant = obj.getCantidad();

ResumenDiario *vecEstaciones = new ResumenDiario[cant];

int anio;
cout << "Anuario: " << endl;
cout << "Ingrese estacion: ";
cin >> anio;

    for(int i=0; i<cant; i++){
        vecEstaciones[i] = obj.leer(i);
    }

    int vecMesesCombu[12]{};

    for(int i=0; i<cant; i++){
        if(anio==vecEstaciones[i].getFecha().getAnio()){
        vecMesesCombu[vecEstaciones[i].getFecha().getMes()-1]+=vecEstaciones[i].getLitrosIniciales()-vecEstaciones[i].getLitrosFinales();
        }
    }

    for(int x=0; x<12; x++){
        cout << x+1 <<"   "<<vecMesesCombu[x]<<endl;

    }


delete []vecEstaciones;



}



