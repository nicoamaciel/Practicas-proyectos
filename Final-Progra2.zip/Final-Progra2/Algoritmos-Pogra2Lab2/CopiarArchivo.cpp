=======================================================================================================
=======================================Asignar valor con operador======================================
=======================================================================================================

4-Crear un vector dinámico para copiar y mostrar el archivo luego de las modificaciones del punto 2.


//Clase con perator de asignacion

class modificarArchivo{
private:
    int numero;
    int legajoProgramador;
    int codigoProyecto;
    int localidad;
    Fecha fechaAsignacion;
    bool estado;

    public:
    void setNumero(int num){numero=num;}
    void setLegajoProgramador(int leg){legajoProgramador=leg;}
    void setCodigoProyecto(int cP){codigoProyecto=cP;}
    void setLocalidad(int loc){localidad=loc;}
    void setFechaAsignacion(Fecha fe){fechaAsignacion=fe;}
    void setEstado(bool e){estado = e;}


        void Mostrar(){
            cout<<"NUMERO "<<numero<<endl;
            cout<<"LEGAJO "<<legajoProgramador<<endl;
            cout<<"CODIGO "<<codigoProyecto<<endl;
            cout<<"LOCALIDAD "<<localidad<<endl;
            fechaAsignacion.Mostrar();
            cout<<endl;
        }

    void operator=(Asignacion &reg){
        numero=reg.getNumero();
        legajoProgramador=reg.getLegajoProgramador();
        codigoProyecto=reg.getCodigoProyecto();
        localidad=reg.getLocalidad();
        fechaAsignacion.setDia(reg.getFechaAsignacion().getDia());
        fechaAsignacion.setMes(reg.getFechaAsignacion().getMes());
        fechaAsignacion.setAnio(reg.getFechaAsignacion().getDia());
        estado=reg.getEstado();
    }


};


//Prototipos 
void punto3();
    int contarFalse();
    void copiarFalse(Asignacion *pFalse);
    void mostrarFalse(Asignacion *pFalse, int cant);



=======================================================================================================
=======================================================================================================
=======================================================================================================

void punto3(){
Asignacion *pFalse;
int cant = contarFalse();

pFalse = new Asignacion[cant];
if(pFalse==NULL){"Error";}
copiarFalse(pFalse);
mostrarFalse(pFalse,cant);

delete []pFalse;

}

int contarFalse(){
Asignacion reg;
int pos=0, cant=0;

while(reg.leerDeDisco(pos)){
    if(reg.getEstado()==false && reg.getFechaAsignacion().getAnio()==2021){
        cant++;
    }

    pos++;
}
return cant;

}


void copiarFalse(Asignacion *pFalse){
Asignacion reg;
int pos=0, i=0;

while(reg.leerDeDisco(pos)){
    if(reg.getEstado()==false && reg.getFechaAsignacion().getAnio()==2021){
        pFalse[i++]=reg;
    }

    pos++;
}

}


void mostrarFalse(Asignacion *pFalse, int cant){

for(int i=0; i<cant; i++){
    pFalse[i].Mostrar();
    cout << endl;
    }

}



