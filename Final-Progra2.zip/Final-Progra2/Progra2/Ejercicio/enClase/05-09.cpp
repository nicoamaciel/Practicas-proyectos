#include <iostream>
using namespace std;

class empresa{
private:
        int numeroDeEmpresa; //(N�mero entero. No se repite en el archivo. Es �nico para cada empresa)
        char nombre[30];
        int cantidadEmpleados;
        int categoria;
        int numeroMunicipio;//(1 a 135)
        bool estado;

public:
///GETS
    int getCantidadEmpleados(){
        return cantidadEmpleados;
    }
    int getNumeroMunicipio(){
        return numeroMunicipio;
    }
    char *getNombre(){
        return nombre;
    }

    int getCategoria(){
        return categoria;
    }

///SETS


///COMPORTAMIENOTS

    void Cargar();
    void Mostrar();


};

void empresa::Cargar(){
cout << "Cargar numero de empresa: ";
cin >> numeroDeEmpresa;
cout << "Cargar nombre: ";
cin >> nombre;
cout << "Cargar cantidad empleados: ";
cin >> cantidadEmpleados;
cout << "Cargar categoria: ";
cin >> categoria;
cout << "Cargar numero de municipio: ";
cin >> numeroMunicipio;
estado=true;
cout << " - - - - - - - - - - - - -" << endl;
}

void empresa::Mostrar(){
    if(estado==true){
        cout << "Numero de empresa: " << numeroDeEmpresa << endl;
        cout << "Nombre: " << nombre << endl;
        cout << "Cantidad empleados: " << cantidadEmpleados << endl;
        cout << "Cargar categoria: " << categoria << endl;
        cout << "Numero de municipio: " << numeroMunicipio << endl;
        cout << " - - - - - - - - - - - - -" << endl;
    }

}

class municipios{
private:
    int numero;// (1 a 135)
    char nombre[30];
    int seccion; //(1 a 9)
    int cantidadHabitantes;
    bool estado; //(bool)



public:


    //Gets
    int getNumero(){
        return numero;
    }
    char *getNombre(){
        return nombre;
    }
    int getSeccion(){
        return seccion;
    }
    int getCantidadHabitantes(){
        return cantidadHabitantes;
    }

    //Sets

    //Comportamiento

    void CargarMunicipios();
    void MostrarMunicipios();

};

void municipios::CargarMunicipios(){
    cout << "Cargar numero de municipio: ";
    cin >> numero;
    cout << "Cargar nombre de municipio: ";
    cin >> nombre;
    cout << "Cargar seccion 1-9: ";
    cin >> seccion;
    cout << "Cargar cantidad de habitantes: ";
    cin >> cantidadHabitantes;
    estado = true;
    cout << " - - - - - - - - - - - - -" << endl;
}

void municipios::MostrarMunicipios(){
    if(estado = true){
        cout << "Numero de municipio: " << getNumero() << endl;
        cout << "Nombre de municipio: " << getNombre() << endl;
        cout << "Seccion: " << getSeccion() << endl;
        cout << "Cantidad de habitantes: " << getCantidadHabitantes() << endl;
        cout << " - - - - - - - - - - - - -" << endl;
    }

}




///PrototiposEmpresa
int grabarRegistro(empresa);
void leerRegistro();
void punto1();
void punto2();
void punto3();
int maximoVector(int*,int);
///PrototiposMunicipios

int grabarMunicipio (municipios);
void leerMunicipio();


int main(){
    int const TAM=5;

    empresa obj[TAM];
    municipios obj2[TAM];
    int opc;

    while(true){
        system("cls");
        cout << "-----MENU EMPRESA----"<<endl;
        cout << "1. CARGAR EMPRESAS "<<endl;
        cout << "2. LEER DE DISCO"<<endl;
        cout << "3. PUNTO 2"<<endl;
        cout << "4. MUNICIPIOS"<<endl;
        cout << "0. SALIR"<<endl;
        cout << "OPCION: "<<endl;
        cin >>opc;
        system("cls");
        switch(opc){
            case 1:
                    for(int x=0; x<TAM; x++){
                        obj[x].Cargar();
                        grabarRegistro(obj[x]);

                    }



                    break;
            case 2:
                    leerRegistro();
                    break;
            case 3:
                    int resolucion2;
                    system("cls");
                    cout << "-----MENU PUNTO 2----"<<endl;
                    cout << "1. Cantidad de empresas de cada municipio "<<endl;
                    cout << "2. Empresas con mas de 200 empleados"<<endl;
                    cout << "3. Categoria de empresa con mas empleados"<<endl;
                    cout << "Opcion: "<<endl;
                    cin >> resolucion2;
                    system("cls");
                    switch(resolucion2){
                    case 1:
                        punto1();
                        break;
                    case 2:
                        punto2();
                        break;
                    case 3:
                        punto3();
                        break;
                    }
                    break; ///FinalizaPunto2
            case 4:
                    int muni;
                    system("cls");
                    cout << "-----MUNICIPIO----"<<endl;
                    cout << "1. CARGAR MUNICIPIO"<<endl;
                    cout << "2. MOSTAR MUNICIPIOS "<<endl;
                    cout << "3. "<<endl;
                    cout << "Opcion: "<<endl;
                    cin >> muni;
                    system("cls");
                    switch(muni){
                    case 1:
                        for(int x=0; x<TAM; x++){
                        obj2[x].CargarMunicipios();
                        grabarMunicipio(obj2[x]);
                        }
                        break;
                    case 2:
                        leerMunicipio();
                        break;
                break;
                }///FinSwitchMunicipio
            case 0: return 0;
                    break;
        }
        cout<<endl;
        system("pause");

    }


    cout << endl;


return 0;
}


int grabarRegistro(empresa aux){
    FILE *pEmpresa;
    pEmpresa=fopen("empresa.dat", "ab");
    if(pEmpresa==NULL){
        cout << "ERROR DE ARCHIVO"<<endl;
        system("PAUSE");
        return -1;
    }


    int escribio=fwrite(&aux, sizeof aux, 1, pEmpresa);
    fclose(pEmpresa);
    return escribio;
}
void leerRegistro(){
    FILE *pEmpresa;
    empresa aux;
    pEmpresa=fopen("empresa.dat", "rb");
    if(pEmpresa==NULL){
        cout << "ERROR DE ARCHIVO"<<endl;
        system("PAUSE");
        return;
    }


    while(fread(&aux,sizeof aux, 1, pEmpresa)==1){
        aux.Mostrar();
        cout << endl;

    }
}

void punto1(){
FILE *pEmpresa;
    empresa aux;
    pEmpresa=fopen("empresa.dat", "rb");
    if(pEmpresa==NULL){
        cout << "ERROR DE ARCHIVO"<<endl;
        system("PAUSE");
        return;
    }

    while(fread(&aux,sizeof aux, 1, pEmpresa)==1){
        cout << "Municipio: " << aux.getNumeroMunicipio() << endl;
        cout << "Empleados: " << aux.getCantidadEmpleados() << endl;
        cout << endl;

    }


}

void punto2(){
    FILE *pEmpresa;
    empresa aux;
    pEmpresa=fopen("empresa.dat", "rb");
    if(pEmpresa==NULL){
        cout << "ERROR DE ARCHIVO"<<endl;
        system("PAUSE");
        return;
    }

    while(fread(&aux,sizeof aux, 1, pEmpresa)==1){
        if(aux.getCantidadEmpleados()>200){
            cout << "Nombre de empresa: " << aux.getNombre()<<endl;
        }

    }

}

void punto3(){

FILE *pEmpresa;
    empresa aux;
    int vCatego[5] = {};
    int maximoEnVec;
    pEmpresa=fopen("empresa.dat", "rb");
    if(pEmpresa==NULL){
        cout << "ERROR DE ARCHIVO"<<endl;
        system("PAUSE");
        return;
    }

    while(fread(&aux,sizeof aux, 1, pEmpresa)==1){
        vCatego[aux.getCategoria()-1]+=aux.getCantidadEmpleados();
    }

    maximoEnVec = maximoVector(vCatego,5);

    cout << "Categoria de empresa con mas empleados: " << maximoEnVec+1 << endl;

}

int maximoVector(int *vec, int tam){
    int maxCatego=0;
    for (int x=1; x<tam; x++){
        if(vec[x]>vec[maxCatego]){
            maxCatego=x;
        }

    }

    return maxCatego;

}


///***Municipiooooss


int grabarMunicipio (municipios aux){
    FILE *pMunicipio;
    pMunicipio=fopen("municipios.dat", "ab");
    if(pMunicipio==NULL){
        cout << "ERROR DE ARCHIVO"<<endl;
        system("PAUSE");
        return -1;
    }


    int escribio=fwrite(&aux, sizeof aux, 1, pMunicipio);
    fclose(pMunicipio);
    return escribio;
}
void leerMunicipio(){
    FILE *pMunicipio;
    municipios aux;
    pMunicipio=fopen("municipios.dat", "rb");
    if(pMunicipio==NULL){
        cout << "ERROR DE ARCHIVO"<<endl;
        system("PAUSE");
        return;
    }


    while(fread(&aux,sizeof aux, 1, pMunicipio)==1){
        aux.MostrarMunicipios();
        cout << endl;

    }
}


