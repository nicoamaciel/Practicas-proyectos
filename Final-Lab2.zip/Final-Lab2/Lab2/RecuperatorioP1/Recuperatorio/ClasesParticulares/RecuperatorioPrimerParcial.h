#ifndef RECUPERATORIOPRIMERPARCIAL_H_INCLUDED
#define RECUPERATORIOPRIMERPARCIAL_H_INCLUDED

class RecuperatorioPrimerParcial{

private:

public:
    void cursosConMayorAyuda();
    void alumnosConPocaAyuda();
    void generarEstadisticasAyuda();
    void mostrarEstadisticas();
    void nuncaRecibioAyuda(int leg);


};


//MacielNicolas 01-12 legajo24290

#endif // RECUPERATORIOPRIMERPARCIAL_H_INCLUDED
