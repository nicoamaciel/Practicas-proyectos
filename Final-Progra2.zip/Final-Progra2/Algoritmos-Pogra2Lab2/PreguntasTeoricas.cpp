POO -->> molde donde se definen propiedades y el comportamiento de los objetos de la clase. 
Poo cuenta con especificadores de acceso. Private, solo va ser accesible desde la clase.
Public, accesible por fuera de clase 

Encapsulamiento: Mecanismo que asegura los datos contenidos en un objeto solo se pueden
acceder mediante metodos de la clase.

Constructores: Se ejecuta cuando el objeto nace. Se usa para darle valores iniciales a las
propiedades.

Destructores: Se ejecura cuando el objeto muere, se ultiliza tambien en conjunto delete[]nombredeclase para
liberar memoria.

this: Puntero oculto, contiene la direccion del objeto que lamma al metodo. Existe dentro de la clase.

Parametro por omision:
valor_devuelto nombre(tipo par1=3, tipo par2="hola",...)

Herencia: A partir de una clase es un mecanismo de una clase base, se construyen las clases derivadas.
Las clases derivadas(protec) heredadas se quedan con las propiedades y los metodos de la clase base.

Composicion: Tener como propiedad de una clase, objetos de otra clase. Por ejemplo fecha.

===================================================================================================================
COLAS:
Las colas son estructuras de datos en las que el primer elemento de información en
ingresar es el primero en salir, por lo que se las conoce como listas FIFO (por las siglas
en inglés First In – First Out).
Son muy utilizadas en informática, para almacenar datos que necesiten ser procesados
según el orden de llegada. Por ejemplo, en un sistema operativo los trabajos de
impresión se ordenan en una Cola, y son procesados de acuerdo a su ubicación en ella.
Existen diversas implementaciones de las colas, que responden a necesidades
específicas de procesamiento de información. Puede haber colas circulares, dobles, con
prioridad, etc.

Operaciones básicas sobre colas

Las operaciones básicas en una cola son las que permiten agregar y sacar elementos de
información.
Agregar: se agrega un elemento de información al final de la cola.
Sacar: se saca de la cola, para su procesamiento, el elemento de información más
“viejo”, es decir, el primero en ser ingresado. Independientemente de la implementación
que se haga mediante programación de la Cola, la operación Sacar es destructiva: el
elemento de información ya no será accesible. Para quien la utilice debe verse como que
no “existe”, que el elemento de información ya no forma parte de la estructura que lo
contenía.
Adicionalmente, puede necesitarse una operación que permita saber si la cola tiene
espacio para almacenar un nuevo elemento (en caso que tenga una longitud fija), o si
está vacía, esto es, no tiene ningún elemento de información almacenado.

Implementación de las colas

Una cola puede ser estática o dinámica, de acuerdo a si tiene una longitud fija (sólo
admite n elementos de información) o si permite un crecimiento indeterminado de la
cantidad de componentes. Una cola estática puede construirse a partir de un vector; una
dinámica en cambio suele implementarse mediante una lista enlazada.
En el siguiente ejemplo se implementa mediante una clase una cola sencilla de longitud
fija que sólo admite que se ingresen y se saquen una cantidad predefinida de números
enteros positivos. Con fines didácticos se agrega un método que muestra los
componentes

===================================================================================================================

PILAS:

La pila es una estructura con numerosas analogías en la vida real, una pila de platos,
una pila de documentos, una pila de monedas. A diferencia de la cola, su
comportamiento es tal que el primero que ingresa es el último que sale, o sea LIFO
(Last In – First Out). Tanto la operación de inserción (agregar) o eliminar (sacar) se
hacen sobre un mismo extremo, generalmente llamado tope.
Las consideraciones sobre las operaciones básicas sobre pilas, así como su
implementación son análogas a las hechas en relación a las colas. La diferencia con la
cola es que la operación sacar se hace sobre el elemento de información mas “nuevo”,
es decir, el último ingresado.
A continuación se presenta una implementación de una pila sencilla en un
