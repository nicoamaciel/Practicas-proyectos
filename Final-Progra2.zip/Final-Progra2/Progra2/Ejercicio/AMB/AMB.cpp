///Ejercicio:
///Autor:DEK
///Fecha:
///Comentario:

# include<iostream>
# include<cstdlib>
# include<cstring>

using namespace std;

void cargarCadena(char *pal, int tam){
  int i;
  fflush(stdin);
  for(i=0;i<tam;i++){
      pal[i]=cin.get();
	  if(pal[i]=='\n') break;
	  }
  pal[i]='\0';
  fflush(stdin);
}


class Empresa{
private:
    int numeroEmpresa;
    char nombreEmpresa[30];
    int cantidadEmpleados;
    int categoria;
    int municipio;
    bool estado;
public:
    int getNumeroEmpresa(){return numeroEmpresa;}
    const char *getNombreEmpresa(){return nombreEmpresa;}
    int getCantidadEmpleados(){return cantidadEmpleados;}
    int getCategoria(){return categoria;}
    int getMunicipio(){return municipio;}
    bool getEstado(){return estado;}
    void setNumeroEmpresa(int nE){numeroEmpresa=nE;}
    void setNombreEmpresa(const char *nE){strcpy(nombreEmpresa,nE);}
    void setCantidadEmpleados(int cE){cantidadEmpleados=cE;}
    void setCategoria(int c){categoria=c;}
    void setMunicipio(int m){municipio=m;}
    void setEstado(bool e){estado=e;}
    void Cargar(int nE=-1);
    void Mostrar();
    bool leerDeDisco(int pos);
    bool grabarEnDisco();
    bool modificarEnDisco(int pos);
};

bool Empresa::leerDeDisco(int pos){ //pos es la posición que ocupa el registro en el archivo, empezando por 0
    FILE *p;
    p=fopen("empresas.dat","rb");
    if(p==NULL) return false;
    fseek(p, pos * sizeof (Empresa), 0); ///sizeof (Empresa) es el tamaño en bytes de un objeto Empresa en memoria
    bool leyo = fread(this, sizeof (Empresa), 1, p);
    fclose(p);
    return leyo;
}

bool Empresa::grabarEnDisco(){
    FILE *p;
    p=fopen("empresas.dat","ab");
    if(p==NULL) return false;
    bool escribio = fwrite(this, sizeof (Empresa), 1, p);
    fclose(p);
    return escribio;
}

bool Empresa::modificarEnDisco(int pos){
    FILE *p;
    p=fopen("empresas.dat","rb+");
    if(p==NULL) return false;
    fseek(p, pos * sizeof(Empresa), 0);
    bool escribio=fwrite(this, sizeof (Empresa), 1, p);
    fclose(p);
    return escribio;
}

void Empresa::Cargar(int nE){
    if(nE==-1){
        cout<<"NUMERO DE EMPRESA: ";
        cin>>numeroEmpresa;
    }
    else{
        numeroEmpresa=nE;
    }
    cout<<"NOMBRE: ";
    cargarCadena(nombreEmpresa,29);
    cout<<"CANTIDAD DE EMPLEADOS: ";
    cin>>cantidadEmpleados;
    cout<<"CATEGORIA: ";
    cin>>categoria;
    cout<<"MUNICIPIO: ";
    cin>>municipio;
    estado=true;
    cout<<endl;

}

void Empresa::Mostrar(){
    if(estado==true){
        cout<<"NUMERO DE EMPRESA: ";
        cout<<numeroEmpresa<<endl;
        cout<<"NOMBRE: ";
        cout<<nombreEmpresa<<endl;
        cout<<"CANTIDAD DE EMPLEADOS: ";
        cout<<cantidadEmpleados<<endl;
        cout<<"CATEGORIA: ";
        cout<<categoria<<endl;
        cout<<"MUNICIPIO: ";
        cout<<municipio<<endl;
    }
}

void cargarVectorEmpresa(Empresa *vReg, int cant){
    int i;
    for(i=0;i<cant;i++){
        vReg[i].Cargar();
    }
}

bool cargarArchivo1(){
    Empresa reg;
    int escribio, i;
    FILE *p;
    p=fopen("empresas.dat", "wb");
    if(p==NULL){
        return false;
    }
    for(i=0;i<3;i++){
        reg.Cargar();
        escribio=fwrite(&reg, sizeof(Empresa),1,p);
        if(escribio==0){
            fclose(p);
            return false;
        }
    }
    fclose(p);
    return true;
}



bool cargarArchivo2(){
    Empresa reg;
    int escribio;
    FILE *p;
    p=fopen("empresas.dat", "ab");
    if(p==NULL){
        return false;
    }
    reg.Cargar();
    escribio=fwrite(&reg, sizeof(Empresa),1,p);
    fclose(p);
    return escribio;
}

bool mostrarArchivo(){
    Empresa reg;
    int i;
    FILE *p;
    p=fopen("empresas.dat", "rb");
    if(p==NULL){
        return false;
    }
    /*for(i=0;i<3;i++){
        fread(&reg, sizeof(Empresa),1,p);///devuelve si pudo leer la cantidad leída
        reg.Mostrar();
        cout<<endl;
    }*/
    while(fread(&reg, sizeof(Empresa),1,p)==1){
        reg.Mostrar();
        cout<<endl;
    }
    fclose(p);
    return true;
}

int buscarNumeroEmpresa(int nE){
    Empresa obj;
    int pos=0;
    while(obj.leerDeDisco(pos)){
        if(obj.getNumeroEmpresa()==nE){ /*Si devuelve -1 no existe*/
            return pos;
        }
        pos++;
    }
    return -1;
}

///PROTOTIPOS AMB

bool altaEmpresa();
bool bajaEmpresa();
bool modificarCategoria();



int main(){
    Empresa obj;

    int opc;
    while(true){
        system("cls");
        cout<<"------MENU PRINCIPAL------"<<endl;
        cout<<"1. ALTA EMPRESA"<<endl;
        cout<<"2. BAJA EMPRESA"<<endl;
        cout<<"3. MODIFICAR CATEGORIA EMPRESA"<<endl;
        cout<<"4. LISTAR EMPRESAS"<<endl;
        cout<<"0. SALIR"<<endl;
        cout<<"-------------------------"<<endl;
        cout<<"SELECCIONE UNA OPCION: "<<endl;
        cin>>opc;
        system("cls");
        switch(opc){
            case 1:
                if(altaEmpresa() == true){
                    cout << "Registro agregado correctamente" << endl;
                    system("pause");
                }else{
                    cout << "No se pudo agregar el registro" << endl;
                    system("pause");
                }
                system("cls");

                    break;
            case 2:
                   if (bajaEmpresa()== true){
                    cout << "Empresa dada de baja" << endl;
                   }else{
                        cout << "No se pudo generar la baja" << endl;
                   }

                    break;
            case 3:
                    if(modificarCategoria() == true){
                        cout << "Categoria modificada" << endl;
                    }
                    else{
                        cout << "Error en modificacion" << endl;
                    }
                    break;
            case 4:
                    int pos;

                    while (obj.leerDeDisco(pos)==1){
                        obj.Mostrar();
                        pos++;
                        cout << endl;
                    }

                    break;

            case 0: return 0;
                    break;
        }
        system("pause");
        system("cls");
    }
	cout<<endl;
	system("pause");
	return 0;
}




bool altaEmpresa(){
    Empresa obj;
    int nE, pos;
    cout << "Numero de empresa alta: ";
    cin >> nE;
    pos=buscarNumeroEmpresa(nE);
    if(pos>=0){
        cout<<"LA EMPRESA INGRESADA YA EXISTE"<<endl;
        return false;
        system("pause");
    }
    obj.Cargar(nE);
    return obj.grabarEnDisco();
    system("cls");
}

bool bajaEmpresa(){
Empresa obj;
int nE, pos;
cout << "Numero de empresa baja: ";
cin >> nE;
pos=buscarNumeroEmpresa(nE);
    if(pos==-1){
    cout << "El numero ingresado no existe en el archivo"<< endl;
    system("pause");
    return false;
    }
    obj.leerDeDisco(pos);
    if(obj.getEstado()==false){
    cout << "Empresa ya fue dada de baja"<< endl;
    system("pause");
    return false;

    }

    obj.leerDeDisco(pos);
    obj.setEstado(false);
    obj.modificarEnDisco(pos);

}

bool modificarCategoria(){
Empresa obj;
int nE,catego, pos;
cout << "Numero de empresa modificar categoria: ";
cin >> nE;
cout << "Categoria: ";
cin >> catego;
pos=buscarNumeroEmpresa(nE);
    if(pos==-1){
    cout << "El numero ingresado no existe en el archivo"<< endl;
    system("pause");
    return false;
    }
    obj.leerDeDisco(pos);
    obj.setCategoria(catego);
    obj.modificarEnDisco(pos);




}

