#ifndef CLASES_H_INCLUDED
#define CLASES_H_INCLUDED



class articulos{
private:
    int _codigo;// (1-10)
    string _nombre;
    float _precio;
    int _stock;

public:
    articulos(int codigo=0, string nombre="vacio", float precio=0, int stock=0);
    //Gets
    int getCodigo();
    string getNombre();
    float getPrecio();
    int getStock();

    //Sets

    void setCodigo(int);
    void setNombre(string);
    void setPrecio(float);
    void setStock(int);

    //Comportamiento

    void cargarArticulo();
    void mostarArticulos();
    void restarStock(int);


};








#endif // CLASES_H_INCLUDED
