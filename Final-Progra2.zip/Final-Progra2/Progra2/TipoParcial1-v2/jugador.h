#ifndef JUGADOR_H_INCLUDED
#define JUGADOR_H_INCLUDED

#include <iostream>
#include <cstring>
#include <cstdlib>
using namespace std;

class jugador{
private:
char CodigoJugador[5];
char Nombre[30];
int Edad;
char CodigoEquipo[3];

public:
//gets
const char *getCodigoJugador(){return CodigoJugador;}
const char *getNombre(){return Nombre;}
int getEdad(){return Edad;}
const char *getCodigoEquipo(){return CodigoEquipo;}

//sets

void setCodigoJugador(const char *codJug){strcpy(CodigoJugador,codJug);}
void setNombre(const char *nom){strcpy(Nombre,nom);}
void setEdad(int ed){Edad=ed;}
void setCodigoEquipo(const char *codEq){strcpy(CodigoEquipo,codEq);}

//Comporatamiento
void cargar();
void mostrar();
bool grabarEnDisco();
bool leerDeDisco(int pos);


};

void jugador::cargar(){
char codj[5];
char nom[30];
char codE[3];
int ed;

cout << "Cargar codigo jugador: ";
cin >> codj;
cout << "Cargar nombre jugador: ";
cin >> nom;
cout << "Cargar edad del jugador: ";
cin >>ed;
cout << "Cargar codigo de equipo: ";
cin >>codE;


setCodigoJugador(codj);
setNombre(nom);
setEdad(ed);
setCodigoEquipo(codE);
}
void jugador::mostrar(){
cout << "Codigo jugador: " << getCodigoJugador() << endl;
cout << "Nombre jugador: " << getNombre() << endl;
cout << "Edad del jugador: " << getEdad() << endl;
cout << "Codigo de equipo: " << getCodigoEquipo() << endl;
cout << "- - - - - - - - - - - - - - " << endl;


}

bool jugador::grabarEnDisco(){
FILE *pJugador = fopen("jugador.dat","ab");
if(pJugador==nullptr){return false;}

bool escribio = fwrite(this,sizeof(jugador),1,pJugador);
fclose(pJugador);
return escribio;
}


bool jugador::leerDeDisco(int pos){
FILE *pJugador = fopen("jugador.dat","rb");
if(pJugador==nullptr){return false;}

fseek(pJugador,pos*sizeof(jugador),SEEK_SET);
bool leyo = fread(this,sizeof(jugador),1,pJugador);
fclose(pJugador);
return leyo;
}




#endif // JUGADOR_H_INCLUDED
