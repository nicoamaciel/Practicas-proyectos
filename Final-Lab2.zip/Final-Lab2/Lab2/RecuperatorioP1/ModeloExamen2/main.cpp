#include <iostream>
#include "ResumenDiarioArchivo.h"
using namespace std;

#include "macielNicolas.h"
int main()
{
  modelo obj;

//  obj.punto1();
//  cout<<endl;
//  obj.punto2();
//  cout<<endl;
//obj.punto3();
//  cout<<endl;
obj.punto4();



  return 0;
}
