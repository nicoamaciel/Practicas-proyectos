

Local en public de clase restaurante:

bool leerDeDisco(int pos){
            FILE *p;
            p=fopen("restaurantes.dat","rb");
            if(p==NULL) return false;
            fseek(p,pos*sizeof *this, 0);
            bool leyo=fread(this, sizeof *this, 1, p);
            fclose(p);
            return leyo;
        }