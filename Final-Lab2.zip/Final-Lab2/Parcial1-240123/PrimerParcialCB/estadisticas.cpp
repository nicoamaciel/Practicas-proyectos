#include <iostream>
#include <cstdlib>
using namespace std;

#include "estadisticas.h"

estadisticas::estadisticas(){
_anio=0;
_recaudacion=0;

}

estadisticas::estadisticas(int anio, float recaudacion){

_anio=anio;
_recaudacion=recaudacion;

}


int estadisticas::getAnio(){
return _anio;
}

float estadisticas::getRecaudacion(){
return _recaudacion;
}

void estadisticas::setAnio(int anio){
    _anio=anio;
}

void estadisticas::setRecaudacion(float recaudacion){
    _recaudacion=recaudacion;
}

void estadisticas::add(float recaudacion){
    _recaudacion += recaudacion;

}


void estadisticas::mostrarEstadistica(){

cout << " Anio " << getAnio() << " Recaudacion: " << getRecaudacion() << endl;
}
