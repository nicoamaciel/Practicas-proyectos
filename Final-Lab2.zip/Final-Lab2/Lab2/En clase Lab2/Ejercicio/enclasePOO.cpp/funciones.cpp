#include <iostream>
using namespace std;

#include "funciones.h"

//Constructor
bidones::bidones(float capacidad, string nom){
    _litros=capacidad;
   _nombre=nom;

}


float bidones::getLitros(){
    return _litros;
}

string bidones::getNombres(){
    return _nombre;
}

void bidones::extraerLitros(float cantidad){

 _litros-=cantidad;

}
