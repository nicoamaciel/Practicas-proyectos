

/*
Cerca de la facultad hay un puesto de batidos llamado �**MaxiBatidos**�
que es atendido por una persona de pelo largo y lacio�

En ella vende 3 tipo de batidos, para ello tienen 1 bid�n de 20L con sabor �Banana�, 1 bid�n de 35L con sabor a �Anan� y
otra bid�n de 44L con sabor a �Sandia�

Siempre al comenzar el d�a llenan los 3 bidones para comenzar a vender.

Nos piden hacer un programa para procesar las ventas del d�a, cada venta esta compuesta por:

- C�digo de Batido (1- Banana, 2- Anan� y 3 - Sandia)
- Tipo de Vaso (1-  150 ml, 2- 200ml, 3- 300ml)

La carga de ventas finaliza con un C�digo de Batido igual a cero.

Informar:

Para cada tipo de batido, cuanto fue lo que le quedo al finalizar el d�a.


*/

#include <iostream>
using namespace std;

int main(){


int banana=2000, anana=3500, sandia=4400;

int tipo1=150, tipo2=200, tipo3=300;

int codigoBatido;
int tipoVaso;


cout << "Codigo de batido (1- Banana, 2- Anana y 3 - Sandia): ";
cin >> codigoBatido;

while(codigoBatido!=0){
cout << "Tipo de vaso (1-  150 ml, 2- 200ml, 3- 300ml): ";
cin >> tipoVaso;
cout << "---------------------------------------" << endl;

switch(codigoBatido){
case 1:
    if(tipoVaso==1){
        banana=banana - tipo1;
    }
    if(tipoVaso==2){
        banana=banana - tipo2;
    }
    if(tipoVaso==3){
        banana=banana - tipo3;
    }

    break;
case 2:
    if(tipoVaso==1){
        anana=anana - tipo1;
    }
    if(tipoVaso==2){
        anana=anana - tipo2;
    }
    if(tipoVaso==3){
        anana=anana- tipo3;
    }

    break;
case 3:
    if(tipoVaso==1){
        sandia=sandia - tipo1;
    }
    if(tipoVaso==2){
        sandia=sandia - tipo2;
    }
    if(tipoVaso==3){
        sandia=sandia - tipo3;
    }
    break;

}




cout << "Codigo de batido (1- Banana, 2- Anana y 3 - Sandia): ";
cin >> codigoBatido;
}



cout << "Lts finales: " << endl;
cout << "Banana: " << banana << endl;
cout << "Anana: " << anana << endl;
cout << "Sandia: " << sandia << endl;


cout << "----------------------" << endl;








return 0;
}
