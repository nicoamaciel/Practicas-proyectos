class FiguraGeometrica{
private:
    float ladomayor, ladomenor;

public:
    
    //Gets
    float getLadomayor(){return ladomayor;}
	float getLadomenor(){return ladomenor;}


    //Sets
    void setLadomayor(float mayor){ladomayor=mayor;}
	void setLadomenor(float menor){ladomenor=menor;}    
	
	
	void Cargar();
    void Mostrar();
	bool grabarEnDisco();
	bool leerDeDisco(pos);

    
}; ///FIN DE LA FIGURA GEOMETRICA

   

    class Rectangulo{
    protected: //Clase base permite acceder por parte de clases derivadas
       
        FiguraGeometrica datos;
    public:
        //GETS
        FiguraGeometrica getdatos(){return datos;}


        //SETS
       void setDatos (FiguraGeometrica dat){
            datos=dat;
        }

    }; //FinDeClaseRectangulo