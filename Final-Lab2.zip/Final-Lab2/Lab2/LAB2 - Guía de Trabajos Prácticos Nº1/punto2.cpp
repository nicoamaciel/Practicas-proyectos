
/*
2
Hacer una funci�n que reciba como par�metros un vector de enteros y un n�mero entero
que indica la cantidad de componentes del vector, y que devuelva el �ndice en
donde se encuentra el valor m�ximo del vector.

*/
#include <iostream>
using namespace std;

///Declaracion de funcion

void componentesVectorMaximo( int *vPrueba, int CONTENIDO);

int main(){

int const CONTENIDO=10;

int vPrueba[CONTENIDO]={10,3,7,9,10,2,31,25,1,9};
componentesVectorMaximo(vPrueba, CONTENIDO);

return 0;
}


///Definicion de funcion
void componentesVectorMaximo(int *vPrueba, int CONTENIDO){
    int maximo=0;
    int maxPosicion=0;
    cout << "Contenido del vector: " << CONTENIDO << endl;

    for (int x=0; x<10; x++){

        if(vPrueba[x]>maximo){
            maximo=vPrueba[x];
            maxPosicion=x;
        }
    }

    cout << "Posicion de maximo valor del vector: " << maxPosicion << endl;

}
