#include <iostream>
using namespace std;
#include "RecuperatorioPrimerParcial.h"


int main() {
    RecuperatorioPrimerParcial obj;

    obj.cursosConMayorAyuda();
    cout << endl;
    obj.alumnosConPocaAyuda();
    cout << endl;
    obj.generarEstadisticasAyuda();
    obj.mostrarEstadisticas();
    cout << endl;
    obj.nuncaRecibioAyuda(1000);

  return 0;
}
