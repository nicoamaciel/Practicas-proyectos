#ifndef INGRESO_H_INCLUDED
#define INGRESO_H_INCLUDED

class ingreso{

private:
    int _Dni;
    int _HoraIngreso;

public:
    //Gets
    int getDni();
    int getHoraIngreso();
    //Sets
    void setDni(int);
    void setHoraIngreso(int);

    //Comportamiento

    void cargarIngreso();
};

#endif // INGRESO_H_INCLUDED
