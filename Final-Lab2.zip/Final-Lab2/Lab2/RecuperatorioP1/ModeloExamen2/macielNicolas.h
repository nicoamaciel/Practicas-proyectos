#ifndef MACIELNICOLAS_H_INCLUDED
#define MACIELNICOLAS_H_INCLUDED
class modelo{
    private:

    public:
    void punto1();
    void punto2();
    void punto3();
    void punto4();
    void punto5();
    void punto6();




};

void buscarCombus(int id);
void buscarMeses(int *vecMesesConNafta, int tam);
void grabarEnDisco();


#endif // MACIELNICOLAS_H_INCLUDED
