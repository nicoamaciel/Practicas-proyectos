
#include <iostream>
#include <cstring>
#include <cstdlib>
using namespace std;

#include "clases_p.h"


/*
1-Generar un archivo con la cantidad de reservas que cada restaurante de la categor�a 2 tuvo el a�o pasado.
Cada registro debe tener el siguiente formato:

-   C�digo de restaurante,
-   nombre de restaurante,
-   cantidad de reservas del a�o pasado.

2- Informar el mes de este a�o con m�s cantidad de reservas.

*/



//Punto1

class Punto1{

private:
    int _codResto;
    char _nomRestaurante[20];
    int _cantReservas21;

public:
    int getCodResto(){return _codResto;}
    const char *getNomRestaurante(){return _nomRestaurante;}
    int getCanReservas21(){return _cantReservas21;}

    void setCodResto(int cod){_codResto=cod;}
    void setNomRestaurante(const char *nom){strcpy(_nomRestaurante,nom);}
    void setCanReservas21(int cant21){_cantReservas21=cant21;}


    void grabarEnDisco();
    void leerDeDisco();
    void mostar();

};

void punto1();
    bool buscarAnio(int);
    int buscarReservas(int);

void punto2();
    void mostrarMayorCant(int *vMeses, int cant);



int main (){
Punto1 reg;
Reserva obj;
Restaurante obj2;
int pos=0, pos2=0;
//punto1();
reg.leerDeDisco();
cout << "- - - - - - - - " << endl;

punto2();
//while(obj.leerDeDisco(pos)){
//    obj.Mostrar();
//    pos++;
//    cout << endl;
//}
////cout << "- - - - - - - - " << endl;
//while(obj2.leerDeDisco(pos2)){
//    obj2.Mostrar();
//    pos2++;
//    cout << endl;
//}


return 0;
}






void Punto1::mostar(){

cout << "Codigo resto: " << getCodResto() << endl;
cout << "Nombre resto: " << getNomRestaurante() << endl;
cout << "Cantidad reservas 21: " <<getCanReservas21()<< endl;

}



void Punto1::grabarEnDisco(){
FILE *pPunto1;
pPunto1 = fopen("punto1.dat","ab");
if(pPunto1==NULL){
    cout << "Error en archivo";
    //return -1;
    }

   int escribio = fwrite(this, sizeof(Punto1), 1, pPunto1);
   fclose(pPunto1);
   //return escribio;


}


void Punto1::leerDeDisco(){
Punto1 reg;
FILE *pPunto1 = fopen("punto1.dat","rb");
if(pPunto1==nullptr){"Error de lectura";}

while(fread(&reg,sizeof(Reserva),1,pPunto1)==1){
reg.mostar();
}
fclose(pPunto1);

}


void punto1(){
Restaurante reg;
Punto1 obj;
int pos=0;

while(reg.leerDeDisco(pos)){
    if(reg.getCategoriaRestaurante()==2 && buscarAnio(reg.getCodigoRestaurante())==true){
        obj.setCodResto(reg.getCodigoRestaurante());
        obj.setNomRestaurante(reg.getNombre());
        obj.setCanReservas21(buscarReservas(reg.getCodigoRestaurante()));

        obj.grabarEnDisco();
    }

    pos++;
}

}



bool buscarAnio(int codResto){
Reserva reg;
int pos=0;

while(reg.leerDeDisco(pos)){
    if(codResto==reg.getCodigoRestaurante() && reg.getFechaReserva().getAnio()==2021){
        return true;
    }
    pos++;
}


}


int buscarReservas(int codResto){
Reserva reg;
int cant=0, pos=0;


while(reg.leerDeDisco(pos)){
    if(codResto==reg.getCodigoRestaurante() && reg.getFechaReserva().getAnio()==2021){
        cant++;
    }
    pos++;
}


return cant;

}



void punto2(){
Reserva reg;
int vMeses[12]{};
int pos=0;

while(reg.leerDeDisco(pos)){
    if(reg.getFechaReserva().getAnio()==2022){
        vMeses[reg.getFechaReserva().getMes()-1]++;
    }

    pos++;
}

mostrarMayorCant(vMeses,12);

}


void mostrarMayorCant(int *vMeses,int cant){

int maxCant=0;
int maxMes=0;

for(int i=0; i<cant; i++){

    if(vMeses[i]>maxCant){
        maxCant=vMeses[i];
        maxMes=i+1;
    }


}

cout << endl << "Mes con mayor cantidad de reservas: " << maxMes << endl;

}
