/*

El Club Deportivo Lara dispone de la informaci�n de todos los pagos de cuotas abonados por sus 50 socios/as durante el a�o pasado.
Cada pago se registra indicando el n�mero de socio (100 y 149) y el n�mero de cuota (1 a 6).
El fin de la carga de datos se indica con un n�mero de socio fuera de rango.

A) Se pide realizar un listado con el siguiente formato:
Ver cuadro

B) Elaborar un listado con los n�meros de socios que no hayan pagado ninguna cuota.
C) Por cada cuota, listar el porcentaje de cumplimiento de pago de los 50 socios.
Por ejemplo, si la cuota 1 fue pagada por todos los socios su porcentaje de cumplimiento ser� del 100%.


*/

#include <iostream>
using namespace std;

int main (){

int numeroSocio;
int numeroCuota;

//PuntoA

int const FILA=150;
int const COLUMNA=6;

int mPAGOS[FILA][COLUMNA]={};

cout << "Numero de socio (100 y 149): ";
cin >> numeroSocio;
while(numeroSocio<150 && numeroSocio>=100){
cout << "Numero de cuota abonada entre 1-6:";
cin >> numeroCuota;
cout << "------------------------" <<endl;

//PuntoA
for(int x=0; x<FILA; x++){
    for(int y=0; y<COLUMNA; y++){
        if(numeroSocio==x+1 && numeroCuota==y+1){
            mPAGOS[x][y]=1;
        }
    }
}











cout << "Numero de socio (100 y 149): ";
cin >> numeroSocio;
}


cout << "------------------------" <<endl;
cout << "Punto A: " << endl;
for(int x=0; x<FILA; x++){
        if(x>99){
            cout << x+1 << " | ";
            for(int y=0; y<COLUMNA; y++){
                cout << mPAGOS[x][y] << "  ";

            }

            cout << endl;

        }

}



return 0;
}
