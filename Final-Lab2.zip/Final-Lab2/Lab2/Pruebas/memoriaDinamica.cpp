#include <iostream>
using namespace std;



void restoMasPular();


int main (){

restoMasPular();
cout << endl;
system("pause");
return 0;
}

void restoMasPular(){
int cantReg;
cantReg=contarRegistrosRestos();
int *vResto = new int[cantReg];
if(vResto = nullptr){cout << "ERROR DE ASIGNACION DE MEMORIA" << endl;}
return;
}
delete []vResto;
