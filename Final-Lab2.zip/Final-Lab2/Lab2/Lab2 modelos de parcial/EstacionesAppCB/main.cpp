/*
1- El nombre del tipo de combustible que haya registrado el precio por litro m�s caro.
Si existe m�s de un tipo de combustible que cumpla esta condici�n, mostrar el primero que encuentren en el archivo.

2- A partir de un IDEstaci�n que se ingresa como par�metro, mostrar los meses en los que no se haya vendido
Nafta S�per en esa estaci�n.

3- El nombre del tipo de combustible que haya registrado el precio por litro promedio m�s caro.
Mostrar todos los tipos de combustibles que cumplan esta condici�n.

4- Hacer un archivo llamado Anuario.dat que a partir de un a�o que se ingrese por
teclado genere un resumen mensual con el total de litros de combustibles vendidos
en ese a�o y mes (en total se deben generar 12 registros).

Aclaraciones:
El archivo Anuario.dat debe contener solamente el resumen del �ltimo a�o que se ingres�.
Si el a�o ingresado no tiene litros acumulados para ninguno de los 12 meses, entonces no debe generar el anuario y mostrar un mensaje aclaratorio al usuario.

5- Mostrar el archivo Anuario.dat con el siguiente formato:
A�o: XXXX

Mes		Total litros
Enero		9999
Febrero	    9999
Marzo		9999
. . .
Diciembre	9999

*/

#include <iostream>
#include "ResumenDiarioArchivo.h"
using namespace std;

#include "parcial.h"

int main()
{
    parcial reg;

    reg.punto3();




  return 0;
}
