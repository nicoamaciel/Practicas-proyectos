#ifndef PARCIAL_H_INCLUDED
#define PARCIAL_H_INCLUDED


class parcial{

private:
public:
    void punto1();
        void mostrarNombre(int id);
    void punto2();
    void punto3();
    void punto4();
    void punto5();




};



#endif // PARCIAL_H_INCLUDED
