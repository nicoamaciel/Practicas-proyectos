#include <iostream>

using namespace std;

#include "clases.h"

articulos::articulos(int codigo, string nombre, float precio, int stock){
    _codigo=codigo;
    _nombre=nombre;
    _precio=precio;
    _stock=stock;
}

//Gets
int articulos::getCodigo(){
return _codigo;

}
string articulos::getNombre(){
return _nombre;
}
float articulos::getPrecio(){
return _precio;
}
int articulos::getStock(){
return _stock;
}

//Sets

void articulos::setCodigo(int codigo){
    _codigo=codigo;
}
void articulos::setNombre(string nombre){
    _nombre=nombre;
}
void articulos::setPrecio(float precio){
    if(precio>0){
        _precio=precio;
    }


}
void articulos::setStock(int stock){
   if(stock>0){
    _stock=stock;
   }



}

//Comportamiento

void articulos::cargarArticulo(){
    int cod;
    string nom;
    float pre;
    int stock;

    cout << "Codigo articulo: ";
    cin >> cod;
    cout << "Nombre articulo: ";
    cin >> nom;
    cout << "Precio articulo: ";
    cin >> pre;
    cout << "Stock: ";
    cin >> stock;
    cout << "-------------------" << endl;
    setCodigo(cod);
    setNombre(nom);
    setPrecio(pre);
    setStock(stock);
}

void articulos::mostarArticulos(){

    cout << "Codigo articulo: " << getCodigo()<< endl;
    cout << "Nombre articulo: " << getNombre()<< endl;
    cout << "Precio articulo: " << getPrecio()<< endl;
    cout << "Stock: " << getStock() << endl;
    cout << "-------------------" << endl;

}


void articulos::restarStock(int vendida){

    _stock-=vendida;

}
