
//4
//Hacer un programa que permita cargar un vector de 10
//n�meros enteros en el cual ninguno de los valores de sus elementos pueda repetirse.

#include <iostream>
using namespace std;

//Declaracion de la funcion

void vectorSinRepeticiones(int *vLlenar,int TAMANIO);
void recorrerVector (int *vLlenar,int TAMANIO);

int validar (int *vLlenar, int TAMANIO, int valor);

int main(){

int const TAMANIO=10;
int vLlenar[TAMANIO]={};



vectorSinRepeticiones(vLlenar,TAMANIO);
cout << endl;
recorrerVector(vLlenar,TAMANIO);



return 0;
}


//Definicion de la funcion

void vectorSinRepeticiones(int *vLlenar, int TAMANIO){
    int valor, validacion=0;

        for (int x=0; x<TAMANIO; x++){

            cout << "Ingrese valor del vector: ";
            cin >> valor;

            validacion=validar(vLlenar,TAMANIO,valor);

            if(validacion==1)
            {
                cout << "Valor repetido" << endl;
            }
            else{
                vLlenar[x]=valor;
            }

        }


    }

int validar(int *vLlenar, int TAMANIO, int valor){
int retorno=-1;
    for (int i=0; i<TAMANIO; i++){
        if(vLlenar[i]==valor){
         retorno=1;
        }

    }

    return retorno;
}



void recorrerVector (int *vLlenar,int TAMANIO){

    for (int x=0; x<TAMANIO; x++){
        if(vLlenar[x]>0){
           cout << vLlenar[x];
        }

    }

}



