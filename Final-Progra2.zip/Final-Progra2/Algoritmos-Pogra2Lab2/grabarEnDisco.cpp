===================================================================================================================================
============================================== grabar en disco - local a equipo ===================================================
===================================================================================================================================
En .h--->> equipos.h -->> Local en clase

int grabarenDisco();

===================================================================================================================================
En .cpp--->> equipos.cpp -->> Local en clase


#include <iostream>
#include <cstdlib>
#include <cstring>
#include <fstream>

using namespace std;
#include "equipos.h"

int equipos::grabarenDisco(){
   FILE *pEquipos;
   pEquipos = fopen("equipos.dat","ab");
   if(pEquipos==NULL){
       cout << "Error en archivo";
        return -1;
        }

   int escribio = fwrite(this, sizeof(equipos), 1, pEquipos);
   fclose(pEquipos);
   return escribio;
   }
===================================================================================================================================
======================================================Grabar en disco con memoria dinamica ========================================
===================================================================================================================================

funcion que invoca grabar en disco y cantidad para ingresar datos.

local en clase especial funcion
public:
    void ingresarEquipos();

===================================================================================================================================


void funcion::ingresarEquipos(){

int cant, archivoEquipo=0;

cout << "Ingresar cantidad de equipos a cargar: ";
cin >> cant;

equipos *objEqui= new equipos[cant];


    for(int i=0; i<cant; i++){
    objEqui[i].cargarEquipos();
        archivoEquipo = objEqui[i].grabarenDisco();
        if(archivoEquipo == 1){
        cout << "Archivo cargado" << endl;


        }
    }

delete []objEqui;

}

