/*
1)  Un m�todo llamado  listarRecaudacion que muestre para cada
curso, la recaudaci�n obtenida desde el 10/05/2020.
(2 Puntos)

2) Agregar a la clase Pago un m�todo llamado esPagoVencido
que determine si el pago fue un pago vencido o no.
(1 Punto)

3) Agregar un m�todo llamado  listarAlumnosNoMorosos y que
usando el m�todo del punto anterior, muestre los legajos de los
alumnos que nunca realizaron un pago vencido.
(2 Puntos)

4)  Un m�todo llamado  soloUnCurso que muestre el legajo, nombre y
apellido de todos los alumnos que pagaron solamente un curso del
periodo (a�o per�odo de cursada)  2021 .
(2 Puntos)

5)  Crear un m�todo generarEstadistica que genere un archivo
llamado estadisticas.dat que guarde el a�o y la recaudaci�n de
cada a�o del archivo de pagos
Crear un m�todo llamado mostrarEstadisticas que muestre el
archivo generado en el punto anterior.
(2 Puntos)

6)  Crear un m�todo llamado  cursosPremium que reciba el legajo de
un estudiante y muestre el id del curso al que realiz� el mayor pago
individual (en caso de haber m�s de uno, muestre todos los que
cumplan esa condici�n).
(1 Punto


*/


#include <iostream>
#include <cstdio>
using namespace std;

#include "PrimerParcial.h"
#include "Pago.h"
#include "PagosArchivo.h"
#include "Estudiante.h"
#include "EstudiantesArchivo.h"
#include "estadisticas.h"


void PrimerParcial::listarRecaudacion(){


PagosArchivo obj;
int cantPagos = obj.getCantidad();

Pago *vPag = new Pago[cantPagos];

for(int i=0; i<cantPagos; i++){
    vPag[i] = obj.leer(i);
}

float vecCursos[10]{};

for(int i=0; i<cantPagos; i++){
    if((vPag[i].getFecha().getAnio()>2020)
       || (vPag[i].getFecha().getAnio()==2020 && vPag[i].getFecha().getMes()>5)
       || (vPag[i].getFecha().getAnio()==2020 && vPag[i].getFecha().getMes()==5 && vPag[i].getFecha().getDia()>10))
    {
    vecCursos[vPag[i].getIdCurso()-1]+=vPag[i].getMonto();
    }
}

for(int i=0; i<10; i++){
   cout << "Cursos: " << i+1 << " : " << vecCursos[i]<<endl;
}

delete []vPag;

}


void PrimerParcial::listarAlumnosNoMorosos(){

PagosArchivo obj;
int cantPagos = obj.getCantidad();

Pago *vPag = new Pago[cantPagos];

for(int i=0; i<cantPagos; i++){
    vPag[i] = obj.leer(i);
}

EstudiantesArchivo reg;
int cantEstu = reg.getCantidad();

Estudiante *vEstu = new Estudiante[cantEstu];

for(int i=0; i<cantEstu; i++){
    vEstu[i] = reg.leer(i);
}


for(int i=0; i<cantEstu; i++){
    Estudiante e = vEstu[i];
    bool sinPagos = true;
    bool pago = false;

    for(int j=0; j<cantPagos; j++){
        if(vPag[j].getLegajo() == e.getLegajo()){
            pago = true;
            if(vPag[j].esPagoVencido()){
                sinPagos = false;
            }
        }
    }

    if(sinPagos && pago){
        cout << e.getLegajo() << endl;
    }
}



//Meter deletes
delete []vPag;
delete []vEstu;


}


void PrimerParcial::soloUnCurso(){
PagosArchivo obj;
int cantPagos = obj.getCantidad();

Pago *vPag = new Pago[cantPagos];

for(int i=0; i<cantPagos; i++){
    vPag[i] = obj.leer(i);
}

EstudiantesArchivo reg;
int cantEstu = reg.getCantidad();

Estudiante *vEstu = new Estudiante[cantEstu];

for(int i=0; i<cantEstu; i++){
    vEstu[i] = reg.leer(i);
}

for(int i=0; i<cantEstu; i++){
    Estudiante e= vEstu[i];
    int vCurso[10]{};

    for(int j=0; j<cantPagos; j++){
        if(e.getLegajo()==vPag[j].getLegajo() && vPag[j].getAnio()==2021)
        {
            vCurso[vPag[j].getIdCurso()-1]=1;
        }
    }

    int cantidad =0;
    for(int x=0; x<10; x++){
        cantidad += vCurso[x];
    }

    if(cantidad == 1){
        cout << e.getLegajo() << " " << e.getNombres() << " " << e.getApellidos() << endl;
    }

}




//Meter deletes
delete []vPag;
delete []vEstu;

}


void PrimerParcial::generarEstadistica(){

PagosArchivo obj;
int cantPagos = obj.getCantidad();

Pago *vPag = new Pago[cantPagos];

for(int i=0; i<cantPagos; i++){
    vPag[i] = obj.leer(i);
    }
int anioMax=0; int anioMin=0;

for(int x=0; x<cantPagos; x++){
    if(x==0){
        anioMax = anioMin = vPag[x].getFecha().getAnio();
    }

    if(vPag[x].getFecha().getAnio()>anioMax){
        anioMax = vPag[x].getFecha().getAnio();
    }

    if(vPag[x].getFecha().getAnio()<anioMin){
        anioMin = vPag[x].getFecha().getAnio();
    }

}

estadisticas *anios = new estadisticas[anioMax - anioMin+1];

for(int x=0; x<anioMax-anioMin; x++){
    anios[x].setAnio(x+anioMin);
    anios[x].setRecaudacion(0);
}

for(int x=0; x<cantPagos; x++){
    anios[vPag[x].getFecha().getAnio()-anioMin].add(vPag[x].getMonto());
    }


    FILE* pFile;
    pFile = fopen("estadisticas.dat","wb");
    fwrite(anios, sizeof (estadisticas), anioMax-anioMin+1, pFile);
    fclose(pFile);

}

void PrimerParcial::mostrarEstadisticas(){
FILE* pFile;
pFile = fopen("estadisticas.dat","rb");
estadisticas est;
while(fread(&est,sizeof (estadisticas), 1, pFile)==1){
    est.verEstadisticas();
    }

}


void PrimerParcial::cursosPremium(int leg){

PagosArchivo obj;
int cantPagos = obj.getCantidad();

Pago *vPag = new Pago[cantPagos];

for(int i=0; i<cantPagos; i++){
    vPag[i] = obj.leer(i);
}

float maximo=0;
for(int i=0; i<cantPagos; i++){
    if(leg==vPag[i].getLegajo() && vPag[i].getMonto()>maximo){
    maximo=vPag[i].getMonto();
    }
}

int cursos[10]{};

for(int i=0; i<cantPagos; i++){
    if(leg==vPag[i].getLegajo() && vPag[i].getMonto()==maximo){
        if(cursos[vPag[i].getIdCurso()-1]==0){
            cout << vPag[i].getIdCurso() <<endl;
            cursos[vPag[i].getIdCurso()-1] = 1;
        }

    }
}




}
