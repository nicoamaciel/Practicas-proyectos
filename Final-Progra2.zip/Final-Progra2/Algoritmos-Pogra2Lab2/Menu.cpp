

===================================================================================================================================
===========================================================Menu infinito===========================================================
===================================================================================================================================

#include <iostream>
using namespace std;
#include "Pais.h"
#include "Ciudad.h"

while(true){
        system("cls");
        cout << " ------menu------" << endl;
        cout << "Punto 1 - " << endl;
        cout << "Punto 2 - " << endl;
        cout << "Punto 3 - " << endl;
        cout << "Punto 4 - " << endl;
        cout << "Punto 5 - " << endl;
        cout << "------------------" << endl;
        cout << "opcion: " << endl;
        cin >> opc;
        system("cls");
        switch(opc){
        case 1:
            {
            
            }
            break;
        case 2:
           {
      

           }

            break;
        case 3:


            break;
        case 4:

            break;
        case 5:

            break;


        case 0: return 0;
        break;
        }
        system("pause");
    }