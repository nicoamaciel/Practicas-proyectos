#include <cstring>
#include <iostream>
using namespace std;

#include "reportes.h"

    int Reportes::getCurso(){
        return _curso;
    }
    float Reportes::getAprobados(){
        return _aprobados;
    }
    float Reportes::getDesaprobados(){
        return _desaprobados;
    }
    void Reportes::setCurso(int cur){
        _curso=cur;
    }
    void Reportes::setAprobados(float apr){
        _aprobados=apr;
    }
    void Reportes::setDesaprobados(float des){
        _desaprobados=des;
    }
    void Reportes::verReportes(){
        cout << " Curso " << getCurso() << endl;
        cout << " Porcentaje arpobado: " << getAprobados() << endl;
        cout << " Porcentaje desaprobado: " << getDesaprobados() << endl;
    }
