
===================================================================================================================================
===================================================================================================================================
En .h --->> Pais.h 
funcion global

int cantidadPais();

===================================================================================================================================
===================================================================================================================================

En .cpp -->>> Pais.cpp

#include "Pais.h"
#include <cstring>
#include <cstdio>
#include <iostream>
using namespace std;

int cantidadPais(){
int cant=0;
FILE *pPais = fopen("paises.dat","rb");
if(pPais==nullptr){return -1;}

fseek(pPais,0,SEEK_END);
cant = ftell(pPais)/sizeof(Pais);
fclose(pPais);
return cant;


}

===================================================================================================================================
Uso en memoria dinamica -->> Uso para manipular archivos 

{
   cant = cantidadPais();
   Pais *obj = new Pais[cant];

   leerPaises(obj,cant);
   ordenerVector(obj,cant);

   for(int i=0; i<cant; i++){
      cout << obj[i].getCodigo() << endl;
      cout << obj[i].getNombre() << endl;
      cout << obj[i].getPoblacion() << endl;
      cout << endl;
    }
    
    delete []obj;
    }

