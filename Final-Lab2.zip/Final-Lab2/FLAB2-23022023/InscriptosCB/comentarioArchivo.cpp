
#include <iostream>
#include <cstdlib>
using namespace std;

#include "Comentarios.h"
#include "comentarioArchivo.h"


comentario comentarioArchivo::leer(int nroRegistro){
  comentario com;
  FILE* p;
  p = fopen("comentarios.dat", "rb");
  if (p == NULL) {
    return com;
  }
  fseek(p, nroRegistro * sizeof(comentario), SEEK_SET);
  fread(&com, sizeof(comentario), 1, p);
  fclose(p);
  return com;

}

int comentarioArchivo::getCantidad(){
    FILE* p = fopen("comentarios.dat", "rb");
  if (p == NULL) {
    return 0;
  }
  fseek(p, 0, SEEK_END);
  int cant = ftell(p) / sizeof(comentario);
  fclose(p);
  return cant;

}
