#ifndef EJERCICIO6_H_INCLUDED
#define EJERCICIO6_H_INCLUDED


class profesores{
private:
    int _Legajo;
    string _Nombre;
    string _Apellido;
    string _Titulo;


public:
    //Gets
    int getLegajo(){return _Legajo;}
    string getNombre(){return _Nombre;}
    string getApellido(){return _Apellido;}
    string getTitulo(){return _Titulo;}
    //Sets
    void setLegajo(int leg){_Legajo=leg;}
    void setNombre(string nom){_Nombre=nom;}
    void setApellido(string ape){_Apellido=ape;}
    void setTitulo(string tit){_Titulo=tit;}

    void cargar();
    void mostrar();



};

void profesores::cargar(){
int leg;
string nom,ape,tit;


cout << "Cargar legajo: ";
cin >> leg;
cout << "Cargar nombre: ";
cin >> nom;
cout << "Cargar apellido: ";
cin >> ape;
cout << "Cargar titulo: ";
cin >> tit;

setLegajo(leg);
setNombre(nom);
setApellido(ape);
setTitulo(tit);

}
void profesores::mostrar(){
cout << "Legajo: " << getLegajo() << endl;
cout << "Nombre: " << getNombre() << endl;
cout << "Apellido: " << getApellido() << endl;
cout << "Titulo: " << getTitulo() << endl;
cout << "- - - - - - - - - - - - - - - - - - " << endl;
}


class alumnos{
private:
     int _Legajo;
     string _Nombre;
     string _Apellido;
     int _Nota;

public:
    //Gets
    int getLegajo(){return _Legajo;}
    string getNombre(){return _Nombre;}
    string getApellido(){return _Apellido;}
    int getNota(){return _Nota;}


    //Sets
    void setLegajo(int leg){ _Legajo=leg;}
    void setNombre(string nom){ _Nombre=nom;}
    void setApellido(string ape){ _Apellido=ape;}
    void setNota(int n){ _Nota=n;}


    void cargar();
    void mostrar();
    bool grabarEnDisco();
    bool leerEnDisco();



};

    void alumnos::cargar(){
    int l,n;
    string nom, ape;
    cout << "Cargar legajo: ";
    cin >> l;
    cout << "Cargar nombre: ";
    cin >> nom;
    cout << "Cargar apellido: ";
    cin >> ape;
    cout << "Cargar nota: ";
    cin >> n;

    setLegajo(l);
    setNombre(nom);
    setApellido(ape);
    setNota(n);

    }

    void alumnos::mostrar(){
    cout << "Legajo: " << getLegajo() << endl;
    cout << "Nombre: " << getNombre() << endl;
    cout << "Apellido: " << getApellido() << endl;
    cout << "Cargar nota: " << getNota() << endl;
    }



#endif // EJERCICIO6_H_INCLUDED
