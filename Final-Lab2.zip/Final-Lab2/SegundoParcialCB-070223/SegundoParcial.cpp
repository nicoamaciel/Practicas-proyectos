
/*
1- Crear un m�todo llamado alumnosDesaprobados que muestre el curso cuya cantidad de alumnos que desaprobaron
el examen final sean la m�s alta, en caso de haber m�s de uno, mostrar todos los cursos que cumplan dicha condici�n.
(20- Puntos)

2- Crear un m�todo llamado peorCurso que muestre los cursos donde todos sus alumnos desaprobaron.
(20- Puntos)

3- Crear un m�todo llamado verGeneraciones que muestre para cada curso la generaci�n en
la que m�s alumnos tenga inscriptos. Se clasifican seg�n el a�o de nacimiento de la siguiente manera:
Generaci�n silenciosa <= 1945
Baby boomers 1946 - 1964
Generaci�n X 1965 - 1980
Millennials 1981 - 1995
Generaci�n Z 1996 - 2012
Generaci�n Alpha >= 2013
(20- Puntos)

4- Crear un m�todo llamado generarReporte que genere un archivo llamado reportes.dat donde
se guarde para cada curso el porcentaje de aprobados y desaprobados de todos los cursos que se hayan terminado.
Un curso est� terminado cuando todos sus alumnos realizaron el examen final.
Crear un m�todo llamado  mostrarReporte que muestre el reporte ley�ndolo del archivo de reportes.dat
(20- Puntos)

ACLARACI�N:
Se aprueba con una nota de examen final mayor o igual a 6
Si la nota tiene un cero, es que aun no realiz� el examen final.
Solo existen 10 cursos, y los ids van del 1 al 10


*/



#include <iostream>
#include <cstdlib>
using namespace std;

#include "SegundoParcial.h"
#include "Estudiante.h"
#include "EstudiantesArchivo.h"
#include "Inscripcion.h"
#include "InscripcionesArchivo.h"
#include "reportes.h"

void SegundoParcial::alumnosDesaprobados(){
InscripcionesArchivo ia;

int cantInscripcion = ia.getCantidad();

Inscripcion* vecIns = new Inscripcion[cantInscripcion];

for(int i=0; i<cantInscripcion; i++){
    vecIns[i] = ia.leer(i);
}

int vecCurso[10]{};

for(int i=0; i<cantInscripcion; i++){
    if(vecIns[i].getNota()>0 && vecIns[i].getNota()<6){
        vecCurso[vecIns[i].getIdCurso()-1]++;
    }
}

int maxVec=0;
int maxId=0;
for(int i=0; i<10; i++){

    if(i==0){
        maxVec=vecCurso[i];
    }

    if(vecCurso[i]>maxVec){
        maxVec=vecCurso[i];
        maxId=i+1;
    }


}

cout << "Curso: " << maxId << " desaprobados: " << maxVec << endl;



delete []vecIns;


}

void SegundoParcial::peorCurso(){

InscripcionesArchivo ia;
int cantInscripcion = ia.getCantidad();

Inscripcion* vecIns = new Inscripcion[cantInscripcion];

for(int i=0; i<cantInscripcion; i++){
    vecIns[i] = ia.leer(i);
}


EstudiantesArchivo es;
int cantEstudiantes = es.getCantidad();

Estudiante* vecEst = new Estudiante[cantEstudiantes];



for(int x=0; x<cantEstudiantes; x++){
    vecEst[x] = es.leer(x);
}

int curso[10]{};
int cantAlumnos[10]{};

for(int y=0; y<cantEstudiantes; y++){
   for(int j=0; j<cantInscripcion; j++){
        if(vecEst[y].getLegajo()==vecIns[j].getLegajo() && vecIns[j].getNota()>0){

            cantAlumnos[vecIns[j].getIdCurso()-1]++;
        }
    }

    for(int i=0; i<cantInscripcion; i++){
        if(vecEst[y].getLegajo()==vecIns[i].getLegajo()){
            if(vecIns[i].getNota()<6){
                curso[vecIns[i].getIdCurso()-1]++;
            }
        }
    }

}

for(int x=0; x<10; x++){

if(cantAlumnos[x]==curso[x]){
    cout <<"Peor curso: " << x+1 << " - Cantidad alumnos: " << cantAlumnos[x]<<endl;
    cout << "Desaprobados : " << curso[x] << endl;
}


}





delete []vecEst;
delete []vecIns;

}


void SegundoParcial::verGeneraciones(){
InscripcionesArchivo ia;
int cantInscripcion = ia.getCantidad();

Inscripcion* vecIns = new Inscripcion[cantInscripcion];

for(int i=0; i<cantInscripcion; i++){
    vecIns[i] = ia.leer(i);
}

EstudiantesArchivo es;
int cantEstudiantes = es.getCantidad();

Estudiante* vecEst = new Estudiante[cantEstudiantes];


for(int x=0; x<cantEstudiantes; x++){
    vecEst[x] = es.leer(x);
}



int mat[10][6]={};


for(int y=0; y<cantEstudiantes; y++){
    for(int x=0; x<cantInscripcion; x++){
        if(vecEst[y].getLegajo()==vecIns[x].getLegajo() && vecEst[y].getFechaNacimiento().getAnio()<=1945){
            mat[vecIns[y].getIdCurso()-1][0]++;
        }
        if(vecEst[y].getLegajo()==vecIns[x].getLegajo() && vecEst[y].getFechaNacimiento().getAnio()>=1946 && vecEst[y].getFechaNacimiento().getAnio()<=1964 ){
            mat[vecIns[y].getIdCurso()-1][1]++;
        }
        if(vecEst[y].getLegajo()==vecIns[x].getLegajo() && vecEst[y].getFechaNacimiento().getAnio()>=1965 && vecEst[y].getFechaNacimiento().getAnio()<=1980 ){
            mat[vecIns[y].getIdCurso()-1][2]++;
        }
        if(vecEst[y].getLegajo()==vecIns[x].getLegajo() && vecEst[y].getFechaNacimiento().getAnio()>=1981 && vecEst[y].getFechaNacimiento().getAnio()<=1995 ){
            mat[vecIns[y].getIdCurso()-1][3]++;
        }
        if(vecEst[y].getLegajo()==vecIns[x].getLegajo() && vecEst[y].getFechaNacimiento().getAnio()>=1996 && vecEst[y].getFechaNacimiento().getAnio()<=2012 ){
            mat[vecIns[y].getIdCurso()-1][4]++;
        }
        if(vecEst[y].getLegajo()==vecIns[x].getLegajo() && vecEst[y].getFechaNacimiento().getAnio()>=2013){
            mat[vecIns[y].getIdCurso()-1][5]++;
        }


    }

}

for(int i=0; i<10; i++){
    for(int a=0; a<6; a++){
        cout << mat[i][a] << " | ";
    }
    cout << endl;
    cout << " -----------------------" << endl;
}


for(int i=0; i<10; i++){
    int maxCant=0;
    int maxGen=0;

    for(int a=0; a<6; a++){
        if (mat[i][a]>maxCant){
            maxCant=mat[i][a];
            maxGen=a+1;
        }

    }


    if(maxGen==1){
      cout << " Curso: " << i+1 <<" - Maximos estudiantes: " << maxCant << " Generacion silenciosa "<<endl;
    }
    if(maxGen==2){
      cout << " Curso: " << i+1 <<" - Maximos estudiantes: " << maxCant << " << Generacion boomers "<<endl;
    }
    if(maxGen==3){
      cout << " Curso: " << i+1 <<" - Maximos estudiantes: " << maxCant << " << Generacion x "<<endl;
    }
    if(maxGen==4){
      cout << " Curso: " << i+1 <<" - Maximos estudiantes: " << maxCant << " << Generacion Milennials "<<endl;
    }
    if(maxGen==5){
      cout << " Curso: " << i+1 <<" - Maximos estudiantes: " << maxCant << " << Generacion z "<<endl;
    }
    if(maxGen==6){
      cout << " Curso: " << i+1 <<" - Maximos estudiantes: " << maxCant << " << Generacion Alpha "<<endl;
    }


}


delete []vecIns;
delete []vecEst;

}


void SegundoParcial::generarReporte(){
InscripcionesArchivo ia;
int cantInscripcion = ia.getCantidad();

Inscripcion* vecIns = new Inscripcion[cantInscripcion];

for(int i=0; i<cantInscripcion; i++){
    vecIns[i] = ia.leer(i);
}

EstudiantesArchivo es;
int cantEstudiantes = es.getCantidad();

Estudiante* vecEst = new Estudiante[cantEstudiantes];


for(int x=0; x<cantEstudiantes; x++){
    vecEst[x] = es.leer(x);
}



float aprobados[10]{};
float desaprobados[10]{};

for(int x=0; x<cantEstudiantes; x++){
        for(int i=0; i<cantInscripcion; i++){
            if(vecEst[x].getLegajo()==vecIns[i].getLegajo()){
                if(vecIns[i].getNota()>0 && vecIns[i].getNota()>=6)
                aprobados[vecIns[i].getIdCurso()-1]++;
            }
        }
    }


for(int x=0; x<cantEstudiantes; x++){
        for(int i=0; i<cantInscripcion; i++){
            if(vecEst[x].getLegajo()==vecIns[i].getLegajo()){
                if(vecIns[i].getNota()>0 && vecIns[i].getNota()<6)
                desaprobados[vecIns[i].getIdCurso()-1]++;
            }
        }
    }



//for(int i=0; i<10; i++){
//    float total=0;
//    float porcentajeA=0;
//    float porcentajeD=0;
//
//    total=aprobados[i]+desaprobados[i];
//    porcentajeA=aprobados[i]*100/total;
//    porcentajeD=desaprobados[i]*100/total;
//    cout << endl;
//    cout << "Curos: " << i+1 << " Pocentaje aprobados -> " << porcentajeA << " %" << endl;
//    cout << "Curos: " << i+1 << " Pocentaje desaprobados -> " << porcentajeD << " %";
//    cout << endl << "-------------------------" << endl;
//}

Reportes cur[10]={};

for(int x=0; x<10; x++){
    float total=0;
    float porcentajeA=0;
    float porcentajeD=0;

    total=aprobados[x]+desaprobados[x];
    porcentajeA=aprobados[x]*100/total;
    porcentajeD=desaprobados[x]*100/total;


    cur[x].setCurso(x+1);
    cur[x].setAprobados(porcentajeA);
    cur[x].setDesaprobados(porcentajeD);
}

FILE* pFile;
pFile = fopen("reportes.dat","wb");
fwrite(cur, sizeof (Reportes), 10, pFile);
fclose(pFile);


delete []vecIns;
delete []vecEst;


}

void SegundoParcial::mostrarReporte(){
FILE* pFile;
pFile = fopen("reportes.dat","rb");
Reportes repo;
while(fread(&repo,sizeof (Reportes), 1, pFile)==1){
    repo.verReportes();
    }




}
