
#include <iostream>
#include <cstdlib>
using namespace std;

#include "ExameneFinal.h"
#include "FinalesArchivo.h"


ExameneFinal finalesArchivo::leer(int nroRegistro){
  ExameneFinal exa;
  FILE* p;
  p = fopen("ExaFinales.dat", "rb");
  if (p == NULL) {
    return exa;
  }
  fseek(p, nroRegistro * sizeof(ExameneFinal), SEEK_SET);
  fread(&exa, sizeof(ExameneFinal), 1, p);
  fclose(p);
  return exa;

}

int finalesArchivo::getCantidad(){
    FILE* p = fopen("ExaFinales.dat", "rb");
  if (p == NULL) {
    return 0;
  }
  fseek(p, 0, SEEK_END);
  int cant = ftell(p) / sizeof(ExameneFinal);
  fclose(p);
  return cant;

}
