/**
Cerca de la UTN hay una sala de eventos llamado **�Gentes�**,
el due�o quiere que realicemos un sistema de control de acceso a la sala,
ya que actualmente lo lleva todo en papel y se suele perder un poco.

El sistema debe contar con el siguiente men�:

```cpp
**1- CARGAR INVITADOS
2- INGRESO DE INVITADO
3- EGRESO DE INVITADO
4- LISTA DE INVITADOS
0- SALIR**
```

**CARGAR INVITADOS:** Debe permitirme cargar 5 invitados al evento (Nombre y DNI)

**INGRESO DE INVITADO:** A partir de su DNI y una Hora, marca el ingreso de una persona

**EGRESO DE INVITADO:** A partir de su DNI y una Hora, marca el egreso de una persona

**LISTA DE INVITADOS:** Muestra un listado de todos los invitados, informando quienes no fueron al evento,
quienes aun est�n en el evento y el tiempo que estuvieron en el evento

**SALIR:** Finaliza el programa

**/

#include <iostream>

using namespace std;
#include "gentes.h"
#include "egreso.h"
#include "ingreso.h"

int main()
{
    gentes vector_obj[5]{};
    ingreso VecIngresos[5]{};
    egreso VecEgresos[5]{};


    int opcion;
    int x=0, y=0;

    int valIngreso, valEgreso;
    while(true){
    system("cls");
    cout << "- - - - - - - - GENTES - - - - - - - " << endl;
    cout << "1-         CARGAR INVITADOS: " << endl;
    cout << "2-         INGRESO DE INVITADOS: " << endl;
    cout << "3-         EGRESO DE INVITADOS: " << endl;
    cout << "4-         LISTA DE INVITADOS: " << endl;
    cout << "0-         SALIR: " << endl;
    cin >> opcion;
    system("cls");
        switch(opcion){
        case 1:
            for (int i=0; i<5; i++){
                vector_obj[i].cargarInvitados();

            }
        break;
        case 2:
            cout << "Si el invitado falto ingrese 0" << endl;
            for(int x=0; x<5; x++){
                cout << "Ingreso del invitado #: " << x+1<< endl;
                VecIngresos[x].cargarIngreso();
            }
        break;
        case 3:
            cout << "Si el invitado falto ingrese 0" << endl;
            for(int y=0; y<5; y++){
                cout << "Egreso del invitado #:  " << y+1 << endl;
                VecEgresos[y].cargarEgreso();
            }

        break;
        case 4:
            for (int i=0; i<5; i++){

                if(vector_obj[i].getDni()==VecIngresos[i].getDni()){
                    cout << "Invitado: " << vector_obj[i].getNombre() << endl;
                    if(VecEgresos[i].getHoraEgreso()>0){
                        cout << "Estuvo en el evento: " << VecEgresos[i].getHoraEgreso() - VecIngresos[i].getHoraIngreso() << " hs" << endl;
                    }
                    else{
                        if(VecIngresos[i].getHoraIngreso()>0){
                            cout << "Permanece en e� evento" << endl;
                        }
                        else{
                            cout << "No fue al evento" << endl;
                        }

                    }

                }

                cout << "- - - - - - - - - - - - - - - - - - " << endl;
            }

        break;
        case 0:
            return 0;
        break;


        }
        system("pause");


    }

    cout<<endl;
    system("pause");

    return 0;
}
