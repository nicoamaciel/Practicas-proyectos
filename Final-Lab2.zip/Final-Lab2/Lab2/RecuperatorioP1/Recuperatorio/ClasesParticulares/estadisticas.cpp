
#include <iostream>
using namespace std;
#include "estadisticas.h"


int estadistica::getCurso(){
    return _curso;
}


int estadistica::getRecaudacion(){
    return _recaudacion;
}


void estadistica::setCurso(int cur){
    _curso=cur;
}


void estadistica::setRecaudacion(float reca){
    _recaudacion=reca;
}


void estadistica::verEstadisticas(){
    cout << "Curso: " << getCurso() << " " << "Recaudacion: " << getRecaudacion() << endl;
    cout << " - - - - - - - - - - - - - " << endl;
}
//MacielNicolas 01-12 legajo24290
