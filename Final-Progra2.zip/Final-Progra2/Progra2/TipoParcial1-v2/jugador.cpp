#include <iostream>
using namespace std;
#include "jugador.h"
#include "partido.h"
int main(){
//jugador obj[10];
//
//
//for(int i=0; i<10; i++){
//    obj[i].cargar();
//    if(obj[i].grabarEnDisco()){
//        cout << "Archivo grabado con exito!" << endl;
//        system("pause");
//    }
//
//
//}







jugador obj;

obj.cargar();
obj.grabarEnDisco();


int pos=0;

while(obj.leerDeDisco(pos)){
    obj.mostrar();
    pos++;
}


return 0;
}
