#include <iostream>

using namespace std;

#include "ingreso.h"

    //Gets
    int ingreso::getDni(){
        return _Dni;
    }
    int ingreso::getHoraIngreso(){
        return _HoraIngreso;
    }

    //Sets
    void ingreso::setDni(int dni){
        _Dni=dni;
    }
    void ingreso::setHoraIngreso(int hora){
        _HoraIngreso=hora;

    }

    //Comportamiento

    void ingreso::cargarIngreso(){
    int dni, hora;

    cout << "Ingrese dni: ";
    cin >> dni;
    cout << "Ingrese hora (00hs a 24hs exactas): ";
    cin >> hora;
    cout << "----------------------" << endl;

    setDni(dni);
    setHoraIngreso(hora);

    }
