#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

class botella{

private:
    float _capacidad; //La capacidad total de carga del recipiente.
    float _ocupacion; //La carga actual del recipiente.
    bool _tapada;
public:
    botella(float capacidad=100); //Constructor
    //Gets
    float getCapacidad();
    float getOcupacion();
    bool getTapada();
    //Sets
    void setCapacidad(float);
    void setOcupacion(float);
    void setTapada(bool);

    //Comportamientos
    void llenar(float); //Debe permitir aumentar la ocupaci�n del recipiente pero nunca por encima de su capacidad.
    void vaciar(float); //Debe permitir disminuir la ocupaci�n del recipiente pero nunca por debajo de 0.
    void tapar(); //Debe tapar la botella.
    void destapar(); //Debe destapar la botella.
    void mostrar(); //Mostrar contenido de botella.

};




#endif // FUNCIONES_H_INCLUDED
