#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED

class menu{
private:

public:
    int menuPrincipal();
    int mantenimieto();
    int altaBaja();
    int consultas();
    int exportar();

};



#endif // MENU_H_INCLUDED
