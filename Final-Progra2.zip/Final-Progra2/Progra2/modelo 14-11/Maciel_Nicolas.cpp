
///Ejercicio: Parcial 2 de Programaci�n II
///Autor:MacielNicolas
///Fecha:14/11/2022
///Comentario:

/*
1) Generar un archivo con los pasajeros que hayan comprado pasajes en el presente a�o.
El formato del archivo debe ser igual que el del archivo de pasajeros.

2) Generar un archivo con la cantidad de vuelos realizados por los aviones.
Cada registro debe tener el c�digo de avi�n, el nombre y la cantidad de vuelos.

3) Generar un vector din�mico para copiar y luego mostrar el archivo del punto anterior.

*/

#include <cstring>
#include <cstdio>
#include <iostream>
using namespace std;

#include "parcial2.h"


//Punto1
class pasajeros22{
private:
    int numeroPasajero;
    char nombre[30];
    char telefono[30];
    char direccion[30];
    int provincia;
    bool activo;
public:
    void setNumeroPasajero(int np){numeroPasajero=np;}
    void setProvincia(int np){provincia=np;}
    void setNombre(const char *n){strcpy(nombre,n);}
    void setTelefono(const char *n){strcpy(telefono,n);}
    void setDireccion(const char *n){strcpy(direccion,n);}
    void setActivo(bool a){activo=a;}

    int leerDeDisco(int pos){
        FILE *p;
        p=fopen("pasajeros.dat", "rb");
        if(p==NULL) return -1;
        fseek(p, sizeof *this*pos,0);
        int leyo=fread(this, sizeof *this,1, p);
        fclose(p);
        return leyo;
    }

    int grabarEnDisco(){
        FILE *p;
        p=fopen("pasajeros.dat", "ab");
        if(p==NULL) return -1;
        int grabo=fwrite(this, sizeof *this,1, p);
        fclose(p);
        return grabo;
    }

    void Mostrar(){
        cout<<numeroPasajero<<endl;
        cout<<nombre<<endl;
        cout<<telefono<<endl;
        cout<<direccion<<endl;
        cout<<provincia<<endl;
    }


};

class vuelosRealizados{
    private:
    int codigoAvion;
    char nombre[30];
    int cantidadVuelos;
    public:

    int getCodigoAvion(){return codigoAvion;}
    const char *getNombre(){return nombre;}
    int getCantidadVuelos(){return cantidadVuelos;}

    void setCodigoAvion(int ca){codigoAvion=ca;}
    void setNombre(const char *m){strcpy(nombre,m);}
    void setCantidadVuelos(int ca){cantidadVuelos=ca;}

    int leerDeDisco(int pos){
        FILE *p;
        p=fopen("vuelosRealizados.dat", "rb");
        if(p==NULL) return -1;
        fseek(p, sizeof *this*pos,0);
        int leyo=fread(this, sizeof *this,1, p);
        fclose(p);
        return leyo;
    }

    int grabarEnDisco(){
        FILE *p;
        p=fopen("vuelosRealizados.dat", "ab");
        if(p==NULL) return -1;
        int grabo=fwrite(this, sizeof *this,1, p);
        fclose(p);
        return grabo;
    }

    void Mostrar(){
        cout<<codigoAvion<<endl;
        cout<<nombre<<endl;
        cout<<cantidadVuelos<<endl;
    }


};



///Prototipos
void punto1();
    bool buscarPasajero(int num);

void punto2();
    int cantidadAviones();

int main(){

int pos;
punto1();
pasajeros22 reg;
while(reg.leerDeDisco(pos)){
    reg.Mostrar();
    pos++;
}

cout << " - - - - - - - - - - - - - - - - - - " << endl;


return 0;
}


void punto1(){
Pasajero reg;
pasajeros22 obj;
int pos=0;

while(reg.leerDeDisco(pos)){
    if(buscarPasajero(reg.getNumeroPasajero())==true){
        obj.setNumeroPasajero(reg.getNumeroPasajero());
        obj.setProvincia(reg.getProvincia());
        obj.setNombre(reg.getNombre());
        obj.setTelefono(reg.getTelefono());
        obj.setDireccion(reg.getDireccion());
        obj.setActivo(reg.getActivo());

        obj.grabarEnDisco();
    }

    pos++;
}


}


bool buscarPasajero(int num){
Pasaje reg;
int pos=0;
while(reg.leerDeDisco(pos)){
    if(num==reg.getNumeroPasajero() && reg.getFechaCompra().getAnio()==2021){
        return true;
    }
    pos++;
}

}

void punto2(){

int cant = cantidadAviones();

int *pAviones = new int[cant];


}

int cantidadAviones(){
Avion reg;
int pos=0;

while(reg.leerDeDisco(pos)){
    if(reg)

    pos++;
}




}
