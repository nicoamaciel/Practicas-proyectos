#include <cstring>
#include <iostream>
using namespace std;

#include "Estadisticas.h"

    int Estadisticas::getCurso(){
        return _curso;
    }
    float Estadisticas::getRecaudacion(){
        return _recaudacion;

    }
    void Estadisticas::setCurso(int cur){
        _curso=cur;

    }
    void Estadisticas::setRecaudacion(float reca){
        _recaudacion=reca;

    }
    void Estadisticas::verEstadisticas(){
        cout << " Curso " << getCurso() << endl;
        cout << " Promedio recaudacion: " << getRecaudacion() << endl;
    }
