#include <iostream>
using namespace std;

#include "modelo1.h"
#include "EstudiantesArchivo.h"
#include "ExamenesArchivo.h"

void modeloParcial::punto1(){

EstudiantesArchivo esa;
ExamenesArchivo exa;

int cantidadEstu = esa.getCantidad();
int cantidadExa = exa.getCantidad();


Estudiante* vecEst = new Estudiante[cantidadEstu];

for(int i=0; i<cantidadEstu; i++){
    vecEst[i] = esa.leer(i);
}


Examen* vecExa = new Examen[cantidadExa];

for(int j=0; j<cantidadExa; j++){
    vecExa[j] = exa.leer(j);

}

for(int i=0; i<cantidadEstu; i++){
    bool noRindio = true;

    for(int j=0; j<cantidadExa; j++){
        if(vecEst[i].getLegajo() == vecExa[j].getLegajo() && vecExa[j].getFecha().getAnio()==2022){
            noRindio = false;
        }

    }

    if(noRindio==true){
        cout << " " << vecEst[i].getLegajo() << " " << vecEst[i].getNombres() << " " << vecEst[i].getApellidos() << endl;

    }


}






}

void modeloParcial::punto2(){

EstudiantesArchivo esa;
ExamenesArchivo exa;

int cantidadEstu = esa.getCantidad();
int cantidadExa = exa.getCantidad();


Estudiante* vecEst = new Estudiante[cantidadEstu];

for(int i=0; i<cantidadEstu; i++){
    vecEst[i] = esa.leer(i);
}


Examen* vecExa = new Examen[cantidadExa];

for(int j=0; j<cantidadExa; j++){
    vecExa[j] = exa.leer(j);

}


for(int i=0; i<cantidadEstu; i++){
    int aprobados =0;
    int desaprobados =0;
    for(int j=0; j<cantidadExa; j++){
        if(vecEst[i].getLegajo() == vecExa[j].getLegajo()){
            if(vecExa[j].getNota()>=6){
                aprobados++;
            }
            if(vecExa[j].getNota()<6){
                desaprobados++;
            }

        }
    }


    cout << vecEst[i].getLegajo() << " " << vecEst[i].getNombres() << " " << vecEst[i].getApellidos() << endl;
    cout << " aprobados: " << aprobados;
    cout << " desprobados: " << desaprobados;
    cout << endl << "---------------------------" << endl;

}





}

void modeloParcial::punto3(){

EstudiantesArchivo esa;
ExamenesArchivo exa;

int cantidadEstu = esa.getCantidad();
int cantidadExa = exa.getCantidad();


Estudiante* vecEst = new Estudiante[cantidadEstu];

for(int i=0; i<cantidadEstu; i++){
    vecEst[i] = esa.leer(i);
}


Examen* vecExa = new Examen[cantidadExa];

for(int j=0; j<cantidadExa; j++){
    vecExa[j] = exa.leer(j);

}


int cantidadAlu=0;

for(int i=0; i<cantidadEstu; i++){
    int vecMaterias[60]{};
    bool masDeDos=false;


    for(int j=0; j<cantidadExa; j++){
        if(vecEst[i].getLegajo()==vecExa[j].getLegajo()
        && vecExa[j].getFecha().getAnio()>=2018
        && vecExa[j].getFecha().getAnio()<=2022){
        vecMaterias[vecExa[j].getIDMateria()-1]++;
        }

        if(vecMaterias[vecExa[j].getIDMateria()-1]>=2){
            masDeDos=true;
        }
    }

    if(masDeDos==true){
        cantidadAlu++;
    }


}

cout << "Cantidad de alumnos que hayan rendido examen mas de una vez: " << cantidadAlu << endl;




}
