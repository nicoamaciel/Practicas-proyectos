
#include <iostream>
#include <stdio.h>
#include <ctime>

using namespace std;

int main() {

    int d=0;
    int m=0;
    int a=0;
    int actual, pedido, mostrar;

	time_t now;
    struct tm *now_tm;
    now = time(NULL);
    now_tm = localtime(&now);

	int day, mouth, year;
   	day = now_tm->tm_mday;
   	mouth = now_tm->tm_mon + 1;
   	year = now_tm->tm_year;
   	year += 1900;

   	printf("\n%d/%d/%d\n", day, mouth, year);

    cout << "Ingrese dia: ";
    cin >> d;
    cout << "Ingrese mes: ";
    cin >> m;
    cout << "Ingrese anio: ";
    cin >> a;
    pedido = (a*365)+(m-1)*30+(d);
    actual = (year*365)+(mouth-1)*30+(day);
    cout <<endl;

    if(pedido>actual){
        mostrar = pedido - actual;
    }else{
        mostrar = actual - pedido;
    }

    cout << mostrar << endl;




}
