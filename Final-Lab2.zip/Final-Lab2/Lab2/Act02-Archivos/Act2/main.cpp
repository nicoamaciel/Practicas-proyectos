#include <iostream>
using namespace std;
#include "Pais.h"
#include "Ciudad.h"
/*
1 - Hacer un listado de pa�ses ordenado por poblaci�n de manera decreciente. Indicar en el listado:
C�digo del pa�s, nombre del pa�s y poblaci�n.

2 - Agregar una funci�n global que permita agregar una ciudad al archivo de ciudades.
Se deber� verificar que:
    - El ID de Ciudad no exista previamente en el archivo de ciudades.
    - El C�digo de Pa�s exista  en el archivo de pa�ses.
    - La Poblaci�n sea mayor a cero.

3 - Agregar una funci�n global que solicite el nombre de una ciudad y la poblaci�n e informe qu� posici�n
 ubicar�a si se hiciese un ranking mundial ordenado por poblaci�n de manera decreciente.

4 - Agregar una funci�n global que solicite el c�digo de un pa�s y permita actualizar en el archivo la poblaci�n de dicho pa�s.
Indicar con un mensaje aclaratorio si pudo actualizarse o no.

5 - Hacer un archivo llamado mundo.dat que contenga la siguiente informaci�n:
    -   C�digo de pa�s
    -   Nombre del pa�s
    -   Nombre de la ciudad de mayor poblaci�n
    -   Poblaci�n de la ciudad de mayor poblaci�n

*/
int main()
{
    int opc;
    int cant;



    while(true){
        system("cls");
        cout << " ------menu------" << endl;
        cout << "Punto 1 - " << endl;
        cout << "Punto 2 - " << endl;
        cout << "Punto 3 - " << endl;
        cout << "Punto 4 - " << endl;
        cout << "Punto 5 - " << endl;
        cout << "------------------" << endl;
        cout << "opcion: " << endl;
        cin >> opc;
        system("cls");
        switch(opc){
        case 1:
            {
            cant = cantidadPais();
            Pais *obj = new Pais[cant];

            leerPaises(obj,cant);
            ordenerVector(obj,cant);

            for(int i=0; i<cant; i++){
                cout << obj[i].getCodigo() << endl;
                cout << obj[i].getNombre() << endl;
                cout << obj[i].getPoblacion() << endl;
                cout << endl;
            }

            delete []obj;
            }
            break;
        case 2:
           /*{
            if(buscarId()){
                cout << "Id de ciudad ya ingresado previamente"<<endl;
            }else{
                if(buscarPais()==false){
                cout << "Cod de pais no existe en el archivo"<<endl;
                }else{
                    cargarCiudad();
                    grabarCiudad();
                }

            }




            }*/

            break;
        case 3:


            mostrarPaises();





            break;
        case 4:

            break;
        case 5:

            break;


        case 0: return 0;
        break;
        }
        system("pause");
    }



    return 0;
}
