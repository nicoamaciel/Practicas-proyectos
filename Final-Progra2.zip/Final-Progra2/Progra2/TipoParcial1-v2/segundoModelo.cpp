#include <iostream>
#include <cstring>
#include <cstdlib>
using namespace std;

#include "partido.h"
#include "jugador.h"
/*
1 - Informar la cantidad total de expulsiones por mes.
2- Generar un archivo de los jugadores que no participaron de ning�n partido con el siguiente formato:
    - C�digo de jugador
    -   Nombre
    -   C�digo de equipo
3 - Sabiendo que el jugador m�s joven tiene 17 a�os y el mayor 41, informar la edad con mayor cantidad de jugadores.
4 - El jugador que m�s goles convirti�.

*/

class nojugo{
private:
    char CodigoJugador[5];
    char Nombre[30];
    char CodigoEquipo[3];
public:

    //Gets
    const char *getCodigoJugador(){return CodigoJugador};
    const char *getNombre(){return Nombre};
    const char *getCodgioEquipo(){return CodigoEquipo};


    //Sets
    void setCodigoJugador(const char *jugador){strcpy(CodigoJugador,jugador)};
    void setNombre(const char *nomb){strcpy(Nombre,nomb);}
    void setCodgioEquipo(const char *equipo){strcpy(CodigoEquipo,equipo);}

    //Comportamiento
    bool grabarEnDisco();



};



//Prototipos
int buscarExpulsados();
    void mostrarVector(int *vec,int tam);
void archivoNojugo();

int main(){

return 0;
}


int buscarExpulsados(){
int vExpulsados[12];

partido reg;
int pos=0;

while(reg.leerDisco(pos)){
    if(reg.getExpulsado()){
        vExpulsados[reg.getExpulsado()-1]++;
    }

    pos++;
}

mostrarVector(vExpulsados,12);

}

void mostrarVector(int *vec,int tam){
    cout << "MES " << "   | " << " EXPULSADOS" << endl;
    for(int i=0; i<tam; i++){
    cout << i+1 << "    | " << vec[i] ;

    }


}

void archivoNojugo(){
char cod[5];

partido reg;
int pos=0, comparador;

while(reg.leerDisco(pos)){
    if(reg.)


    }


}
