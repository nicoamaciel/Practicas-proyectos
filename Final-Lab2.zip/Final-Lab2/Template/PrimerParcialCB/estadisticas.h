#ifndef ESTADISTICAS_H_INCLUDED
#define ESTADISTICAS_H_INCLUDED

class estadisticas{
private:
    int _anio;
    float _recaudacion;
public:
    int getRecaudacion();
    int getAnio();
    void setAnio(int an);
    void setRecaudacion(float reca);
    void add(float reca);
    void verEstadisticas();

};


#endif // ESTADISTICAS_H_INCLUDED
