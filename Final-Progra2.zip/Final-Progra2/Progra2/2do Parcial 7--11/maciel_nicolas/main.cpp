
///Maciel Nicolas
///parcial 2 - 7/11


#include <iostream>
#include <cstdlib>
#include <cstring>

using namespace std;
#include "clasesp2.h"

/*
1-Crear un archivo con las asignaciones realizadas para el proyecto Gesti�n ventas DEK SA en el a�o 2021.
El archivo debe tener el mismo formato que el archivo de asignaciones, pero sin la fecha.
Mostrar el archivo creado.


2-Dar de baja l�gica en el archivo de asignaciones a los registros del a�o actual.
Listar el archivo omitiendo los registros dados de baja.


4-Crear un vector din�mico para copiar y mostrar el archivo luego de las modificaciones del punto 2.

*/

class dek21{
private:
    int numero;
        int _legajoProgramador;
        int _codigoProyecto;
        int _localidad;
        bool _estado;
public:
        void setLegajoProgramador(int leg){_legajoProgramador=leg;}
        void setCodigoProyecto(int cod){_codigoProyecto=cod;}
        void setLocalidad(int loc){_localidad=loc;}
        void setEstado(bool est){_estado=est;}

        int getLegajoProgramador(){return _legajoProgramador;}
        int getCodigoProyecto(){return _codigoProyecto;}
        int getLocalidad(){return _localidad;}
        bool getEstado(){return _estado;}

        void mostrar();
        void grabarEnDisco();
        bool leerDeDisco(int pos);

};

class modificarArchivo{
private:
    int numero;
    int legajoProgramador;
    int codigoProyecto;
    int localidad;
    Fecha fechaAsignacion;
    bool estado;

    public:
    void setNumero(int num){numero=num;}
    void setLegajoProgramador(int leg){legajoProgramador=leg;}
    void setCodigoProyecto(int cP){codigoProyecto=cP;}
    void setLocalidad(int loc){localidad=loc;}
    void setFechaAsignacion(Fecha fe){fechaAsignacion=fe;}
    void setEstado(bool e){estado = e;}


        void Mostrar(){
            cout<<"NUMERO "<<numero<<endl;
            cout<<"LEGAJO "<<legajoProgramador<<endl;
            cout<<"CODIGO "<<codigoProyecto<<endl;
            cout<<"LOCALIDAD "<<localidad<<endl;
            fechaAsignacion.Mostrar();
            cout<<endl;
        }

    void operator=(Asignacion &reg){
        numero=reg.getNumero();
        legajoProgramador=reg.getLegajoProgramador();
        codigoProyecto=reg.getCodigoProyecto();
        localidad=reg.getLocalidad();
        fechaAsignacion.setDia(reg.getFechaAsignacion().getDia());
        fechaAsignacion.setMes(reg.getFechaAsignacion().getMes());
        fechaAsignacion.setAnio(reg.getFechaAsignacion().getDia());
        estado=reg.getEstado();
    }


};


void punto1();
void punto2();
    bool modificarArchivo(Asignacion reg, int pos);
void punto3();
    int contarFalse();
    void copiarFalse(Asignacion *pFalse);
    void mostrarFalse(Asignacion *pFalse, int cant);


int main(){
dek21 reg;
Asignacion obj;
int pos,pos2;

//Punto1
//punto1();

while(reg.leerDeDisco(pos)){
    reg.mostrar();
    pos++;

}

cout << " - - - - - - - - - - " << endl;
punto2();
while(obj.leerDeDisco(pos++)){
    if(obj.getEstado()==true){
        obj.Mostrar();
    }
}

//Punto3
cout << " - - - - - - - - - - " << endl;
punto3();

return 0;
}





//Punto1

void dek21::grabarEnDisco(){
    FILE *pDek;
    pDek = fopen("dek21.dat","ab");
    if(pDek==NULL){
    cout << "Error en archivo";
    }

   bool escribio = fwrite(this, sizeof(dek21), 1, pDek);
   fclose(pDek);

}

bool dek21::leerDeDisco(int pos){
    FILE *pDek;
    pDek=fopen("dek21.dat","rb");
    if(pDek==NULL) return false;
    fseek(pDek,pos*sizeof *this, 0);
    bool leyo=fread(this, sizeof *this, 1, pDek);
    fclose(pDek);
    return leyo;

}

void dek21::mostrar(){
    cout << "Legajo del programador: " << getLegajoProgramador() <<endl;
    cout << "Codigo de proyecto: " << getCodigoProyecto() << endl;
    cout << "Localidad: " << getLocalidad() << endl;
    cout << "Estado: " << getEstado() << endl;
}



void punto1(){
Asignacion reg;
dek21 cargar;
int pos=0;

while(reg.leerDeDisco(pos)){

    if(reg.getFechaAsignacion().getAnio()==2021 && reg.getCodigoProyecto()==2){
        cargar.setLegajoProgramador(reg.getLegajoProgramador());
        cargar.setCodigoProyecto(reg.getCodigoProyecto());
        cargar.setLocalidad(reg.getLocalidad());
        cargar.setEstado(reg.getEstado());

        cargar.grabarEnDisco();
        }
    pos++;
    }


    }


void punto2(){

Asignacion reg;
int pos=0;

while(reg.leerDeDisco(pos)){
    if(reg.getFechaAsignacion().getAnio()==2021){
        reg.setEstado(false);
        modificarArchivo(reg,pos);
    }
    pos++;
 }

}

bool modificarArchivo(Asignacion reg, int pos){
FILE *p = fopen("asignaciones.dat","rb+");
if(p==NULL){return false;}

fseek(p,sizeof(Asignacion)*pos,0);
bool escribio = fwrite(&reg,sizeof reg,1,p);
fclose(p);
return escribio;

}

void punto3(){
Asignacion *pFalse;
int cant = contarFalse();

pFalse = new Asignacion[cant];
if(pFalse==NULL){"Error";}
copiarFalse(pFalse);
mostrarFalse(pFalse,cant);

delete []pFalse;

}

int contarFalse(){
Asignacion reg;
int pos=0, cant=0;

while(reg.leerDeDisco(pos)){
    if(reg.getEstado()==false && reg.getFechaAsignacion().getAnio()==2021){
        cant++;
    }

    pos++;
}
return cant;

}


void copiarFalse(Asignacion *pFalse){
Asignacion reg;
int pos=0, i=0;

while(reg.leerDeDisco(pos)){
    if(reg.getEstado()==false && reg.getFechaAsignacion().getAnio()==2021){
        pFalse[i++]=reg;
    }

    pos++;
}

}


void mostrarFalse(Asignacion *pFalse, int cant){

for(int i=0; i<cant; i++){
    pFalse[i].Mostrar();
    cout << endl;
    }

}



