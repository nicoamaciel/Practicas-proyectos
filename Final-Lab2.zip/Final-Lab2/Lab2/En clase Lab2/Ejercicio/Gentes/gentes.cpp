#include <iostream>

using namespace std;

#include "gentes.h"

    //Gets
    string gentes::getNombre(){
    return _Nombre;
    }


    int gentes::getDni(){
    return _Dni;
    }


    //Sets
    void gentes::setNombre(string nomb){
    _Nombre=nomb;

    }

    void gentes::setDni(int dni){
    _Dni=dni;

    }


    //Comportamiento

    void gentes::cargarInvitados(){
    string nom;
    int hora, dni;

    cout << " Ingrese nombre: ";
    cin >> nom;
    cout << " Ingrese dni: ";
    cin >> dni;
    cout << "----------------------" << endl;

    setNombre(nom);
    setDni(dni);

    }

    void gentes::mostrarInvitados(){

    cout << " Nombre: " << getNombre() << endl;
    cout << " Dni: " << getDni() << endl;


    }



