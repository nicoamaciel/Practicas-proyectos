#include <cstring>
#include <cstdio>
#include <iostream>
using namespace std;
===================================================================================================================================
============================================== Crear clase en .h con nombre de clase ==============================================
===================================================================================================================================
class Pais{
    private:
        char _codigo[4];
        char _codigo2[3];
        char _nombre[45];
        char _continente[20];
        float _superficie;
        int _poblacion;
        short _independencia;
        float _expectativaDeVida;
        int _capital;
    public:
        void mostrar();

        void setCodigo(const char *);
        void setCodigo2(const char *);
        void setNombre(const char *);
        void setContinente(const char *);
        void setSuperficie(float);
        void setPoblacion(int);
        void setIndependencia(short);
        void setExpectativaDeVida(float);
        void setIDCapital(int);
        char * getCodigo();
        char * getCodigo2();
        char * getNombre();
        char * getContinente();
        float getSuperficie();
        int getPoblacion();
        short getIndependencia();
        float getExpectativaDeVida();
        int getIDCapital();
};


==============================================================================================================
============================================== archivo cpp continuacion ======================================
==============================================================================================================

#include "Pais.h"
#include <cstring>
#include <cstdio>
#include <iostream>
using namespace std;

void Pais::setCodigo(const char *codigo){
    strcpy(_codigo, codigo);
}
void Pais::setCodigo2(const char *codigo2){
    strcpy(_codigo2, codigo2);
}
void Pais::setNombre(const char *nombre){
    strcpy(_nombre, nombre);
}
void Pais::setContinente(const char *continente){
    strcpy(_continente, continente);
}
void Pais::setSuperficie(float superficie){
    _superficie = superficie;
}
void Pais::setPoblacion(int poblacion){
    _poblacion = poblacion;
}
void Pais::setIndependencia(short independencia){
    _independencia = independencia;
}
void Pais::setExpectativaDeVida(float expectativa){
    _expectativaDeVida = expectativa;
}
void Pais::setIDCapital(int IDCapital){
    _capital = IDCapital;
}
char * Pais::getCodigo(){
    return _codigo;
}
char * Pais::getCodigo2(){
    return _codigo2;
}
char * Pais::getNombre(){
    return _nombre;
}
char * Pais::getContinente(){
    return _continente;
}
float Pais::getSuperficie(){
    return _superficie;
}
int Pais::getPoblacion(){
    return _poblacion;
}
short Pais::getIndependencia(){
    return _independencia;
}
float Pais::getExpectativaDeVida(){
    return _expectativaDeVida;
}
int Pais::getIDCapital(){
    return _capital;
}

==============================================================================================================
==============================================================================================================


