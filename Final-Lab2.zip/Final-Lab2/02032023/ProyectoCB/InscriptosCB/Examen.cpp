
#include <iostream>
#include <cstdlib>
#include <stdio.h>
#include <string.h>
using namespace std;

#include "Estudiante.h"
#include "EstudiantesArchivo.h"
#include "ExameneFinal.h"
#include "FinalesArchivo.h"
#include "Fecha.h"

#include "Examen.h"


void Examen::leerExamenes(){
finalesArchivo exa;
int cantExa = exa.getCantidad();
ExameneFinal* vecExa= new ExameneFinal[cantExa];
if(vecExa==nullptr){cout << "error en vec dinamico";}

    for(int i=0; i<cantExa; i++){
        vecExa[i] = exa.leer(i);
    }

    for(int i=0; i<cantExa; i++){
        cout << "Id de Alumno: "<< vecExa[i].getId() <<  endl;
        cout << "Legajo alumno: "<< vecExa[i].getLegajo()<< endl;
        cout << "Nota: "<< vecExa[i].getNota()<< endl;
        cout << "Id materia: "<< vecExa[i].getIDMateria()<< endl;

        cout << " - - - - - - - - - - - " << endl;
    }



}



void Examen::crearExamenFinal(){

    int id, leg, idMat, nota;
    char obs[300];
    Fecha fe;
    int d,m,a;
    bool pos;


    cout << "Cargar ID de alumno: ";
    cin >>id;

    do{
        cout << "Cargar legajo del alumno: ";
        cin >> leg;
        cout << "Cargar id de meteria: ";
        cin >>idMat;
        pos = validarAlumno(leg,idMat);
        if(pos==false){
        cout << "Error de validacion en datos suministrados" << endl;
        system("pause");
        }



    }while(pos==false);

    cout << "Cargar nota: ";
    cin >> nota;
    cout << "Cargar observacion: ";
    cin >> obs;
    cout << "Cargar fecha de publicacion: "<<endl;
    cout << "Dia: ";
    cin>>d;
    cout << "Mes: ";
    cin>>m;
    cout << "Anio: ";
    cin>>a;


    if(pos==true){
    ExameneFinal obj;
    obj.setId(id);
    obj.setLegajo(leg);
    obj.setNota(nota);
    obj.setIDMateria(idMat);
    obj.setObservacion(obs);
    fe.setDia(d);
    fe.setMes(m);
    fe.setAnio(a);
    obj.grabarenDisco();

    }

}

void Examen::alumnosAprobados(){

EstudiantesArchivo est;
int canEstudiantes = est.getCantidad();
Estudiante* vecEst = new Estudiante[canEstudiantes];
if(vecEst==nullptr){cout << "error en vec dinamico";}

    for(int x=0; x<canEstudiantes; x++){
        vecEst[x] = est.leer(x);
    }


finalesArchivo exa;
int cantExa = exa.getCantidad();
ExameneFinal* vecExa= new ExameneFinal[cantExa];
if(vecExa==nullptr){cout << "error en vec dinamico";}

    for(int i=0; i<cantExa; i++){
        vecExa[i] = exa.leer(i);
    }



    for(int x=0; x<canEstudiantes; x++){
        for(int y=0; y<cantExa; y++){
            if(vecEst[x].getLegajo()==vecExa[y].getLegajo() && vecExa[y].getNota()>6){
                cout << vecEst[x].getNombres() << endl;
                cout << vecEst[x].getLegajo() << endl;
            }

        }

    }

}


void Examen::dificultadExamen(int anio){

/*
3- Crear un m�todo llamado dificultadExamen que reciba como par�metro un a�o y muestre para cada materia el
porcentaje de aprobados y de desaprobados, considerando solamente aquellos ex�menes que
fueron realizados en ese a�o.

*/
finalesArchivo exa;
int cantExa = exa.getCantidad();
ExameneFinal* vecExa= new ExameneFinal[cantExa];
if(vecExa==nullptr){cout << "error en vec dinamico";}

    for(int i=0; i<cantExa; i++){
        vecExa[i] = exa.leer(i);
    }

float aprobados[5]{};
float desaprobados[5]{};

for(int i=0; i<cantExa; i++){
        if(vecExa[i].getFechaExamen().getAnio()==anio){
            if(vecExa[i].getNota()>=6){
                aprobados[vecExa[i].getIDMateria()-1]++;
            }
            if(vecExa[i].getNota()<6){
                desaprobados[vecExa[i].getIDMateria()-1]++;
            }
        }
    }

float ap;
float des;
float total;
for(int i=0; i<5; i++){
    ap = aprobados[i];
    des =desaprobados[i];
    total = ap+des;
}

cout << "Desaprobados: " << des*100/total;
cout << "Aproados: " << ap*100/total;

}



bool validarAlumno(int leg,int mat){

EstudiantesArchivo est;
int canEstudiantes = est.getCantidad();
Estudiante* vecEst = new Estudiante[canEstudiantes];
if(vecEst==nullptr){cout << "error en vec dinamico";}

    for(int x=0; x<canEstudiantes; x++){
        vecEst[x] = est.leer(x);
    }


finalesArchivo exa;
int cantExa = exa.getCantidad();
ExameneFinal* vecExa= new ExameneFinal[cantExa];
if(vecExa==nullptr){cout << "error en vec dinamico";}

    for(int i=0; i<cantExa; i++){
        vecExa[i] = exa.leer(i);
    }

    int pos=0;

    for(int x=0; x<canEstudiantes; x++){
        for(int y=0; y<cantExa; y++){
            if(vecEst[x].getLegajo()==leg){
                if(vecExa[y].getNota()<6 && vecExa[y].getIDMateria()==mat){
                    return true;
                }
            }

        }
    }



}

