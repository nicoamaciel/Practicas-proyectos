///Ejercicio:
///Autor:DEK
///Fecha:
///Comentario:

# include<iostream>
# include<cstdlib>
# include<cstring>

using namespace std;

class Cadena{
private:
    char *pCad;
    int tam;
public:
    Cadena(const char *ini="nada"){
        tam=strlen(ini)+1;
        pCad=new char[tam];
        if(pCad==NULL)return;
        strcpy(pCad,ini);
        pCad[tam-1]='\0';
    }
    ~Cadena(){
        delete pCad;
    }
    void Mostrar(){
        cout<<pCad<<endl;
    }
    const char *getPcad(){return pCad;}
    bool operator==(Cadena obj){
        if(strcmp(pCad,obj.pCad)==0 && tam==obj.tam) return true;
        return false;
    }
    bool operator==(int cant){///me interesa que se compare el valor recibido con la cantidad de caracteres SIN EL CARACTER NULO
        if(tam==cant+1) return true;
        return false;
    }

};
///SOBRECARGAR EL OPERADOR != PARA COMPARAR DOS CADENAS
///SOBRECARGAR EL OPERADOR > ENTRE UNA CADENA Y UN VECTOR DE CHAR

///Agregar los sets para las propiedades de la clase cadena
////////////////////
class Fecha{
private:
    int dia, mes, anio;
public:
    Fecha(int d=0,int m=0, int a=0){
        dia=d;
        mes=m;
        anio=a;
    }
    bool operator==(Fecha &aux){
        if(dia!=aux.dia) return false;
        if(mes!=aux.mes) return false;
        if(anio!=aux.anio) return false;
        return true;
    }


};
//////////////////////////////

int main(){
    Cadena cad1, cad2("algo");
    cout<<cad1.getPcad()<<endl;
    cad2.Mostrar();
    if(cad1==10){
        cout<<"la cadena tiene 4 caracteres";
    }
    else{
        cout<<"la cadena NO tiene 4 caracteres";
    }
    if(cad1!=10){
        cout<<"la cadena tiene 4 caracteres";
    }
	cout<<endl;
	system("pause");
	return 0;
}
