#include <iostream>
#include <cstdlib>
#include <cstring>
using namespace std;

#include "Comentarios.h"

    int comentario::getid(){
        return _id;
    }
	int comentario::getlegajo(){
        return _legajo;
	}
	Fecha comentario::getFechaPublicacion(){
        return _FechaPublicacion;
	}
	int comentario::getIDForo(){
        return _IDForo;
	}
	int comentario::getIDComentarioRespuesta(){
        return _IDComentarioRespuesta;
	}

	void comentario::setid(int id){
        _id=id;
	}
	void comentario::setlegajo(int leg){
        _legajo=leg;
	}
	void comentario::settexto(const char *tex){
        strcpy (_texto,tex);

	}
	void comentario::setFechaPublicacion(Fecha fe){
        _FechaPublicacion=fe;

	}
	void comentario::setIDForo(int idf){
        _IDForo=idf;

	}
	void comentario::setIDComentarioRespuesta(int idc){
        _IDComentarioRespuesta=idc;

	}



	void comentario::cargarComentario(){
    int id, leg, idF, idC;
    char tex[300];
    Fecha fe;
    int d,m,a;



	cout << "Cargar id comentario: ";
    cin >> id;
    setid(id);
    cout << "Cargar legajo alumno: ";
    cin >> leg;
    setlegajo(leg);
    cout << "Cargar texto comentario: ";
    cin >> tex;
    settexto(tex);
    cout << "Cargar fecha de publicacion: "<<endl;
    cout << "Dia: ";
    cin>>d;
    fe.setDia(d);
    cout << "Mes: ";
    cin>>m;
    fe.setMes(m);
    cout << "Anio: ";
    cin>>a;
    fe.setAnio(a);
    cout << "Cargar id de foro (1- Cafeter�a, 2- Foro de dudas, 3- Tareas, 4 - Grupos, 5- Desaf�os )";
    cin >>idF;
    setIDForo(idF);
    cout << "Cargar ID Comentario: ";
    cin >>idC;
    setIDComentarioRespuesta(idC);
	}


    int comentario::grabarenDisco(){
    FILE *pComentarios;
    pComentarios = fopen("comentarios.dat", "ab");
    if(pComentarios == NULL){
    cout << "ERROR DE ARCHIVO"<< endl;
    system("pause");
    return -1;
        }
    int escribio = fwrite(this, sizeof(comentario), 1, pComentarios);
    fclose(pComentarios);
    return escribio;
    }
