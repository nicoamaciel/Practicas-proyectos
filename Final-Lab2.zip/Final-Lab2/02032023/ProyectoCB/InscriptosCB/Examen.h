#ifndef EXAMEN_H_INCLUDED
#define EXAMEN_H_INCLUDED

class Examen{
private:

public:
    void leerExamenes();
    void crearExamenFinal();
    void alumnosAprobados();
    void dificultadExamen(int anio);

};
bool validarAlumno(int leg, int mat);
#endif // EXAMEN_H_INCLUDED
