///Ejercicio:
///Autor:DEK
///Fecha:
///Comentario:

# include<iostream>
# include<cstdlib>
# include<cstring>

using namespace std;

void cargarCadena(char *pal, int tam){
  int i;
  fflush(stdin);
  for(i=0;i<tam;i++){
      pal[i]=cin.get();
	  if(pal[i]=='\n') break;
	  }
  pal[i]='\0';
  fflush(stdin);
}


class Empresa{
private:
    int numeroEmpresa;
    char nombreEmpresa[30];
    int cantidadEmpleados;
    int categoria;
    int municipio;
    bool estado;
public:
    int getNumeroEmpresa(){return numeroEmpresa;}
    const char *getNombreEmpresa(){return nombreEmpresa;}
    int getCantidadEmpleados(){return cantidadEmpleados;}
    int getCategoria(){return categoria;}
    int getMunicipio(){return municipio;}
    bool getEstado(){return estado;}
    void setNumeroEmpresa(int nE){numeroEmpresa=nE;}
    void setNombreEmpresa(const char *nE){strcpy(nombreEmpresa,nE);}
    void setCantidadEmpleados(int cE){cantidadEmpleados=cE;}
    void setCategoria(int c){categoria=c;}
    void setMunicipio(int m){municipio=m;}
    void setEstado(bool e){estado=e;}
    void Cargar(int nE=-1);
    void Mostrar();
    bool leerDeDisco(int pos);
    bool grabarEnDisco();
    bool modificarEnDisco(int pos);
};

bool Empresa::leerDeDisco(int pos){ //pos es la posición que ocupa el registro en el archivo, empezando por 0
    FILE *p;
    p=fopen("empresas.dat","rb");
    if(p==NULL) return false;
    fseek(p, pos * sizeof (Empresa), 0); ///sizeof (Empresa) es el tamaño en bytes de un objeto Empresa en memoria
    bool leyo = fread(this, sizeof (Empresa), 1, p);
    fclose(p);
    return leyo;
}

bool Empresa::grabarEnDisco(){
    FILE *p;
    p=fopen("empresas.dat","ab");
    if(p==NULL) return false;
    bool escribio = fwrite(this, sizeof (Empresa), 1, p);
    fclose(p);
    return escribio;
}

bool Empresa::modificarEnDisco(int pos){
    FILE *p;
    p=fopen("empresas.dat","rb+");
    if(p==NULL) return false;
    fseek(p, pos * sizeof(Empresa), 0);
    bool escribio=fwrite(this, sizeof (Empresa), 1, p);
    fclose(p);
    return escribio;
}

void Empresa::Cargar(int nE){
    if(nE==-1){
        cout<<"NUMERO DE EMPRESA: ";
        cin>>numeroEmpresa;
    }
    else{
        numeroEmpresa=nE;
    }
    cout<<"NOMBRE: ";
    cargarCadena(nombreEmpresa,29);
    cout<<"CANTIDAD DE EMPLEADOS: ";
    cin>>cantidadEmpleados;
    cout<<"CATEGORIA: ";
    cin>>categoria;
    cout<<"MUNICIPIO: ";
    cin>>municipio;
    estado=true;
    cout<<endl;

}

void Empresa::Mostrar(){
    if(estado==true){
        cout<<"NUMERO DE EMPRESA: ";
        cout<<numeroEmpresa<<endl;
        cout<<"NOMBRE: ";
        cout<<nombreEmpresa<<endl;
        cout<<"CANTIDAD DE EMPLEADOS: ";
        cout<<cantidadEmpleados<<endl;
        cout<<"CATEGORIA: ";
        cout<<categoria<<endl;
        cout<<"MUNICIPIO: ";
        cout<<municipio<<endl;
    }
}

void cargarVectorEmpresa(Empresa *vReg, int cant){
    int i;
    for(i=0;i<cant;i++){
        vReg[i].Cargar();
    }
}

bool cargarArchivo1(){
    Empresa reg;
    int escribio, i;
    FILE *p;
    p=fopen("empresas.dat", "wb");
    if(p==NULL){
        return false;
    }
    for(i=0;i<3;i++){
        reg.Cargar();
        escribio=fwrite(&reg, sizeof(Empresa),1,p);
        if(escribio==0){
            fclose(p);
            return false;
        }
    }
    fclose(p);
    return true;
}

/*bool cargarArchivo2(){
    Empresa vReg[5];
    int escribio;
    FILE *p;
    p=fopen("empresas.dat", "ab");
    if(p==NULL){
        return false;
    }
    cargarVectorEmpresa(vReg, 3);
    escribio=fwrite(vReg, sizeof(Empresa),3,p);
    fclose(p);
    return escribio;
}*/

bool cargarArchivo2(){
    Empresa reg;
    int escribio;
    FILE *p;
    p=fopen("empresas.dat", "ab");
    if(p==NULL){
        return false;
    }
    reg.Cargar();
    escribio=fwrite(&reg, sizeof(Empresa),1,p);
    fclose(p);
    return escribio;
}

bool mostrarArchivo(){
    Empresa reg;
    int i;
    FILE *p;
    p=fopen("empresas.dat", "rb");
    if(p==NULL){
        return false;
    }
    /*for(i=0;i<3;i++){
        fread(&reg, sizeof(Empresa),1,p);///devuelve si pudo leer la cantidad leída
        reg.Mostrar();
        cout<<endl;
    }*/
    while(fread(&reg, sizeof(Empresa),1,p)==1){
        reg.Mostrar();
        cout<<endl;
    }
    fclose(p);
    return true;
}

int buscarNumeroEmpresa(int nE){
    Empresa obj;
    int pos=0;
    while(obj.leerDeDisco(pos)){
        if(obj.getNumeroEmpresa()==nE){
            return pos;
        }
        pos++;
    }
    return -1;
}

int main(){
    Empresa obj;
    FILE *p;
    p=fopen("empresas.dat","rb");
    if(p==NULL) return -1;
    cout<<"TAMANIO DE EL TIPO DE DATOS: "<<sizeof (Empresa)<<endl;
    fseek(p,0,2);
    cout<<ftell(p)/sizeof(Empresa)<<endl;
    fclose(p);
    system("pause>nul");
    return 0;
    int nE, pos=0;
    cout<<"INGRESE EL NUMERO DE EMPRESA A DAR DE BAJA: ";
    cin>>nE;
    pos=buscarNumeroEmpresa(nE);
    if(pos==-1){
        cout<<"LA EMPRESA INGRESADA NO EXISTE EN EL ARCHIVO"<<endl;
        system("pause");
        return -1;
    }
    obj.leerDeDisco(pos);
    //obj.setEstado(true);
    obj.setNombreEmpresa("EMPRESA 1");
    obj.modificarEnDisco(pos);
    pos=0;
    while(obj.leerDeDisco(pos++)){
        obj.Mostrar();
        if(obj.getEstado())cout<<endl;
    }
    //mostrarArchivo();
    /*int opc;
    while(true){
        system("cls");
        cout<<"------MENU EMPRESAS------"<<endl;
        cout<<"1. CARGAR EMPRESAS DE A 1 REGISTRO"<<endl;
        cout<<"2. CARGAR LAS 5 EMPRESAS EN UN VECTOR DE 5"<<endl;
        cout<<"3. MOSTRAR EMPRESAS CARGADAS"<<endl;
        cout<<"0. SALIR DEL PROGRAMA"<<endl;
        cout<<"-------------------------"<<endl;
        cout<<"SELECCIONE UNA OPCION: "<<endl;
        cin>>opc;
        system("cls");
        switch(opc){
            case 1: cargarArchivo1();
                    break;
            case 2: cargarArchivo2();
                    break;
            case 3: if(!mostrarArchivo()){
                        cout<<"NO EXISTE EL ARCHIVO"<<endl;
                    };
                    break;
            case 0: return 0;
                    break;
        }
        system("pause");
        system("cls");
    }*/
	cout<<endl;
	system("pause");
	return 0;
}
