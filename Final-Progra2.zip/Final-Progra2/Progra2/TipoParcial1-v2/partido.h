#ifndef PARTIDO_H_INCLUDED
#define PARTIDO_H_INCLUDED

#include <iostream>
#include <cstring>
#include <cstdlib>
using namespace std;

class partido{
private:
    int NumeroPartido;
    char CodigJugador[5];
    int Dia;
    int Mes;
    int CantidadGoles;
    bool Expulsado;

public:

    //Gets
    int getNumeroPartido(){return NumeroPartido;}
    const char *getCodigJugador(){return CodigJugador;}
    int getDia(){return Dia;}
    int getMes(){return Mes;}
    int getCantidadGoles(){return CantidadGoles;}
    bool getExpulsado(){return Expulsado;}


    //Sets
    void setNumeroPartido(int numP){NumeroPartido=numP;}
    void setCodigJugador(const char *codJ){strcpy(CodigJugador,codJ);}
    void setDia(int d){Dia=d;}
    void setMes(int m){Mes=m;}
    void setCantidadGoles(int cant){CantidadGoles=cant;}
    void setExpulsado(bool exp){Expulsado=exp;}

    //Comportamiento
    void cargar();
    void mostrar();
    bool grabarDisco();
    bool leerDisco(int pos);


};

void partido::cargar(){
int num,d,m,cant;
char cod[5];
bool expul;

cout << "Cargar numero de partido: ";
cin >>num;
cout << "Cargar codigo de jugador: ";
cin >>cod;
cout << "Cargar dia: ";
cin >>d;
cout << "Cargar mes de partido: ";
cin >>m;
cout << "Cargar cantidad de goles convertidos: ";
cin >>cant;
cout << "Cargar 1 si fue expulsado - 0 si no fue expulsado: ";
cin >>expul;

setNumeroPartido(num);
setCodigJugador(cod);
setDia(d);
setMes(m);
setCantidadGoles(cant);
setExpulsado(expul);
}
void partido::mostrar(){
cout << "Cargar numero de partido: " << getNumeroPartido() << endl;
cout << "Cargar codigo de jugador: " << getCodigJugador() << endl;
cout << "Cargar dia: " << getDia() << endl;
cout << "Cargar mes de partido: " << getMes() << endl;
cout << "Cantidad de goles convertidos: " << getCantidadGoles() << endl;
cout << "Expulsado: "<< getExpulsado() <<endl;
cout << "- - - - - - - - - - - - - - - - - - - - - - - " << endl;
}
bool partido::grabarDisco(){

FILE *pPartido = fopen("partido.dat","ab");
if(pPartido==nullptr){return false;}

bool escribio = fwrite(this,sizeof(partido),1,pPartido);
fclose(pPartido);
return escribio;
}
bool partido::leerDisco(int pos){

FILE *pPartido = fopen("partido.dat", "rb");
if(pPartido==nullptr){return false;}

fseek(pPartido,pos*sizeof(partido),SEEK_SET);
bool leyo = fread(this, sizeof(partido),1,pPartido);
fclose(pPartido);
return leyo;


}





#endif // PARTIDO_H_INCLUDED
