#include <iostream>
#include <cstdlib>
#include <cstring>
using namespace std;

#include "ExameneFinal.h"
#include "Fecha.h"

    int ExameneFinal::getId(){
        return _id;
    }
	int ExameneFinal::getLegajo(){
        return _Legajoalumno;
	}

	Fecha ExameneFinal::getFechaExamen(){
        return _fechaExamen;
	}
	int ExameneFinal::getIDMateria(){
        return _IDMateria;
	}
	int ExameneFinal::getNota(){
        return _Nota;
	}

	void ExameneFinal::setId(int id){
        _id=id;
	}
	void ExameneFinal::setLegajo(int leg){
        _Legajoalumno=leg;
	}
	void ExameneFinal::setObservacion(const char *obs){
        strcpy (_Observacion,obs);
	}
	void ExameneFinal::setFechaExamen(Fecha fe){
        _fechaExamen=fe;
	}
	void ExameneFinal::setIDMateria(int idMat){
        _IDMateria = idMat;
	}
	void ExameneFinal::setNota(int nota){
        _Nota=nota;
	}

	void ExameneFinal::cargarExamenes(){
        int id, leg, idMat, nota;
        char obs[300];
        Fecha fe;
        int d,m,a;



	cout << "Cargar id del Alumno: ";
    cin >> id;
    setId(id);
    cout << "Cargar legajo alumno: ";
    cin >> leg;
    setLegajo(leg);
    cout << "Cargar observacion: ";
    cin >> obs;
    setObservacion(obs);
    cout << "Cargar fecha de examen: "<<endl;
    cout << "Dia: ";
    cin>>d;
    fe.setDia(d);
    cout << "Mes: ";
    cin>>m;
    fe.setMes(m);
    cout << "Anio: ";
    cin>>a;
    fe.setAnio(a);
    cout << "Cargar id de materia: ";
    cin >>idMat;
    setIDMateria(idMat);
    cout << "Cargar Nota: ";
    cin >>nota;
    setNota(nota);
	}


	int ExameneFinal::grabarenDisco(){
    FILE *pExaFinales;
    pExaFinales = fopen("ExaFinales.dat", "ab");
    if(pExaFinales == NULL){
    cout << "ERROR DE ARCHIVO"<< endl;
    system("pause");
    return -1;
        }
    int escribio = fwrite(this, sizeof(ExameneFinal), 1, pExaFinales);
    fclose(pExaFinales);
    return escribio;
	}
